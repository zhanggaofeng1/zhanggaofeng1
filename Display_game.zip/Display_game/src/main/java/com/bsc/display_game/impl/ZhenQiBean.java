/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPZhenQiData;
import com.bsc.commonproject.clinet.command.response.RPZhenQiLianQi;
import com.bsc.display_game.bo.ZhenQiBo;
import com.bsc.display_game.request.ZQExchangeRQ;
import com.bsc.display_game.request.ZQLianQiRQ;
import com.bsc.display_game.request.ZQLoad;
import com.bsc.display_game.request.ZQUpgradeRQ;
import com.bsc.display_game.service.ZhenQiService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.util.json.JsonHelper;
import java.util.List;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class ZhenQiBean extends DaosPublic implements ZhenQiService {

    private static final Logger log = LoggerFactory.getLogger(ZhenQiBean.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private ZhenQiBo zhenQiBo;

    public void upgrade(SuperAction sa) throws Exception {
        try {

            RPChangeData change = new RPChangeData();
            String json = sa.getRequestJson();
            ZQUpgradeRQ upgrade = (ZQUpgradeRQ) JsonHelper.getBeanFromJson(json, ZQUpgradeRQ.class);
            int cardId = upgrade.getCardId();
            int userId = upgrade.getUserid();
            List<Integer> delCardIds = upgrade.getDelCardIds();

            change = zhenQiBo.upgrade_zq(delCardIds, userId, cardId, change);

            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void lianqi(SuperAction sa) throws Exception {
        try {

            RPZhenQiLianQi change = new RPZhenQiLianQi();
            String json = sa.getRequestJson();
            ZQLianQiRQ lianqi = (ZQLianQiRQ) JsonHelper.getBeanFromJson(json, ZQLianQiRQ.class);
            int userId = lianqi.getUserid();
            int random_type = lianqi.getLq_type();

            change = zhenQiBo.Lianqi(userId, random_type, change);
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void exchange(SuperAction sa) throws Exception {
        try {

            RPChangeData change = new RPChangeData();
            String json = sa.getRequestJson();
            ZQExchangeRQ exchangeR = (ZQExchangeRQ) JsonHelper.getBeanFromJson(json, ZQExchangeRQ.class);
            int userId = exchangeR.getUserid();
            int cardId = exchangeR.getCardId();
            change = zhenQiBo.exchange(userId, cardId, change);
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void xinwupangwu(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            ZQExchangeRQ exchangeR = (ZQExchangeRQ) JsonHelper.getBeanFromJson(json, ZQExchangeRQ.class);
            int userId = exchangeR.getUserid();
            RPChangeData change = zhenQiBo.xinwupangwu(userId);
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void load(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            ZQLoad zq = (ZQLoad) JsonHelper.getBeanFromJson(json, ZQLoad.class);
            int userId = zq.getUserid();
            RPZhenQiData data = zhenQiBo.load(userId);
            sa.setResponseJson(JsonHelper.getJsonFromBean(data));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
