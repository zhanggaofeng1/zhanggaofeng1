/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.CJAchieveData;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.MsgEvent;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.Message;
import com.bsc.commonproject.vo.ResItem;
import com.bsc.display_game.constants.DataConstants;
import com.bsc.display_game.constants.GrudgeConstants;
import com.bsc.display_game.impl.AllianceBean;
import com.bsc.display_game.impl.GrudgeBean;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.CommMsgBean;
import com.bsc.message.server.FactionService;
import com.bsc.message.server.LevelMsgService;
import com.bsc.message.server.SystemMsgService;
import com.bsc.protracted.domin.CdUnion;
import com.bsc.protracted.domin.CmAlliance;
import com.bsc.protracted.domin.CmAllianceMember;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class MessageBackBo {

    private static final Logger log = LoggerFactory.getLogger(MessageBackBo.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private AllianceBo allianceBo;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private LevelMsgService levelMsgService;
    @Resource
    private SystemMsgService systemMsgService;
    @Resource
    private CommMsgBean commMsgBean;
    @Resource
    private GrudgeBo grudgeBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private FactionService factionService;
    @Resource
    private AchieveBo achieveBo;

    public RPState allance_applyresult(int userId, Message m, String result, int messageType) throws Exception {
        RPState ps = new RPState();
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            int applay_userId = m.getSenderId();
            String applay_nume = null;
            int applay_user_allianceId = 0;
            CmAllianceMember member = allianceBo.is_alliance_member(userId);
            CmAlliance alliance = (CmAlliance) ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, member.getAllianceId());
            if (Constants.DEFALUT_OK_1.equals(result)) {
                MenPaiCacheVo apply_vo = menPaiBo.getCmMenpaiFromCache(applay_userId);
                if (apply_vo == null) {
                    CmMenpai mp = menPaiBo.getCmMenpaiFromDB(applay_userId);
                    if (mp != null) {
                        applay_nume = mp.getMpName();
                        applay_user_allianceId = mp.getAllianceId();
                    }
                } else {
                    applay_nume = apply_vo.getMpName();
                    applay_user_allianceId = apply_vo.getAllianceId();
                }
                if (applay_user_allianceId == 0) {
                    //验证用户是否为盟主或者副盟主
                    if (DataConstants.ALLIANCE_POST_FUMENGZHU == member.getPost() || DataConstants.ALLIANCE_POST_MENGZHU == member.getPost()) {
                        Map<Integer, CdUnion> map = (Map<Integer, CdUnion>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                        CdUnion cdUnion = (CdUnion) map.get(alliance.getAllanceLevel());
                        if (alliance.getMembers().size() <= cdUnion.getUnionNum()) {
                            ps.setSt(ErrorCodeEnum.normal_success.value());
                            allianceBo.add_alliance(member.getAllianceId(), applay_userId);
                            //int senderId, String senderName, int recId, String recName, String factionName
                            String recName = menPaiBo.getMenPaiName(applay_userId);
                            systemMsgService.someOneAgreeSomeOneRequest(vo.getUserId(), vo.getMpName(), applay_userId, recName, alliance.getAllianceName());
                            //int senderId, String whoJoin, int factionId
                            factionService.factionPlayerJoinFc(applay_userId, applay_nume, alliance.getAllianceId());
                        } else {
                            ps.setSt(ErrorCodeEnum.arrive_limit.value());
                        }
                    } else {
                        ps.setSt(ErrorCodeEnum.alliance_post_error.value());
                    }
                } else {
                    ps.setSt(ErrorCodeEnum.alliance_have_exist.value());
                }
            } else {
                //int senderId, String senderName, int recId, String factionName
                m.setMsgEvent(MsgEvent.is_refuse);
                commMsgBean.putDifTypeOfMessage(userId, m);
                levelMsgService.someOneRefuseSomeOneInvateJoinFc(vo.getUserId(), vo.getMpName(), applay_userId, alliance.getAllianceName());
                ps.setSt(ErrorCodeEnum.normal_success.value());
            }
            commMsgBean.deleteAnyTypeOfMessage(userId, m.getId(), messageType);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ps;
    }

    public RPState alliance_inviteresut(int userId, Message m, String result, int messageType) throws Exception {
        RPState ps = new RPState();
        try {
            ResItem res = (ResItem) m.getRes().get(0);
            int allianceId = res.getItemId();
            //验证用户是否存在联盟
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            CmAlliance alliance = allianceBo.find_alliance(allianceId);
            if (Constants.DEFALUT_OK_1.equals(result)&&alliance!=null) {
                if (vo.getAllianceId() == 0) {
                    Map<Integer, CdUnion> map = (Map<Integer, CdUnion>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                    CdUnion cdUnion = (CdUnion) map.get(alliance.getAllanceLevel());
                    //判断联盟认识是否符合
                    if (alliance.getMembers().size() <= cdUnion.getUnionNum()) {
                        allianceBo.add_alliance(allianceId, userId);
                        String recName = menPaiBo.getMenPaiName(m.getSenderId());
                        //int senderId, String senderName, int recId, String recName, String factionName
                        systemMsgService.someOneAgreeSomeOneInvate(userId, vo.getMpName(), m.getSenderId(), recName, alliance.getAllianceName());
                        ps.setSt(ErrorCodeEnum.normal_success.value());
                    } else {
                        ps.setSt(ErrorCodeEnum.arrive_limit.value());
                    }
                }
            } else {
                m.setMsgEvent(MsgEvent.is_refuse);
                commMsgBean.putDifTypeOfMessage(userId, m);
                levelMsgService.someOneRefuseSomeOneInvateJoinFc(userId, vo.getMpName(), m.getSenderId(), alliance.getAllianceName());
                ps.setSt(ErrorCodeEnum.normal_success.value());
            }
            commMsgBean.deleteAnyTypeOfMessage(userId, m.getId(), messageType);
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ps;
    }

    public RPState friend_add(int userId, Message m, String result, int messageType) throws Exception {
        RPState ps = new RPState();
        try {
            String type = GrudgeConstants.FRIEND.getValue_add();
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            //查找消息
            if (Constants.DEFALUT_OK_1.equals(result)) {
                if (GrudgeConstants.FRIEND.getValue_add().equals(type)) {
                    //增加好友
                    int add_result = grudgeBo.add_friend(userId,m.getSenderId());
                    if (add_result == -1) {
                        ps.setSt(ErrorCodeEnum.user_enemy.value());
                    } else if (add_result == -2) {
                        ps.setSt(ErrorCodeEnum.arrive_limit.value());
                    } else if (add_result == -3) {
                        ps.setSt(ErrorCodeEnum.user_data_error.value());
                    } else {

                        //int userId, int codeId, int exp, int level 增加成就
                        AchieveVo achieveVo = achieveBo.saveAchieve(userId, 150010007, 1, 0);
                        if (achieveVo != null) {
                            Map<String, Object> m2 = new HashMap<String, Object>();
                            List<CJAchieveData> lt = new ArrayList<CJAchieveData>();
                            CJAchieveData cd = new CJAchieveData();
                            cd.setId(150010007);
                            cd.setLv(achieveVo.getLv());
                            m2.put(ClientMapKeyEnum.achive.value(), lt.add(cd));
                            ps.setAh(m2);
                        }
                        MenPaiCacheVo fid_vo = menPaiBo.getCmMenpaiFromCache(m.getSenderId());
                        if (fid_vo == null) {
                            achieveBo.saveAchievementEXP_DB(m.getSenderId(), 150010007, 1);
                        } else {
                            achieveBo.saveAchieve(m.getSenderId(), 150010007, 1, 0);
                        }
                        levelMsgService.someOneAgreeJoinFriend(vo.getUserId(), vo.getMpName(), m.getSenderId());
                        ps.setSt(ErrorCodeEnum.normal_success.value());
                    }
                }
                commMsgBean.deleteAnyTypeOfMessage(userId, m.getId(), messageType);
            } else {
                m.setMsgEvent(MsgEvent.is_refuse);
                commMsgBean.putDifTypeOfMessage(userId, m);
                levelMsgService.someOneRefuseRequestJoinFriend(vo.getUserId(), vo.getMpName(), m.getSenderId());
                ps.setSt(ErrorCodeEnum.normal_success.value());
            }

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GrudgeBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ps;
    }

    public RPState flower(int userId, Message m, String result, int messageType) throws Exception {
        RPState publicRP = new RPState();
        try {
            int num = 1;
            MenPaiCacheVo my_vo = menPaiBo.getCmMenpaiFromCache(userId);
            String recName = "";
            //增加好友的花
            int flower_num = mpcommonBo.getPlayNum(21, userId, 2, true);
            if (flower_num == -1) {
                publicRP.setSt(ErrorCodeEnum.arrive_limit.value());
            } else {
                int receive_userId = m.getSenderId();
                if (grudgeBo.my_send_user(userId, receive_userId)) {
                    if (grudgeBo.receive_flower_num(receive_userId)) {
                        MenPaiCacheVo receive_vo = menPaiBo.getCmMenpaiFromCache(receive_userId);
                        if (receive_vo != null) {
                            recName = receive_vo.getMpName();
                            mpcommonBo.update_flower(receive_userId, num);
                        } else {
                            CmMenpai mp = menPaiBo.getCmMenpaiFromDB(receive_userId);
                            recName = mp.getMpName();
                            mp.setMpFlower(mp.getMpFlower() + num);
                            menPaiBo.update(mp);
                        }
                        //增加我的花值
                        mpcommonBo.update_flower(userId, num);
                        systemMsgService.sendFloorMsg(userId, my_vo.getMpName(), my_vo.getMpVip(), receive_userId, recName);
                        publicRP.setSt(ErrorCodeEnum.normal_success.value());
                        commMsgBean.deleteAnyTypeOfMessage(userId, m.getId(), messageType);
                    } else {
                        publicRP.setSt(ErrorCodeEnum.submit_have_ok.value());
                    }
                } else {
                    publicRP.setSt(ErrorCodeEnum.arrive_limit.value());
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GrudgeBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return publicRP;
    }
}
