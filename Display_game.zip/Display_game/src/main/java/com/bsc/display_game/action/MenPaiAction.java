/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;

import com.bsc.display_game.bo.MenPaiBo;
import com.bsc.display_game.service.MenPaiService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import com.bsc.temporary.ehcache.CacheHandler;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.ByteArrayInputStream;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/menpai")
public class MenPaiAction extends SuperAction {

    @Resource
    private MenPaiService menPaiService;
    @Resource
    private MenPaiBo menPaiBo;
//    @Resource
//    private FunRevice funRevice;
    @Resource
    private CacheHandler ch;

    @Action(value = "create", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String create() {
        try {
            menPaiService.create(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "load", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String load() {
        try {
            menPaiService.load(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "update", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String update() {
        try {
            menPaiService.update(this);
            setJsonStream(new ByteArrayInputStream("123".getBytes()));

        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "barriers", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String barriers() {
        try {
            menPaiService.barriers(this);

        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "wlp", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String wlp() {
        try {
            menPaiService.tujian(this);

        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "renamed", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String renamed() {
        try {
            menPaiService.renamed(this);

        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
     @Action(value = "cd", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String cd() {
        try {
            menPaiService.otherdata(this);;

        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
     @Action(value = "quit", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String quit() {
        try {
            menPaiService.quit(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
//    @Action(value = "bat", results =
//            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
//    public String bat() {
//        try {
//            int j = 1;
//            //int user_id, int type_id, int sort_id, int scores
//            for (int i = 1; i < 20; i++) {
//                int z = (int) (Math.random() * 10) + 1;
//                if (i % 10 == 0) {
//                    j++;
//                }
//                barriersBo.addBarriers(1, j, i, (int) (Math.random() * 3) + 1);
//            }
//            setJsonStream(new ByteArrayInputStream("123".getBytes()));
//        } catch (Exception e) {
//            return THROWSERROR;
//        }
//        return SUCCESS;
//    }

    @Action(value = "tz", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String tz() {
        try {
//            Map map = new HashMap();
//            map.put(MsgKeys.TYPE, ControlType.USER_LOGIN);
//            map.put(MsgKeys.USERID, 1);
//            map.put(MsgKeys.USERNAME, "rtr彩电@#$%*(&)");
//            map.put(MsgKeys.ROLENAME, "rtr彩电@#$%*(&)");
//            map.put(MsgKeys.AREAID, 1);
//            map.put(MsgKeys.AREA, "AA");
//            map.put(MsgKeys.INGOT, 10);
//            funRevice.msgSend(JsonHelper.getJsonFromBean(map));
//            setJsonStream(new ByteArrayInputStream("123".getBytes()));
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
}
