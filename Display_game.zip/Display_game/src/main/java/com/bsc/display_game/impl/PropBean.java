/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.DisCommonBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPUpdateUserData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.PropConstants;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.TiYanVipVo;
import com.bsc.display_game.bo.PackageBo;
import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.request.DelProp;
import com.bsc.display_game.request.MenPaiUpdateRQ;
import com.bsc.display_game.request.PropUseRQ;
import com.bsc.display_game.request.ShopOpenRQ;
import com.bsc.display_game.request.TQLoadRQ;
import com.bsc.display_game.service.PropServce;
import com.bsc.displaybases.SuperAction;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdFormula;
import com.bsc.protracted.domin.CdGoods;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpOtherData;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.json.JsonHelper;
import com.bsc.util.tools.FelCount;
import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class PropBean extends DaosPublic implements PropServce {

    @Resource
    private PackageBo packageBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private CacheHandler ch;
    @Resource
    private PropBo propBo;
    @Resource
    private DisCommonBo disCommonBo;
    @Resource
    private SaveLogBo saveLogBo;
    @Resource
    private RankBo rankBo;
    private static final Logger log = LoggerFactory.getLogger(ShopBean.class);

    public void open(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            ShopOpenRQ shopOpenRQ = (ShopOpenRQ) JsonHelper.getBeanFromJson(json, ShopOpenRQ.class);
            //验证道具
            CmMpProps prop = propBo.getCmMpPropsFromCacheBycardId(shopOpenRQ.getUserid(), shopOpenRQ.getCardId());
            RPChangeData change = new RPChangeData();
            if (prop != null) {
                //验证包裹
                Map<Integer, CdGoods> cdGoods_map = (Map<Integer, CdGoods>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.GOOD_KEY);
                if (cdGoods_map != null && !cdGoods_map.isEmpty()) {
                    for (int i = 0; i < shopOpenRQ.getNum(); i++) {
                        if (packageBo.is_box(prop.getPropId())) {
                            change = packageBo.open_box(shopOpenRQ.getUserid(), prop, change);
                        } else {
                            CdGoods goods = cdGoods_map.get(prop.getPropId());
                            if (goods != null) {
                                //int userId, CmMpProps prop, int packageCodeId, int num, RPChangeData change
                                change = packageBo.open_package(shopOpenRQ.getUserid(), prop, prop.getPropId(), goods.getOpenType(), change);
                            } else {
                                change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
                            }
                        }
                    }
                } else {
                    change.setSt(ErrorCodeEnum.goal_prop_not_exist.value());
                }
            } else {
                change.setSt(ErrorCodeEnum.item_error.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void load_tq(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            TQLoadRQ tqLoadRQ = (TQLoadRQ) JsonHelper.getBeanFromJson(json, TQLoadRQ.class);
            RPUpdateUserData up = new RPUpdateUserData();
            long[] ti = mpcommonBo.edit_physique(tqLoadRQ.getUserid(), 0, 0);
            long[] qi = mpcommonBo.edit_momentum(tqLoadRQ.getUserid(), 0, 0);
            up.setTi((int) ti[0]);
            up.setTilt((int) ti[1]);
            up.setQi((int) qi[0]);
            up.setQilt((int) qi[1]);
             up.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(up));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void add_tq(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            TQLoadRQ tqLoadRQ = (TQLoadRQ) JsonHelper.getBeanFromJson(json, TQLoadRQ.class);
            RPChangeData change = new RPChangeData();
            //int modeId, int userId, int type, boolean is_day_num
            int modeId = 4;//体力恢复次数
            if (tqLoadRQ.getType() == 2) {
                modeId = 5;//气力恢复次数
            }
            int num = mpcommonBo.getPlayNum(modeId, tqLoadRQ.getUserid(), 3, true);
            //查找公式码表
            Map cdFormula_map = (Map) ch.getObjectFromCache(CacheNames.FORMULABASIC_CODE_CACHE, ElementKeys.CODE_TABLE_KEY);
            CdFormula cdFormula = (CdFormula) cdFormula_map.get(53);
            //封装公式需要的参数
            Map map = new HashMap();
            map.put("n", num);
            Number final_exp_number = FelCount.getCountResult(map, cdFormula.getGongshi());
            int less_num = Tools.getNumberToInt(final_exp_number);
            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(tqLoadRQ.getUserid());
            if (vo.getMpGold() - less_num > 0) {
                mpcommonBo.consum_gold(vo.getUserId(), less_num);
                saveLogBo.gold(ControlType.BUY_TILI_OR_QILI, vo.getUserId(), vo.getMpName(), vo.getMpGold(), less_num, "buy_ti_or_qi");
                if (modeId == 4) {
                    long[] times = mpcommonBo.edit_physique(vo.getUserId(), 1, 8);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.tili.value(), String.valueOf(8)));
                } else if (modeId == 5) {
                    mpcommonBo.edit_momentum(vo.getUserId(), 1, 8);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.qili.value(), String.valueOf(8)));
                }
                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(less_num)));

            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void menpai_update(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            RPChangeData change = new RPChangeData();
            MenPaiUpdateRQ mpu = (MenPaiUpdateRQ) JsonHelper.getBeanFromJson(json, MenPaiUpdateRQ.class);
            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(mpu.getUserid());
            if (vo != null) {
                Map<Integer, Integer> cdLvReward_map = (Map<Integer, Integer>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.LV_REWARD_KEY);
                Object obj = cdLvReward_map.get(vo.getMpLevel());
                if (obj != null) {
                    int packageId = (Integer) obj;
                    Map<Integer, CdGoods> cdGoods_map = (Map<Integer, CdGoods>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.GOOD_KEY);
                    if (cdGoods_map != null && !cdGoods_map.isEmpty()) {
                        CdGoods goods = cdGoods_map.get(packageId);
                        //验证用户该等级是否领过奖品
                        if (getLvReward(vo.getUserId(), vo.getMpLevel())) {
                            //用户升级奖励，开包裹形式奖励
                            change = packageBo.open_package(mpu.getUserid(), null, goods.getId(), goods.getOpenType(), change);
                        }
                    } else {
                        change.setSt(ErrorCodeEnum.goal_prop_not_exist.value());
                    }
                } else {
                    change.setSt(ErrorCodeEnum.info_error_json.value());
                }
            } else {
                change.setSt(ErrorCodeEnum.user_not_exist.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void use(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            PropUseRQ propUseRQ = (PropUseRQ) JsonHelper.getBeanFromJson(json, PropUseRQ.class);
            int userId = propUseRQ.getUserid();
            List<DelProp> dellt = propUseRQ.getDelLt();
            RPChangeData change = new RPChangeData();
            if (dellt != null) {
                for (DelProp delprop : dellt) {
                    CmMpProps prop = propBo.getCmMpPropsFromCacheBycardId(userId, delprop.getCardId());
                    if (prop != null) {
                        if (prop.getPropNum() - delprop.getNum() >= 0) {
                            int error = 0;
                            if (prop.getPropId() >= PropConstants.PANTAO_1_CODE_ID && prop.getPropId() <= PropConstants.PANTAO_9_CODE_ID) {//蟠桃
                                int exp = (int) propBo.getPropAttach(prop.getPropId());
                                List<Integer> lt = new ArrayList<Integer>();
                                lt.add(propUseRQ.getUse_cardId());
                                List<CmMpDisciple> dis_lt = disCommonBo.disciple_exp(userId, lt, exp);
                                if (dis_lt != null) {
                                    CmMpDisciple dis = dis_lt.get(0);
                                    //更新弟子的经验和等级
                                    change.getCv().getCc().add(PackageCardBo.getDicCard(dis.getMpDisId(), dis.getDiscipleId(), dis.getDisLevel(), dis.getDisExp(), Constants.DEFUALT_NULL, dis.getDisPotential(), CardStatusEnum.add.value(), dis.getGestId()));
                                }
                            } else if (prop.getPropId() == PropConstants.ZHANGMENTIE_CODE_ID) {//掌门贴
                                int num = (int) propBo.getPropAttach(prop.getPropId());
                                int all_num = mpcommonBo.getPlayNum(1, userId, 2, false);
                                int today_num = mpcommonBo.getPlayNum(1, userId, 3, true);
                                if (all_num - today_num + num <= all_num) {
                                    rankBo.use_zhangmentie(userId, num);
                                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.rank_ok_num.value(), String.valueOf(num)));
                                } else {
                                    error = -1;
                                }
                            } else if (prop.getPropId() == PropConstants.YUANLIDAN_CODE_ID) {//气力
                                int num = (int) propBo.getPropAttach(prop.getPropId());
                                mpcommonBo.edit_momentum(userId, 1, num);
                                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.qili.value(), String.valueOf(num)));
                            } else if (prop.getPropId() == PropConstants.TILIDAN_CODEI_ID) {//体力
                                int num = (int) propBo.getPropAttach(prop.getPropId());
                                mpcommonBo.edit_physique(userId, 1, num);
                                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.tili.value(), String.valueOf(num)));
                            } else if (prop.getPropId() == PropConstants.TIYANVIP_6 || prop.getPropId() == PropConstants.TIYANVIP_10) {//体验VIP6.vip10
                                int day = (int) propBo.getPropAttach(prop.getPropId());
                                int vip = 6;
                                if (prop.getPropId() == PropConstants.TIYANVIP_10) {
                                    vip = 10;
                                }
                                TiYanVipVo vo = mpcommonBo.use_vip_tiyan(userId, vip, day);
                                if (vo != null) {
                                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.mp_t_vip.value(), String.valueOf(vip)));
                                }
                            }
                            if (error == 0) {
                                int card_status = CardStatusEnum.add.value();
                                 CmMpProps consum_prop = propBo.consumProp(userId, delprop.getCardId(), delprop.getNum());
                                if (consum_prop.getPropNum() == 0) {
                                    card_status = CardStatusEnum.del.value();
                                }
                                change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), prop.getPropNum(), prop.getPropNum(), card_status));
                                change.setSt(ErrorCodeEnum.normal_success.value());
                            } else if (error == -1) {
                                change.setSt(ErrorCodeEnum.arrive_limit.value());
                            }
                        } else {
                            change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
                        }
                    } else {
                        change.setSt(ErrorCodeEnum.goal_prop_not_exist.value());
                    }
                }
            } else {
                change.setSt(ErrorCodeEnum.info_error_must_data_null.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    private boolean getLvReward(int userId, int lv) throws Exception {
        try {
            Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
            if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
            }
            Object lv_reward_obj = cmMpOtherData_map.get("user_lv_reward");
            CmMpOtherData cmMpOtherData = null;
            Set set = null;
            if (lv_reward_obj != null) {
                cmMpOtherData = (CmMpOtherData) lv_reward_obj;
                set = (Set) JsonHelper.getBeanFromJson(cmMpOtherData.getDataValue(), Set.class);
            } else {
                cmMpOtherData = new CmMpOtherData();
                cmMpOtherData.setDataKey("user_lv_reward");
                cmMpOtherData.setUserId(userId);
                int dataId = save(cmMpOtherData);
                cmMpOtherData.setDataId(dataId);
                set = new HashSet();
            }
            if (!set.contains(lv)) {
                set.add(lv);
                cmMpOtherData.setDataValue(JsonHelper.getJsonFromBeanNoSrting(set));
                cmMpOtherData_map.put(cmMpOtherData.getDataKey(), cmMpOtherData);
                ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);
                return true;
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return false;
    }
}
