/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;


import com.bsc.display_game.service.ZhenQiService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import static com.opensymphony.xwork2.Action.SUCCESS;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/zhenqi")
public class ZhenQiAction extends SuperAction{
    @Resource
    private ZhenQiService zhenQiService;
    
    @Action(value = "upgrade", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String upgrade() {
        try {
            zhenQiService.upgrade(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
    
     @Action(value = "lianqi", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String lianqi() {
        try {
            zhenQiService.lianqi(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
     @Action(value = "exchange", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String exchange() {
        try {
            zhenQiService.exchange(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
     @Action(value = "xwpw", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String xwpw() {
        try {
            zhenQiService.xinwupangwu(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
     @Action(value = "load", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String load() {
        try {
            zhenQiService.load(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
    
}
