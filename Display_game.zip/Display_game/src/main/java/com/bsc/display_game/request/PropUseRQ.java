/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class PropUseRQ extends ReceiveJson{
     @JsonProperty("id")
    private int use_cardId;
      @JsonProperty("il")
    private List<DelProp> delLt;

    public int getUse_cardId() {
        return use_cardId;
    }

    public void setUse_cardId(int use_cardId) {
        this.use_cardId = use_cardId;
    }

    

    public List<DelProp> getDelLt() {
        return delLt;
    }

    public void setDelLt(List<DelProp> delLt) {
        this.delLt = delLt;
    }
    
   

  
    
}
