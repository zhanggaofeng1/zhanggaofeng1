/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.RPBattleData;
import com.bsc.commonproject.constants.BattleModel;
import com.bsc.commonproject.request.BattlleRQ;
import com.bsc.display_game.bo.GestBo;
import com.bsc.display_game.bo.GrudgeBo;
import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.service.GameBattleService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;

import com.bsc.protracted.daos.DaosPublic;
import com.bsc.util.json.JsonHelper;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GameBattleBean extends DaosPublic implements GameBattleService {

    @Resource
    private GestBo gestBo;
    @Resource
    private RankBo rankBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private GrudgeBo grudgeBo;
    private static final Logger log = LoggerFactory.getLogger(GameBattleBean.class);

    public void battle(SuperAction sa) throws Exception {
        try {
            RPBattleData rpbd = new RPBattleData();
            String json = sa.getRequestJson();
            BattlleRQ bttlleRQ = (BattlleRQ) JsonHelper.getBeanFromJson(json, BattlleRQ.class);
            int userId = bttlleRQ.getUserid();
            int rivalId = bttlleRQ.getCompetitorId();
            int battleId = bttlleRQ.getBattleId();
            if (BattleModel.broken.value() == battleId) {
                Map<String, String> map = bttlleRQ.getAppendMap();
                int brokenCode = Integer.parseInt((String) map.get("brokenCodeId"));
                String brokenType = String.valueOf(map.get("brokenType"));

                //int have_uid, int snatch_uid, int brokenCodeId, int broken_type, RPChangeData change
                rpbd = gestBo.snatch(rivalId, userId, brokenCode, brokenType, rpbd);
            }else if(battleId == BattleModel.rank.value()){
                int result = mpcommonBo.getPlayNum(1, userId, 2, false);
                if(result == -1){
                    rpbd.setSt("no num");
                }else{
                    rpbd = rankBo.battle(userId, rivalId, rpbd);
                }
            }else if(battleId == BattleModel.qiecuo.value()){
                rpbd = grudgeBo.learn(userId, rivalId, rpbd);
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(rpbd));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GameBattleBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
