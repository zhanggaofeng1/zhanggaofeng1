/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;


import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class ZQLianQiRQ extends ReceiveJson {

    @JsonProperty("t")
    private int lq_type;

    public int getLq_type() {
        return lq_type;
    }

    public void setLq_type(int lq_type) {
        this.lq_type = lq_type;
    }

   
}
