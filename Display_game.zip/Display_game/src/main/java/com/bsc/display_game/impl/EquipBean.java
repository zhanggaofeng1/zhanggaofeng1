/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.bo.CommonBo;
import com.bsc.display_game.bo.EquipBo;
import com.bsc.display_game.constants.CstateConstants;
import com.bsc.display_game.request.EquipRefining;
import com.bsc.display_game.request.EquipRefiningRQ;
import com.bsc.display_game.request.EquipSellRQ;
import com.bsc.display_game.request.EquipUpgradeRQ;
import com.bsc.display_game.service.EquipService;
import com.bsc.displaybases.SuperAction;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdEquip;
import com.bsc.protracted.domin.CdEquipUpMoney;
import com.bsc.protracted.domin.CmMpEquip;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.json.JsonHelper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class EquipBean extends DaosPublic implements EquipService {

    private static final Logger log = LoggerFactory.getLogger(EquipBean.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private EquipBo equidBo;
    @Resource
    private CommonBo commonBo;
    @Resource
    private SaveLogBo saveLogBo;
    

    public void upgrade(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String json = sa.getRequestJson();
            EquipUpgradeRQ equipUpgradeRQ = (EquipUpgradeRQ) JsonHelper.getBeanFromJson(json, EquipUpgradeRQ.class);
            int userId = equipUpgradeRQ.getUserid();
            int cardId = equipUpgradeRQ.getCardId();
            //查找用户信息
            //查找用户装备数据
            Map equip_map = (Map) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
            Object obj = equip_map.get(cardId);
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (obj != null) {
                CmMpEquip equip = (CmMpEquip) obj;
                if (equip.getEquipLevel() < 3 * vo.getMpLevel()) {
                    //查找码表数据
                    Map cdEquip_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.EQUIP_KEY);
                    CdEquip cdEquip = (CdEquip) cdEquip_map.get(equip.getEquipId());
                    // CacheNames.EQUIP_SELLANDUPGRADE_CODE_CACHE,查找当前等级下的装备需要消耗的银币数
                    Map sell_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.EQUIP_UP_MONEY_KEY);
                    CdEquipUpMoney cdEquipUpMoney = (CdEquipUpMoney) sell_map.get(equip.getEquipLevel());
                    //封装公式需要的参数
                    Map formula_value_map = new HashMap();
                    formula_value_map.put("baseconsume", cdEquip.getBaseconsume());
                    formula_value_map.put("money", cdEquipUpMoney.getMoney());
                    int final_silver_int = commonBo.getIntFromFormula(14, formula_value_map);
                    //判断用户的硬币是否够本次升级
                    if (vo.getMpSilver() > final_silver_int) {
                        //cardId, silver, uid, level
                        change = equidBo.upgrade(cardId, final_silver_int, userId, vo.getMpVip(),change,cdEquip,vo);
                        change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(-final_silver_int)));
                        change.setSt(ErrorCodeEnum.normal_success.value());
                            //ControlType controlType, int userId, String mp_name, int silver, int counsu_silver, String result, int type
                        saveLogBo.sliver(ControlType.UPDATE_EQUIP, userId, vo.getMpName(), vo.getMpSilver(), -final_silver_int, "", 0);
                    } else {
                        change.setSt(CstateConstants.SHENEGJI_ZHUANGBEI_SLIVER_NO);
                    }
                } else {
                    change.setSt(CstateConstants.SHENGJI_ZHANGBEI_SHANGXIAN);
                }
            } else {
                change.setSt(CstateConstants.SHENGJI_ZHUANGBEI_NO);
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void refining(SuperAction sa) throws Exception {

        try {
            RPChangeData rPChangeData = new RPChangeData();
            String json = sa.getRequestJson();
            EquipRefiningRQ equipRefiningRQ = (EquipRefiningRQ) JsonHelper.getBeanFromJson(json, EquipRefiningRQ.class);
            int userId = equipRefiningRQ.getUserid();
            int cardId = equipRefiningRQ.getCardId();
            List<EquipRefining> del_props = equipRefiningRQ.getEquipRefinings();
            //userId, cardId, List<EquipRefining> del_props
            //装备精炼
            rPChangeData = equidBo.refining(userId, cardId, del_props, rPChangeData);
            sa.setResponseJson(JsonHelper.getJsonFromBean(rPChangeData));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void sell(SuperAction sa) throws Exception {
        try {
            RPChangeData rPChangeData = new RPChangeData();
            String json = sa.getRequestJson();
            EquipSellRQ equipSellRQ = (EquipSellRQ) JsonHelper.getBeanFromJson(json, EquipSellRQ.class);
            int userId = equipSellRQ.getUserid();
            List<Integer> equipIds = equipSellRQ.getEquipIds();
            //装备卖出
            rPChangeData = equidBo.sell(equipIds, userId, rPChangeData);
            sa.setResponseJson(JsonHelper.getJsonFromBean(rPChangeData));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
