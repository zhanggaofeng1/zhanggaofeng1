/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class ClientActionLogListRQ extends ReceiveJson{
     @JsonProperty("ll")
    private List<ClientActionLog> logList;

    public List<ClientActionLog> getLogList() {
        return logList;
    }

    public void setLogList(List<ClientActionLog> logList) {
        this.logList = logList;
    }
     
     
     
}
