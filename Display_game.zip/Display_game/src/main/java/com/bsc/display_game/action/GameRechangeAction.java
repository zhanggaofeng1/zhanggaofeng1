/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;

import com.bsc.display_game.service.GameRechargeService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import static com.opensymphony.xwork2.Action.SUCCESS;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/game")
public class GameRechangeAction extends SuperAction {
         @Resource
     private GameRechargeService gamerechargeService;
     
     @Action(value = "rechange", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String rechange() {
        try {
            gamerechargeService.rechage(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
}
