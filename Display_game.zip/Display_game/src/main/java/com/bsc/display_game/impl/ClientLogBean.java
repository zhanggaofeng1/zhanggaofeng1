/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.request.ClientActionLog;
import com.bsc.display_game.request.ClientActionLogListRQ;
import com.bsc.display_game.service.ClientLogService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.util.datas.DateUtil;
import com.bsc.util.json.JsonHelper;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class ClientLogBean extends DaosPublic implements ClientLogService {

    private static final Logger log = LoggerFactory.getLogger(ClientLogBean.class);
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private SaveLogBo saveLogBo;

    public void log(SuperAction sa) throws Exception {
        try {
            RPState rp = new RPState();
            String json = sa.getRequestJson();
            ClientActionLogListRQ cal = (ClientActionLogListRQ) JsonHelper.getBeanFromJson(json, ClientActionLogListRQ.class);
            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(cal.getUserid());
            if (vo != null) {
                List<ClientActionLog> logList = getSeqList(cal.getLogList());
                long current_time = (DateUtil.getCurrentDate().getTime());
                for (ClientActionLog c : logList) {//  
                    current_time = current_time - c.getTime();
                    java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    String current_time_str = format.format(current_time);
                    //int userId, String mp_name, String page, int second,String time, String result
                    saveLogBo.user_action(vo.getUserId(), vo.getMpName(), c.getSite(), c.getTime(), current_time_str, "");
                }
            }
            rp.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(rp));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public List<ClientActionLog> getSeqList(List<ClientActionLog> logList) {
        Comparator comp = new Comparator() {
            public int compare(Object o1, Object o2) {
                ClientActionLog p1 = (ClientActionLog) o1;
                ClientActionLog p2 = (ClientActionLog) o2;
                if (p1.getSeq() < p2.getSeq()) {
                    return 1;
                } else {
                    return 0;
                }
            }
        };
        Collections.sort(logList, comp);
        return logList;
    }
}
