/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.constants;

/**
 *
 * @author LXF 定义各种常量
 *
 *
 */
public class DataConstants {



    /**
     * **********************装备类别********************************
     */
    //武器
    public static final int EQUIP_TYPE_FIREARM = 1;
    //服装
    public static final int EQUIP_TYPE_CLOTHING = 2;
    //饰品
    public static final int EQUIP_TYPE_ACCESSORIES = 3;
    /**
     * ************定义初始数据***************************
     */
    //
    public static final String DEFUL_CONFIRM_YES = "1";
    public static final String DEFULE_CONFIRM_NO = "0";

    /**
     * *******************门徒提升类型***********************************
     */
    //普通提升1次
    public static final int DISCIPLE_UPGRADE_TYPE_1 = 1;
    //元宝提升
    public static final int DISCIPLE_UPGRAGE_TYPE_2 = 2;
    //普通提升10次
    public static final int DISCIPLE_UPGRADE_TYPE_3 = 3;
    //元宝提升10次
    public static final int DISCIPLE_UPGRADE_TYPE_4 = 4;
    
    
    
    /*****************************道具码表ID**************************************************/
    //银币类别
    public static final int MONEY_TYPE_SILVERE = 1;
    //金币类别
    public static final int MONEY_TYPE_GOLD = 2;
    
    
    
    
    /*******************************定义联盟常量数据*************************************************/
    //联盟盟主
    public static final int ALLIANCE_POST_MENGZHU = 10;
    //联盟副盟主
    public static final int ALLIANCE_POST_FUMENGZHU = 9;
    //联盟精英成员
    public static final int ALLIANCE_POST_JINGYING = 8;
    //普通成员
    public static final int ALLIANCE_POST_MEMEBER = 0;
    //联盟祈福类型1，普通祈福
    public static final int ALLIANCE_PRAYER_TYPE_1 = 1;
    //联盟祈福类型2，消费元宝祈福
    public static final int ALLIANCE_PRAYER_TYPE_2 = 2;
    
    
}
