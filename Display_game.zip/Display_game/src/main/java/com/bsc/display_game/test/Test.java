/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.test;

import java.io.File;

/**
 *
 * @author lxf
 */
import  java.io.File;
public class Test {

    public static void main(String[] args) throws Exception {
        //递归显示C盘下所有文件夹及其中文件
        File root = new File("F:\\Font");
        showAllFiles(root);
    }

    final static void showAllFiles(File dir) throws Exception {
        File[] fs = dir.listFiles();
        for (int i = 0; i < fs.length; i++) {
            System.out.println(fs[i].getAbsolutePath());
            if (fs[i].isDirectory()) {
                try {
                    showAllFiles(fs[i]);
                } catch (Exception e) {
                }
            }
        }
    }
}