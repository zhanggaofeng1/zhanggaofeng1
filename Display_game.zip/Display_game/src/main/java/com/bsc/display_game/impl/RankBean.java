/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.clinet.command.response.CJPaiHanger;
import com.bsc.commonproject.clinet.command.response.CJUserPaiHangData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPPaiHangData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.PropConstants;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.display_game.bo.RankComparator;
import com.bsc.display_game.bo.QueueBo;
import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.constants.RankEnum;
import com.bsc.display_game.request.ExchangeRankDAtaRQ;
import com.bsc.display_game.request.FlushRankScoreRQ;
import com.bsc.display_game.request.RankListRQ;
import com.bsc.display_game.service.RankService;
import com.bsc.display_game.vo.RankVo;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdConverttab;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.datas.StringUtil;
import com.bsc.util.json.JsonHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class RankBean extends DaosPublic implements RankService {

    @Resource
    private RankBo rankBo;
    @Resource
    private CacheHandler ch;
    @Resource
    private AddCardBo addPropBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private QueueBo queueBo;
    private static final Logger log = LoggerFactory.getLogger(RankBean.class);

    public void list(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            RankListRQ rankListRQ = (RankListRQ) JsonHelper.getBeanFromJson(json, RankListRQ.class);
            RPPaiHangData ph = new RPPaiHangData();
            int userId = rankListRQ.getUserid();
            Object[] objs = rankBo.getmyRankList2(userId);
            int r_num = 0;
            while (objs == null || objs.length != 5) {
                r_num++;
                objs = rankBo.getmyRankList2(userId);
                if (r_num >= 3) {
                    break;
                }
            }
            if (objs != null && objs.length == 5) {
                int all_num = mpcommonBo.getPlayNum(1, userId, 2, false);
                int today_num = mpcommonBo.getPlayNum(1, userId, 3, true);
                ph.setRc(all_num - today_num);


                RankVo myvo = (RankVo) objs[0];
                CJUserPaiHangData phd = new CJUserPaiHangData();

                //查询修改用户的积分
//                int score = rankBo.getMinToScore(myvo.getStartTime(), myvo.getSite());
                //editRankDate(int userId, int atackNum, String awardData, BSCLinkedMap map, int score)
                int mysite = myvo.getSite();
                phd.setRk(mysite);
                phd.setSc(myvo.getScore());
                String awardData = myvo.getAwardData();
                if (awardData != null && StringUtil.isNotNull(awardData)) {
                    Map<String, Integer> m = (Map<String, Integer>) JsonHelper.getBeanFromJson(awardData, Map.class);
                    Map<String, Integer> m2 = new HashMap<String, Integer>();
                    for (Map.Entry entry_type : m.entrySet()) {
                        String key = (String) entry_type.getKey();
                        Integer cvo = (Integer) entry_type.getValue();
                        if (cvo > 0) {
                            m2.put(key, cvo);
                        }
                    }
                    phd.setElv(JsonHelper.getJsonFromBean(m2));
                }
                List<CJPaiHanger> pl = new ArrayList();
                if (objs[1] != null) {
                    List<RankVo> top2_list = (List) objs[1];
                    int i = 0;
                    if (top2_list != null && !top2_list.isEmpty()) {
                        for (RankVo vo : top2_list) {
                            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            if (obj == null) {
                                queueBo.addUserInPicture(vo.getUserId());
                                obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            }
                            if (obj != null) {
                                i++;
                                UserPictureVo upv = (UserPictureVo) obj;
                                CJPaiHanger chp = new CJPaiHanger();
                                chp.setId(vo.getUserId());
                                chp.setN(upv.getName());
                                chp.setLv(upv.getLevel());
                                chp.setIl(upv.getDisCodeIds());
                                chp.setVip(upv.getVip());
                                chp.setPt(RankEnum.TOP10_USER.value());
                                chp.setRk(i);
                                pl.add(chp);
                            }
                        }
                    }
                }
                if (objs[2] != null) {
                    List<RankVo> up_list2 = (List) objs[2];
                    if (up_list2 != null && !up_list2.isEmpty()) {
                        for (int i = up_list2.size() - 1; i >= 0; i--) {
                            RankVo vo = (RankVo) up_list2.get(i);
                            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            if (obj == null) {
                                queueBo.addUserInPicture(vo.getUserId());
                                obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            }
                            if (obj != null && vo.getSite() > 10) {
                                UserPictureVo upv = (UserPictureVo) obj;
                                CJPaiHanger chp = new CJPaiHanger();
                                chp.setId(vo.getUserId());
                                chp.setN(upv.getName());
                                chp.setLv(upv.getLevel());
                                chp.setIl(upv.getDisCodeIds());
                                chp.setVip(upv.getVip());
                                chp.setPt(RankEnum.ATTACK_USER.value());
                                chp.setRk(vo.getSite() + 1);
                                pl.add(chp);
                            }
                        }
                    }
                }
                if (objs[3] != null) {
                    List<RankVo> up_list3 = (List) objs[3];
                    if (up_list3 != null && !up_list3.isEmpty()) {
                        for (int i = up_list3.size() - 1; i >= 0; i--) {
                            RankVo vo = (RankVo) up_list3.get(i);
                            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            if (obj == null) {
                                queueBo.addUserInPicture(vo.getUserId());
                                obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            }
                            if (obj != null && vo.getSite() > 10) {
                                UserPictureVo upv = (UserPictureVo) obj;
                                CJPaiHanger chp = new CJPaiHanger();
                                chp.setId(vo.getUserId());
                                chp.setN(upv.getName());
                                chp.setLv(upv.getLevel());
                                chp.setIl(upv.getDisCodeIds());
                                chp.setVip(upv.getVip());
                                chp.setPt(RankEnum.NORMAL_USER.value());
                                chp.setRk(vo.getSite() + 1);
                                pl.add(chp);
                            }
                        }
                    }
                }
                if (objs[4] != null) {
                    List<RankVo> down_list3 = (List) objs[4];
                    if (down_list3 != null && !down_list3.isEmpty()) {
                        int z = 0;
                        for (RankVo vo : down_list3) {

                            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            if (obj == null) {
                                queueBo.addUserInPicture(vo.getUserId());
                                obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                            }
                            if (obj != null) {
                                z++;
                                UserPictureVo upv = (UserPictureVo) obj;
                                CJPaiHanger chp = new CJPaiHanger();
                                chp.setId(vo.getUserId());
                                chp.setN(upv.getName());
                                chp.setLv(upv.getLevel());
                                chp.setIl(upv.getDisCodeIds());
                                chp.setVip(upv.getVip());
                                chp.setPt(RankEnum.DOWN_USER.value());
                                chp.setRk(mysite + z);
                                pl.add(chp);
                            }
                        }
                    }
                }
                RankComparator articleComparator = new RankComparator();
                Collections.sort(pl, articleComparator);
                ph.setUd(phd);
                ph.setPl(pl);
                ph.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                ph.setSt(ErrorCodeEnum.info_error_member_error.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(ph));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void flush(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            FlushRankScoreRQ flush = (FlushRankScoreRQ) JsonHelper.getBeanFromJson(json, FlushRankScoreRQ.class);
            RPChangeData fd = new RPChangeData();
            int userId = flush.getUserid();
            RankVo vo = rankBo.getUserRankDataFromUserId(userId);
            if (vo != null) {
                Long sl[] = rankBo.getMinToScore(vo.getStartTime(), vo.getSite());
                rankBo.editUserRankDate(userId, vo.getAttackNum(), vo.getAwardData(), vo.getMap(), 0);
                fd.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.rank_score.value(), String.valueOf(sl[0])));
                fd.setSt(ErrorCodeEnum.normal_success.value());

            } else {
                fd.setSt(ErrorCodeEnum.info_error_member_error.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(fd));
            sa.getSend().sendDataToClient(sa, true, true);


        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void exchange(SuperAction sa) throws Exception {
        //0 为开启，1开启可以兑奖，2开启可以积分兑换 ExchangeRankDAtaRQ
        try {
            String json = sa.getRequestJson();
            ExchangeRankDAtaRQ exchange = (ExchangeRankDAtaRQ) JsonHelper.getBeanFromJson(json, ExchangeRankDAtaRQ.class);
            RPChangeData fd = new RPChangeData();
            int userId = exchange.getUserid();
            String exchageType = exchange.getExchageType();
            if (exchageType != null && StringUtil.isNotNull(exchageType)) {
                RankVo vo = rankBo.getUserRankDataFromUserId(userId);
                if (vo != null) {
                    //获取码表数据
                    Map<Integer, CdConverttab> map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.CONVERTTAB_KEY);
                    String awardData = vo.getAwardData();
                    Map<String, Integer> map_award = null;
                    if (awardData == null || !StringUtil.isNotNull(awardData)) {
                        map_award = new HashMap<String, Integer>();
                    } else {
                        map_award = (Map) JsonHelper.getBeanFromJson(awardData, Map.class);
                    }

                    //验证用户是否存在没有开启的奖励
                    for (Map.Entry entry_type : map.entrySet()) {
                        int key = (Integer) entry_type.getKey();
                        CdConverttab cvo = (CdConverttab) entry_type.getValue();
                        if (cvo.getRdLimit() >= vo.getSite()) {
                            Object obj = map_award.get(String.valueOf(key));
                            if (obj == null) {
                                map_award.put(String.valueOf(key), 0);
                            }
                        }
                    }
                    Object obj = map_award.get(exchageType);
                    if (obj != null) {
                        int value = (Integer) obj;
                        CdConverttab tab = map.get(Integer.parseInt(exchageType));
                        int peiyandan = 0;
                        int score = 0;
                        if (value == 0) {
                            peiyandan = tab.getRdCount();
                            map_award.put(exchageType, 2);
                        } else if (value == 2) {
                            peiyandan = tab.getTrainCount();
                            score = tab.getNeedScore();
                        }
                        if (vo.getScore() - score >= 0) {
                            //修改用户道具数量
                            CmMpProps cmMpProps = addPropBo.addProp(userId, peiyandan, PropConstants.PEIYANGDAN_CODE_ID);
                            //修改用户排行数据
                            rankBo.editUserRankDate(userId, vo.getAttackNum(), JsonHelper.getJsonFromBeanNoSrting(map_award), vo.getMap(), score);
                            //返回变化的培养单数量
//                        fd.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.peiyangdan.value(), String.valueOf(peiyandan)));
                            fd.getCv().getCc().add(PackageCardBo.getPropCard(cmMpProps.getMpPropId(), cmMpProps.getPropId(), cmMpProps.getPropNum(), cmMpProps.getPropLv(), CardStatusEnum.add.value()));
                            if (score != 0) {
                                //变化积分
                                fd.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.rank_score.value(), String.valueOf(-score)));
                            }
                            fd.setSt(ErrorCodeEnum.normal_success.value());
                        } else {
                            fd.setCst(ErrorCodeEnum.count_not_enough.value());
                        }
                    } else {
                        fd.setSt("errror");
                    }
                } else {
                    fd.setSt("rank error");
                }
            } else {
                fd.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(fd));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }

    }
}
