/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.cache.listener;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.singleton.UserLoginNum;
import com.bsc.displaybases.tigger.PersionManager;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.util.srping.SpringUtil;
import java.util.logging.Level;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.event.CacheEventListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cache监听器
 *
 * @author lxf
 */
public class UserControlListener implements CacheEventListener {

    private static final Logger log = LoggerFactory.getLogger(UserControlListener.class);
    public static final CacheEventListener INSTANCE = new UserControlListener();

    public void notifyElementRemoved(Ehcache ehch, Element elmnt) throws CacheException {
        log.debug("Removed -------------------------" + ehch.getName() + "-->" + elmnt.getKey() + "-->" + elmnt.getObjectValue().toString());
    }

    public void notifyElementPut(Ehcache ehch, Element elmnt) throws CacheException {
        log.debug("Put ----------------------------------" + ehch.getName() + "-->" + elmnt.getKey() + "-->" + elmnt.getObjectValue().toString());
    }

    public void notifyElementUpdated(Ehcache ehch, Element elmnt) throws CacheException {
        log.debug("Updated -----------------------------" + ehch.getName() + "-->" + elmnt.getKey());
    }
//空闲

    public void notifyElementExpired(Ehcache ehch, Element elmnt) {
        try {
            UserLoginNum.getInstance().del((Integer) elmnt.getKey());
            MPCommonBo bo = (MPCommonBo) SpringUtil.getBean("MPCommonBo");
            bo.updateFromCacheToDB((Integer) elmnt.getKey());
            CacheManager manager = (CacheManager) SpringUtil.getBean("cacheManager");
            if (manager != null) {
                Cache cache = manager.getCache(CacheNames.USER_MENPAI_CACHE);
                if (cache != null) {
                    Element e = cache.get((Integer) elmnt.getKey());
                    if (e != null) {
                        Object obj = e.getObjectValue();
                        if (obj != null) {
                            MenPaiCacheVo vo = (MenPaiCacheVo) obj;
                            if (vo.getLoginStatue() == 1) {
                                vo.setLoginStatue(0);
                                PersionManager.getInstance().delNum();
                                Element e2 = new Element((Integer) elmnt.getKey(), vo);
                                cache.put(e2);
                            }
                        }
                    }
                }
            }
            System.out.println("t=" + PersionManager.getInstance().getNum());
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(UserControlListener.class.getName()).log(Level.SEVERE, null, ex);
        }
        log.debug("Expired -------------------------------------" + ehch.getName() + "-->" + elmnt.getKey());
    }
//存活时间

    public void notifyElementEvicted(Ehcache ehch, Element elmnt) {
        try {
            UserLoginNum.getInstance().del((Integer) elmnt.getKey());
            MPCommonBo bo = (MPCommonBo) SpringUtil.getBean("MPCommonBo");
            bo.updateFromCacheToDB((Integer) elmnt.getKey());
            CacheManager manager = (CacheManager) SpringUtil.getBean("cacheManager");
            if (manager != null) {
                Cache cache = manager.getCache(CacheNames.USER_MENPAI_CACHE);
                if (cache != null) {
                    Element e = cache.get((Integer) elmnt.getKey());
                    if (e != null) {
                        Object obj = e.getObjectValue();
                        if (obj != null) {
                            MenPaiCacheVo vo = (MenPaiCacheVo) obj;
                            if (vo.getLoginStatue() == 1) {
                                vo.setLoginStatue(0);
                                PersionManager.getInstance().delNum();
                                Element e2 = new Element((Integer) elmnt.getKey(), vo);
                                cache.put(e2);
                            }
                        }
                    }
                }
            }
            System.out.println("t=" + PersionManager.getInstance().getNum());

        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(UserControlListener.class.getName()).log(Level.SEVERE, null, ex);
        }
        log.debug("Evicted ------------------------------------" + ehch.getName() + "-->" + elmnt.getKey());
    }

    public void notifyRemoveAll(Ehcache ehch) {
        log.debug("RemoveAll -------------------------->" + ehch.getName());
    }

    public void dispose() {
        log.debug("dispose Ehcache!!!");
    }

    @Override
    public Object clone() {
        return null;
    }
}
