/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;



/**
 *
 * @author lxf
 */
public class MessageReturnRQ extends ReceiveJson{
     @JsonProperty("id")
    private int messageId;
      @JsonProperty("tp")
    private int messageType;
       @JsonProperty("fn")
    private String result;

    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

   

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public int getMessageType() {
        return messageType;
    }

    public void setMessageType(int messageType) {
        this.messageType = messageType;
    }
    

   
   

    
    
    
}
