/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;

import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface ManageUpdateService extends BaseDao {

    public String update(int type) throws Exception;

    public void creat_rank() throws Exception;
    
      public void creat_rank2() throws Exception;

    public void updateCacheDate(String type) throws Exception;
}
