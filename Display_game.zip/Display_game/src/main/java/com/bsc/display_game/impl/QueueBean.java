/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.CJFData;
import com.bsc.commonproject.clinet.command.response.RPFormationData;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.bo.EquipBo;
import com.bsc.display_game.bo.GestBo;
import com.bsc.display_game.bo.QueueBo;
import com.bsc.display_game.bo.ZhenQiBo;
import com.bsc.display_game.request.AddQueueDIsRQ;
import com.bsc.display_game.request.ChangeQueueRQ;
import com.bsc.display_game.request.EditCardSiteRQ;
import com.bsc.display_game.request.GetQueueListRQ;
import com.bsc.display_game.service.QueueService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CmMpEquip;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpGestZhenqi;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.util.datas.StringUtil;

import com.bsc.util.json.JsonHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class QueueBean extends DaosPublic implements QueueService {

    private static final Logger log = LoggerFactory.getLogger(QueueBean.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private EquipBo equipBo;
    @Resource
    private GestBo gestBo;
    @Resource
    private ZhenQiBo zhenQiBo;
    @Resource
    private QueueBo queueBo;
    @Resource
    private MPCommonBo mpcommonBo;

    public void getQueueList(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            GetQueueListRQ getQueueListRQ = (GetQueueListRQ) JsonHelper.getBeanFromJson(json, GetQueueListRQ.class);
            int userId = getQueueListRQ.getUserid();
            int find_user_id = getQueueListRQ.getFind_user_id();
            int type = getQueueListRQ.getRequest_type();
            RPFormationData pf = new RPFormationData();
            if (type == 1) {
                boolean ble = true;
                if (find_user_id == 0) {
                    ble = false;
                    find_user_id = userId;
                }
                Object[] objs = queueBo.getCJFData(find_user_id, ble);
                if (objs == null) {
                    pf.setSt(ErrorCodeEnum.user_not_exist.value());
                } else {
                    if ( objs.length > 1) {
                        CJFData fd = (CJFData) objs[0];
                        pf.setF(fd);
                        pf.setSt(ErrorCodeEnum.normal_success.value());
                    }

                }
            } else {
                pf.setSt(ErrorCodeEnum.info_error_must_data_null.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(pf));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void editCardSite(SuperAction sa) throws Exception {
        RPState publicRP = new RPState();
        try {
            String queue_json = sa.getRequestJson();
            EditCardSiteRQ editQueueRQ = (EditCardSiteRQ) JsonHelper.getBeanFromJson(queue_json, EditCardSiteRQ.class);
            int userId = editQueueRQ.getUserid();
            int type = editQueueRQ.getEquipType();
            int site = editQueueRQ.getEquipSite() + 1;//客户端默认顺序从0开始所以做自加1以便区分未装备和以装备
            int up_cardId = editQueueRQ.getCardId();
            int queue_site = editQueueRQ.getQueueSite() + 1;
            int down_cardId = 0;
            int battleId = queueBo.find_battle_disciple(userId, queue_site);
            if (battleId != 0) {
                String error = ErrorCodeEnum.normal_success.value();
                //区分装备的类别 1：装备 2：武功 3：真气
                if (type == 1) {
                    //查找位置上的装备
                    CmMpEquip cmMpEquip = equipBo.getCmMpEquipFromCacheBySite(userId, battleId, site);
                    if (cmMpEquip != null) {
                        down_cardId = cmMpEquip.getMpEquipId();
                    }
                    //修改装备
                    equipBo.replace(down_cardId, up_cardId, userId, site, battleId);
                } else if (type == 2) {
                    //查找位置上的武功
                    CmMpGest cmMpGest = gestBo.getCmMpEquipFromCacheBySite(userId, battleId, site);

                    if (cmMpGest != null) {
                        down_cardId = cmMpGest.getMpGestId();
                    }
                    Map<Integer, CmMpGest> cmMpProps_map = (Map<Integer, CmMpGest>) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
                    if (cmMpProps_map != null && !cmMpProps_map.isEmpty()) {
                        CmMpGest up_cmMpGest = cmMpProps_map.get(up_cardId);
                        if (gestBo.getCmMpGestFromCacheByApp(userId, battleId, up_cmMpGest.getGestId())) {
                            //修改使用的武功
                            gestBo.replace_gest(down_cardId, up_cardId, userId, site, battleId);
                        } else {
                            error = ErrorCodeEnum.up_same_prop.value();
                        }
                    }
                } else if (type == 3) {
                    CmMpGestZhenqi cmMpGestZhenqi = zhenQiBo.getCmMpGestZhenqiFromCacheBySite(userId, battleId, site);
                    if (cmMpGestZhenqi != null) {
                        down_cardId = cmMpGestZhenqi.getMpZhenqiId();
                    }
                    Map<Integer, CmMpGestZhenqi> cmMpGestZhenqi_map = (Map<Integer, CmMpGestZhenqi>) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
                    if (cmMpGestZhenqi_map != null && !cmMpGestZhenqi_map.isEmpty()) {
                        CmMpGestZhenqi up_cmMpGestZhenqi = cmMpGestZhenqi_map.get(up_cardId);
                        if (gestBo.getCmMpGestFromCacheByApp(userId, battleId, up_cmMpGestZhenqi.getZhenqiId())) {
                            //修改使用的武功
                            zhenQiBo.replace_zq(down_cardId, up_cardId, userId, site, battleId);
                        } else {
                            error = ErrorCodeEnum.up_same_prop.value();
                        }
                    }
                }
                //修改存储用户头像数据
                MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
                queueBo.getUserPicture(userId, vo.getMpName(), vo.getMpLevel());
                publicRP.setSt(error);
            } else {
                publicRP.setSt(ErrorCodeEnum.info_error_must_data_null.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void addQueueDIs(SuperAction sa) throws Exception {
        RPState publicRP = new RPState();
        try {
            String json = sa.getRequestJson();
            AddQueueDIsRQ addQueueDIsRQ = (AddQueueDIsRQ) JsonHelper.getBeanFromJson(json, AddQueueDIsRQ.class);
            int cardId = addQueueDIsRQ.getDisCardId();
            int site = addQueueDIsRQ.getSite() + 1;
            int userId = addQueueDIsRQ.getUserid();
            //修改存储用户头像数据
            int up_num = 1;
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (vo.getCmMpLineup() != null && StringUtil.isNotNull(vo.getCmMpLineup().getBitArray()) && vo.getCmMpLineup().getBitArray().indexOf(",") > 0) {
                String[] cardSite = vo.getCmMpLineup().getBitArray().split(",");
                up_num = cardSite.length;
            }
            if (mpcommonBo.getQueueNum(vo.getMpLevel()) >= up_num) {
                //默认新上阵弟子
                if (site < 0) {
                    site = up_num + 1;
                }
                if (queueBo.is_dis_up_battle(userId, cardId)) {
                    queueBo.replace(site, cardId, userId);
                    queueBo.getUserPicture(userId, vo.getMpName(), vo.getMpLevel());
                    publicRP.setSt(ErrorCodeEnum.normal_success.value());
                } else {
                    publicRP.setSt(ErrorCodeEnum.up_same_prop.value());
                }
            } else {
                publicRP.setSt(ErrorCodeEnum.arrive_limit.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }

    }

    public void changeQueue(SuperAction sa) throws Exception {
        RPState publicRP = new RPState();
        try {
            String queue_json = sa.getRequestJson();
            ChangeQueueRQ changeQueueRQ = (ChangeQueueRQ) JsonHelper.getBeanFromJson(queue_json, ChangeQueueRQ.class);
            List lineups = changeQueueRQ.getSiteList();
            int userId = changeQueueRQ.getUserid();
            if (lineups != null && !lineups.isEmpty()) {
                String lineup = lineups.toString().substring(1, (lineups.toString().length() - 1)).trim();
                queueBo.changeQueue(userId, lineup);
                publicRP.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                publicRP.setSt(ErrorCodeEnum.info_error_verify_error.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
