/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.clinet.command.response.CJPaiHanger;
import java.util.Comparator;

/**
 *
 * @author lxf
 */
public class RankComparator implements Comparator {

    public int compare(Object o1, Object o2) {
        CJPaiHanger c1 = (CJPaiHanger) o1;
        CJPaiHanger c2 = (CJPaiHanger) o2;
        if (c1.getRk() > c2.getRk()) {
            return 1;
        }
        return -1;
    }
}
