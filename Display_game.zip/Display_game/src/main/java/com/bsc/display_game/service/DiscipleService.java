/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;



import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface DiscipleService extends BaseDao {
    //弟子招募

    public void recruit(SuperAction sa) throws Exception;
//弟子传功

    public void transfer(SuperAction sa) throws Exception;
//弟子培养

    public void train(SuperAction sa) throws Exception;
//地址培养确认

    public void train_confirm(SuperAction sa) throws Exception;
//弟子突破

    public void tuPo(SuperAction sa) throws Exception;
}
