/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.BarriersBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.bo.WordFilter;
import com.bsc.commonproject.clinet.command.response.CJFData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPLevelData;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.clinet.command.response.RPTuJianData;
import com.bsc.commonproject.clinet.command.response.RPUserData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.CardTypeEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.GameConstants;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.bo.MenPaiBo;
import com.bsc.display_game.bo.QueueBo;
import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.request.BarriersDateRQ;
import com.bsc.display_game.request.CreateMPRQ;
import com.bsc.display_game.request.LoadMPRQ;
import com.bsc.display_game.request.QuitRQ;
import com.bsc.display_game.request.RenamedRQ;
import com.bsc.display_game.request.TuJianListRQ;
import com.bsc.display_game.request.UserOtherDateRQ;
import com.bsc.display_game.service.MenPaiService;
import com.bsc.displaybases.SuperAction;
import com.bsc.displaybases.tigger.PersionManager;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdGoods;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpOtherData;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.protracted.domin.CmMpWulinpu;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;

import com.bsc.util.datas.DateUtil;
import com.bsc.util.datas.StringUtil;

import com.bsc.util.json.JsonHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class MenPaiBean extends DaosPublic implements MenPaiService {

    private static final Logger log = LoggerFactory.getLogger(MenPaiBean.class);
    private static final String CILENT_DATA = "CILENTDATA";
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private CacheHandler ch;
    @Resource
    private AddCardBo addPropBo;
    @Resource
    private BarriersBo barriersBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private QueueBo queueBo;
    @Resource
    private SaveLogBo saveLogBo;
    @Resource
    private RankBo rankBo;
    @Resource
    private WordFilter wordFilter;

    /**
     * *
     * 创建门派
     *
     * @param sa
     * @throws java.lang.Exception
     */
    public void create(SuperAction sa) throws Exception {
        try {
            String create_menpai_json = sa.getRequestJson();
            CreateMPRQ createMPRQ = (CreateMPRQ) JsonHelper.getBeanFromJson(create_menpai_json, CreateMPRQ.class);
            int userId = createMPRQ.getUserid();
            String menpai_name = createMPRQ.getName();
            RPUserData userDatd = new RPUserData();

            if (createMPRQ.getDisId() == 0 || menpai_name == null || !StringUtil.isNotNull(menpai_name)) {
                userDatd.setSt(ErrorCodeEnum.info_error_must_data_null.value());
            } else if (!wordFilter.wordValite(menpai_name)) {
                 userDatd.setSt(ErrorCodeEnum.info_data_illegal.value());
            } else {
                if (menPaiBo.is_huan_name(menpai_name)) {
                    CmMenpai cmMenpai = new CmMenpai();
                    // cmMenpai.setUserId(userId);
                    cmMenpai.setMpName(menpai_name);
                    cmMenpai.setUserId(userId);
                    cmMenpai.setMpPhysique(30);
                    cmMenpai.setMpMomentum(12);
                    //91赠送
//                    cmMenpai.setMpGold(100000);
//                    cmMenpai.setMpSilver(100000);
//                    cmMenpai.setMpVip(6);

                    cmMenpai.setMpLevel(GameConstants.DEFALUT_LEVEL);

                    //存储门派信息
                    int mp_id = save(cmMenpai);
                    cmMenpai.setMpId(mp_id);

                    saveLogBo.saveCreate(userId, menpai_name, mp_id);

                    userDatd = menPaiBo.loadfromdb(cmMenpai, userDatd);
                    //创建弟子卡牌
                    CmMpDisciple cmMpDisciple = addPropBo.getCmMpDisciple(mp_id, createMPRQ.getDisId(), GameConstants.DEFALUT_LEVEL);

                    CmMpGest gest = cmMpDisciple.getCmMpGest();
                    userDatd.getCardlist().add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), CardStatusEnum.add.value()));
                    //int cardId, int codeId,int level, int exp,int topoLv,int poten ,int state
                    userDatd.getCardlist().add(PackageCardBo.getDicCard(cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), cmMpDisciple.getDisLevel(), cmMpDisciple.getDisExp(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                    //设置出阵弟子
                    queueBo.replace(1, cmMpDisciple.getMpDisId(), mp_id);
                    //设置阵型
                    queueBo.changeQueue(mp_id, "0");
                    //反返回阵型数据
                    Object[] objs = queueBo.getCJFData(mp_id, false);
                    List<Integer> queuesLt = new ArrayList<Integer>();
                    if (objs != null && objs.length > 1) {
                        CJFData fd = (CJFData) objs[0];
                        userDatd.setFaddtion(fd);
                        queuesLt = (List) objs[1];
                    }

                    //注册礼包
                    Map<Integer, CdGoods> cdGoods_map = (Map<Integer, CdGoods>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.GOOD_KEY);
                    if (cdGoods_map != null && !cdGoods_map.isEmpty()) {
                        Object obj = cdGoods_map.get(140040021);
                        if (obj != null && ((CdGoods) obj).getOpenType() > -1) {
                            CmMpProps cmMpProps = addPropBo.addProp(mp_id, 1, 140040021);
                            userDatd.getCardlist().add(PackageCardBo.getPropCard(cmMpProps.getMpPropId(), cmMpProps.getPropId(), cmMpProps.getPropNum(), cmMpProps.getPropLv(), CardStatusEnum.add.value()));
                        }
                    }
                    userDatd.setSt(ErrorCodeEnum.normal_success.value());
//                    //加入排行
//                    rankBo.getUserRankDataFromUserId(mp_id);
                    MenPaiCacheVo vo2 = menPaiBo.getCmMenpaiFromCache(mp_id);

                    PersionManager.getInstance().addNum();
                    //int userId, String mp_name, int silver, int gold, int friend_size, int friend_average_lv, int allianceId, int allance_name, int qishi, int lv
                    saveLogBo.login(vo2.getUserId(), mp_id, vo2.getMpName(), vo2.getMpSilver(), vo2.getMpGold(), 0, 0, vo2.getAllianceId(), "", 0, vo2.getMpLevel(), queuesLt.toString(), vo2.getMpVip(), -1);

                    //
//                 int[] achieves=new int[]{150010001,150010002,150010003,150010004,150010005,150010006,150010007};
                    //saveAchieve(int userId, int codeId, int exp, int level)
//                for(int i = 0;i<achieves.length;i++){
//                    achieveBo.saveAchieve(userId, achieves[i], (i+1)*10, i+1);
//                }
                } else {
                    userDatd.setSt(ErrorCodeEnum.menpai_name_have_exist.value());
                }
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(userDatd));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void load(SuperAction sa) throws Exception {
        try {
            RPUserData userDatd = new RPUserData();
            String load_menpai_json = sa.getRequestJson();
            LoadMPRQ loadMPRQ = (LoadMPRQ) JsonHelper.getBeanFromJson(load_menpai_json, LoadMPRQ.class);
            int user_id = loadMPRQ.getUserid();
            List<CmMenpai> lt = menPaiBo.getCmMenpaiFromUserId(user_id);
            if (lt != null && !lt.isEmpty()) {
                CmMenpai mp = lt.get(0);
//                if (true) {
                if (mp != null) {
                    int mp_id = mp.getMpId();
                    MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(mp_id);
                    //在线人数统计
                    if (vo == null || vo.getLoginStatue() == 0) {
                        PersionManager.getInstance().addNum();
                    }
                    if (vo == null) {
                        //门派
                        userDatd = menPaiBo.loadfromdb(mp, userDatd);
                    } else {
                        //验证cache中是否全部存在
                        mpcommonBo.valiteCacheDate(mp);
                        userDatd = menPaiBo.loadfromcache(mp_id, userDatd);
                    }

                    Object[] objs = queueBo.getCJFData(mp_id, false);
                    List<Integer> queuesLt = new ArrayList<Integer>();
                    if (objs != null && objs.length > 1) {
                        CJFData fd = (CJFData) objs[0];
                        userDatd.setFaddtion(fd);
                        queuesLt = (List) objs[1];
                    }

//                    userDatd.setFaddtion(queueBo.getCJFData(mp_id, false));
                    userDatd.setSt(ErrorCodeEnum.normal_success.value());
                    //增加统计用户数

                    Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, mp_id);
                    Object cilent_data_obj = cmMpOtherData_map.get(CILENT_DATA);
                    if (cilent_data_obj != null) {
                        CmMpOtherData od = (CmMpOtherData) cilent_data_obj;
                        userDatd.setPf(od.getDataValue());
                    }
                    ch.putObjectToCache(CacheNames.USER_CONTROL_CACHE, mp_id, DateUtil.getCurrentDate().getTime());
                    MenPaiCacheVo logvo = menPaiBo.getCmMenpaiFromCache(mp_id);
                    //int userId, String mp_name, int silver, int gold, int friend_size, int friend_average_lv, int allianceId, int allance_name, int qishi, int lv
                    saveLogBo.login(logvo.getReal_userId(), mp_id, logvo.getMpName(), logvo.getMpSilver(), logvo.getMpGold(), 0, 0, logvo.getAllianceId(), "", 0, logvo.getMpLevel(), queuesLt.toString(), logvo.getMpVip(), rankBo.getUserRankDataFromUserId2(mp_id));
                } else {
                    userDatd.setSt(ErrorCodeEnum.menpai_not_exist.value());
                }
            } else {
                userDatd.setSt(ErrorCodeEnum.menpai_not_exist.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(userDatd));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void update(SuperAction sa) throws Exception {
        try {
            String load_menpai_json = sa.getRequestJson();
            LoadMPRQ loadMPRQ = (LoadMPRQ) JsonHelper.getBeanFromJson(load_menpai_json, LoadMPRQ.class);
            int userId = loadMPRQ.getUserid();
            mpcommonBo.updateFromCacheToDB(userId);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void barriers(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            BarriersDateRQ barriersDateRQ = (BarriersDateRQ) JsonHelper.getBeanFromJson(json, BarriersDateRQ.class);
            int userId = barriersDateRQ.getUserid();
            RPLevelData data = barriersBo.getUserBarriers(userId);
            data.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(data));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void tujian(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            RPTuJianData tjdata = new RPTuJianData();
            TuJianListRQ tuJianListRQ = (TuJianListRQ) JsonHelper.getBeanFromJson(json, TuJianListRQ.class);
            int userId = tuJianListRQ.getUserid();
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                Map<Integer, CmMpWulinpu> map = (Map<Integer, CmMpWulinpu>) ch.getObjectFromCache(CacheNames.USER_WULINPU_CACHE, userId);
                if (map != null && !map.isEmpty()) {
                    for (Map.Entry entry_type : map.entrySet()) {
                        CmMpWulinpu wlp = (CmMpWulinpu) entry_type.getValue();
                        if (wlp.getWlpType() == CardTypeEnum.DISCIPLE_CARD_TYPE.value()) {
                            tjdata.setTujian_1(wlp.getWlpValue());
                        } else if (wlp.getWlpType() == CardTypeEnum.GEST_CARD_TYPE.value()) {
                            tjdata.setTujian_2(wlp.getWlpValue());
                        } else if (wlp.getWlpType() == CardTypeEnum.EQUIP_CARD_TYPE.value()) {
                            tjdata.setTujian_3(wlp.getWlpValue());
                        }
                    }
                    tjdata.setSt(ErrorCodeEnum.normal_success.value());
                }
            } else {
                tjdata.setSt(ErrorCodeEnum.user_not_exist.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(tjdata));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void renamed(SuperAction sa) throws Exception {
        String json = sa.getRequestJson();
        RenamedRQ renamedRQ = (RenamedRQ) JsonHelper.getBeanFromJson(json, RenamedRQ.class);
        int userId = renamedRQ.getUserid();
        RPChangeData change = menPaiBo.renamed(userId, renamedRQ.getMp_name());
        sa.setResponseJson(JsonHelper.getJsonFromBean(change));
        sa.getSend().sendDataToClient(sa, true, true);
    }

    public void otherdata(SuperAction sa) throws Exception {
        String json = sa.getRequestJson();
        UserOtherDateRQ uo = (UserOtherDateRQ) JsonHelper.getBeanFromJson(json, UserOtherDateRQ.class);
        int userId = uo.getUserid();
        Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
        if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
            cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
        }
        Object cilent_data_obj = cmMpOtherData_map.get(CILENT_DATA);
        CmMpOtherData cilent_data = null;
        String data = uo.getData();
        if (cilent_data_obj != null) {
            cilent_data = (CmMpOtherData) cilent_data_obj;
            cilent_data.setDataValue(data);
        } else {
            cilent_data = new CmMpOtherData();
            cilent_data.setDataKey(CILENT_DATA);
            cilent_data.setDataValue(data);
            cilent_data.setUserId(userId);
            int dataId = save(cilent_data);
            cilent_data.setDataId(dataId);
        }
        cmMpOtherData_map.put(CILENT_DATA, cilent_data);
        ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);
        RPState ps = new RPState();
        ps.setSt(ErrorCodeEnum.normal_success.value());
        sa.setResponseJson(JsonHelper.getJsonFromBean(ps));
        sa.getSend().sendDataToClient(sa, true, true);
    }

    public void quit(SuperAction sa) throws Exception {
        RPState publicRP = new RPState();
        try {
            String queue_json = sa.getRequestJson();
            QuitRQ quitRQ = (QuitRQ) JsonHelper.getBeanFromJson(queue_json, QuitRQ.class);
            int userId = quitRQ.getUserid();
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null && vo.getLoginStatue() == 1) {
                mpcommonBo.updateFromCacheToDB(userId);
                vo.setLoginStatue(0);
                ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, userId, vo);
                PersionManager.getInstance().delNum();
            }
            publicRP.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
