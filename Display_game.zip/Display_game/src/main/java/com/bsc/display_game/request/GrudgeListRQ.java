/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;



/**
 *
 * @author lxf
 */
public class GrudgeListRQ extends ReceiveJson{
    @JsonProperty("st")
    private int type;
    @JsonProperty("f")
    private String info;
    @JsonProperty("fp")
    private int page;
    @JsonProperty("pp")
    private int num;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    
  
    
    
    
    
}
