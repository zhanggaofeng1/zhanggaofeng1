/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;

import com.bsc.display_game.service.AllianceService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import static com.opensymphony.xwork2.Action.SUCCESS;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/alliance")
public class AllianceAction extends SuperAction {

    @Resource
    private AllianceService allianceService;

    @Action(value = "create", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String create() {
        try {
            allianceService.create(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "apply", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String apply() {
        try {
            allianceService.apply(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "result", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String result() {
        try {
            allianceService.applyresult(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "manager", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String manager() {
        try {
            allianceService.manager(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "mlt", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String mlt() {
        try {
            allianceService.memeberlist(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "alt", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String alt() {
        try {
            allianceService.alliancelist(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "prayer", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String prayer() {
        try {
            allianceService.prayer(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "pay", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String pay() {
        try {
            allianceService.pay(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "buy", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String buy() {
        try {
            allianceService.buy(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "aplt", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String aplt() {
        try {
            allianceService.applylist(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "disband", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String disband() {
        try {
            allianceService.disband(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "ali", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String ali() {
        try {
            allianceService.alliance(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "ult", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String ult() {
        try {
            allianceService.findUserList(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
}
