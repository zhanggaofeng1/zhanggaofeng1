/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class AllianceApplyResultRQ extends ReceiveJson{
    @JsonProperty("ot")
    private String result;
    @JsonProperty("id")
    private int messgeId;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public int getMessgeId() {
        return messgeId;
    }

    public void setMessgeId(int messgeId) {
        this.messgeId = messgeId;
    }

    
    
    
}
