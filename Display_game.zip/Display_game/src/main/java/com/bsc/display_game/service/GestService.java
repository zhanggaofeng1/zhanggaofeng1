/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;



import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface GestService extends BaseDao{
    //武功升级
    public void upgrade(SuperAction sa)throws Exception;  
    //残章合成   
     public void mixtureBroken(SuperAction sa)throws Exception;
    //残章卖出  
     public void sellBroken(SuperAction sa)throws Exception;
     //残章列表
     public void brokenlist(SuperAction sa)throws Exception;
}
