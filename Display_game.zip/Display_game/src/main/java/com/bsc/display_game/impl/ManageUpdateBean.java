/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.vo.RobotVo;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.service.ManageUpdateService;
import com.bsc.displaybases.service.StartService;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.NotifyMsgService;
import com.bsc.message.server.SystemMsgService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdActivity;
import com.bsc.protracted.domin.CdMarket;
import com.bsc.protracted.domin.CdName;
import com.bsc.protracted.domin.CdRobot;
import com.bsc.protracted.domin.CmNotice;
import com.bsc.protracted.domin.CmSendGoods;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.datas.DateUtil;
import com.bsc.util.datas.StringUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class ManageUpdateBean extends DaosPublic implements ManageUpdateService {

    @Resource
    private CacheHandler ch;
    @Resource
    private NotifyMsgService notifyMsgService;
    @Resource
    private RankBo rankBo;
    @Resource
    private SystemMsgService systemMsgService;
    @Resource
    private StartService startService;
    private static final Logger log = LoggerFactory.getLogger(ManageUpdateBean.class);

    public String update(int type) throws Exception {
        try {
            if (type == 1) {//更新集市
                List<CdMarket> marketlt = get(CdMarket.class);
                Map<Integer, CdMarket> CdMarket_map = new HashMap<Integer, CdMarket>();
                for (CdMarket cdMarket : marketlt) {
                    CdMarket_map.put(cdMarket.getId(), cdMarket);
                }
                ch.putObjectToCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.MARKET_KEY, CdMarket_map);
                return "OK";
            } else if (type == 2) {//运营活动管理
                String hql = "from CdActivity a where a.actStartDate <'" + DateUtil.getCurrentDateStr(DateUtil.C_TIME_PATTON_DEFAULT) + "' and a.actEndDate >'" + DateUtil.getCurrentDateStr(DateUtil.C_TIME_PATTON_DEFAULT) + "'";
                List<CdActivity> avlist = get(hql);
                Map<Integer, CdActivity> CdActivity_map = new HashMap<Integer, CdActivity>();
                for (CdActivity cdActivity : avlist) {
                    CdActivity_map.put(cdActivity.getId(), cdActivity);
                }
                ch.putObjectToCache(CacheNames.ACTIVITY_BASIC_CODE_CACHE, ElementKeys.ACTIVE_DEPLAY_KEY, CdActivity_map);
                return "OK";
            } else if (type == 3) {//发布公告
                // 
//                CmNotice
                String hql = "from CmNotice a where a.startDate <'" + DateUtil.getCurrentDateStr(DateUtil.C_TIME_PATTON_DEFAULT) + "' and a.endDate >'" + DateUtil.getCurrentDateStr(DateUtil.C_TIME_PATTON_DEFAULT) + "' order by a.createDate desc";
                List<CmNotice> avlist = get(hql);
                for (CmNotice cmNotice : avlist) {
                    notifyMsgService.addNotifyMsg(cmNotice);
                }
                return "OK";
            } else if (type == 4) {//发奖
                //CmSendGoods
                String hql = "from CmSendGoods a where a.starttime <'" + DateUtil.getCurrentDateStr(DateUtil.C_TIME_PATTON_DEFAULT) + "' and a.endtime >'" + DateUtil.getCurrentDateStr(DateUtil.C_TIME_PATTON_DEFAULT) + "' order by a.controltime desc";
                List<CmSendGoods> csglist = get(hql);
                for (CmSendGoods cmSendGoods : csglist) {
                    if (cmSendGoods.getUserids() != null && StringUtil.isNotNull(cmSendGoods.getUserids())) {
                        if (cmSendGoods.getUserids().indexOf(",") > 0) {
                            String[] uids = cmSendGoods.getUserids().split(",");
                            for (int i = 0; i < uids.length; i++) {
//                                 levelMsgService.officialSendRdtoPlayer(cmSendGoods.getMessage(), Integer.parseInt(uids[i]), Integer.parseInt(cmSendGoods.getGoodsid()), 1, 0, 0);
                            }
                        }
                    } else {
//                         systemMsgService.officialSendRdtoAllPlayer(cmSendGoods.getMessage(),  Integer.parseInt(cmSendGoods.getGoodsid()),1);                  
                    }
                }
                return "OK";
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return "NO";
    }

    public void creat_rank() throws Exception {
        try {
            //默认前10名用户
            String sss = "10228,10229,10230,10231,10232,10233,10234,10235,10236";
            for (String s : sss.split(",")) {
                rankBo.getUserRankDataFromUserId(Integer.parseInt(s));
            }

            List<CdRobot> crtlt = get("from CdRobot order by num desc");
            List<CdName> nlt = get(CdName.class, true);
            List<String> nlt1 = new ArrayList<String>();
            List<String> nlt2 = new ArrayList<String>();
            List<String> nlt3 = new ArrayList<String>();
            for (CdName n : nlt) {
                if (n.getName1() != null && StringUtil.isNotNull(n.getName1())) {
                    nlt1.add(n.getName1());
                }
                if (n.getName2() != null && StringUtil.isNotNull(n.getName2())) {
                    nlt2.add(n.getName2());
                }
                if (n.getName3() != null && StringUtil.isNotNull(n.getName3())) {
                    nlt3.add(n.getName3());
                }
            }

            Map<Integer, RobotVo> robot_map = new HashMap<Integer, RobotVo>();
            Map<Integer, List<RobotVo>> robot_map2 = new HashMap<Integer, List<RobotVo>>();
            for (CdRobot cdRobot : crtlt) {
                List<RobotVo> robot_num_lt2 = new ArrayList<RobotVo>();
                StringBuilder strb = new StringBuilder();
                if (cdRobot.getMonster1() != null && StringUtil.isNotNull(cdRobot.getMonster1())) {
                    strb.append(cdRobot.getMonster1()).append(",");
                }
                if (cdRobot.getMonster2() != null && StringUtil.isNotNull(cdRobot.getMonster2())) {
                    strb.append(cdRobot.getMonster2()).append(",");
                }
                if (cdRobot.getMonster3() != null && StringUtil.isNotNull(cdRobot.getMonster3())) {
                    strb.append(cdRobot.getMonster3()).append(",");
                }
                if (cdRobot.getMonster4() != null && StringUtil.isNotNull(cdRobot.getMonster4())) {
                    strb.append(cdRobot.getMonster4()).append(",");
                }
                if (cdRobot.getMonster5() != null && StringUtil.isNotNull(cdRobot.getMonster5())) {
                    strb.append(cdRobot.getMonster5()).append(",");
                }
                if (cdRobot.getMonster6() != null && StringUtil.isNotNull(cdRobot.getMonster6())) {
                    strb.append(cdRobot.getMonster6()).append(",");
                }
                if (cdRobot.getMonster7() != null && StringUtil.isNotNull(cdRobot.getMonster7())) {
                    strb.append(cdRobot.getMonster7()).append(",");
                }
                String n_strb = strb.substring(0, strb.length() - 1);
                String[] array = n_strb.split(",");

                for (int k = 0; k < cdRobot.getNumber(); k++) {
                    List<Integer> disLt = randomizeInPlace2(array);
                    RobotVo rvo = new RobotVo();
                    rvo.setBabyLv(getRandomNum(cdRobot.getBabyLv()));
                    rvo.setLv(cdRobot.getLv());
                    String n1 = (String) nlt1.get((int) (Math.random() * nlt1.size()));
                    String n2 = (String) nlt2.get((int) (Math.random() * nlt2.size()));
                    String n3 = (String) nlt3.get((int) (Math.random() * nlt3.size()));
                    String name = n1 + n2 + n3;
                    rvo.setName(name.trim());
                    rvo.setDisLt(disLt);
                    Integer id = (cdRobot.getId() + 10) * 100 + k;
                    rvo.setUserId(id);
                    robot_map.put(id, rvo);
                    if (k < cdRobot.getNum()) {
                        robot_num_lt2.add(rvo);
                    }
                    if (cdRobot.getLv() < 26) {
                        rankBo.getUserRankDataFromUserId(id);
                    }
                    putUserPicture(id, name, cdRobot.getLv(), disLt);
                }
                robot_map2.put(cdRobot.getLv(), robot_num_lt2);
            }
            ch.putObjectToCache(CacheNames.ROBOT_DATA_CACHE, ElementKeys.ROBOT_KEY, robot_map);
            ch.putObjectToCache(CacheNames.ROBOT_DATA_CACHE, ElementKeys.ROBOT_BROKEN_KEY, robot_map2);
            System.out.println("robot_map-------------------------" + robot_map.size());
            System.out.println("robot_map2-------------------------" + robot_map2.size());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void creat_rank2() throws Exception {
        try {
            List<CdRobot> crtlt = get("from CdRobot order by num desc");
            List<CdName> nlt = get(CdName.class, true);
            List<String> nlt1 = new ArrayList<String>();
            List<String> nlt2 = new ArrayList<String>();
            List<String> nlt3 = new ArrayList<String>();
            for (CdName n : nlt) {
                if (n.getName1() != null && StringUtil.isNotNull(n.getName1())) {
                    nlt1.add(n.getName1());
                }
                if (n.getName2() != null && StringUtil.isNotNull(n.getName2())) {
                    nlt2.add(n.getName2());
                }
                if (n.getName3() != null && StringUtil.isNotNull(n.getName3())) {
                    nlt3.add(n.getName3());
                }
            }

            Map<Integer, RobotVo> robot_map = new HashMap<Integer, RobotVo>();
            Map<Integer, List<RobotVo>> robot_map2 = new HashMap<Integer, List<RobotVo>>();
            for (CdRobot cdRobot : crtlt) {
                List<RobotVo> robot_num_lt2 = new ArrayList<RobotVo>();
                StringBuilder strb = new StringBuilder();
                if (cdRobot.getMonster1() != null && StringUtil.isNotNull(cdRobot.getMonster1())) {
                    strb.append(cdRobot.getMonster1()).append(",");
                }
                if (cdRobot.getMonster2() != null && StringUtil.isNotNull(cdRobot.getMonster2())) {
                    strb.append(cdRobot.getMonster2()).append(",");
                }
                if (cdRobot.getMonster3() != null && StringUtil.isNotNull(cdRobot.getMonster3())) {
                    strb.append(cdRobot.getMonster3()).append(",");
                }
                if (cdRobot.getMonster4() != null && StringUtil.isNotNull(cdRobot.getMonster4())) {
                    strb.append(cdRobot.getMonster4()).append(",");
                }
                if (cdRobot.getMonster5() != null && StringUtil.isNotNull(cdRobot.getMonster5())) {
                    strb.append(cdRobot.getMonster5()).append(",");
                }
                if (cdRobot.getMonster6() != null && StringUtil.isNotNull(cdRobot.getMonster6())) {
                    strb.append(cdRobot.getMonster6()).append(",");
                }
                if (cdRobot.getMonster7() != null && StringUtil.isNotNull(cdRobot.getMonster7())) {
                    strb.append(cdRobot.getMonster7()).append(",");
                }
                String n_strb = strb.substring(0, strb.length() - 1);
                String[] array = n_strb.split(",");

                for (int k = 0; k < cdRobot.getNumber(); k++) {
                    List<Integer> disLt = randomizeInPlace2(array);
                    RobotVo rvo = new RobotVo();
                    rvo.setBabyLv(getRandomNum(cdRobot.getBabyLv()));
                    rvo.setLv(cdRobot.getLv());
                    String n1 = (String) nlt1.get((int) (Math.random() * nlt1.size()));
                    String n2 = (String) nlt2.get((int) (Math.random() * nlt2.size()));
                    String n3 = (String) nlt3.get((int) (Math.random() * nlt3.size()));
                    String name = n1 + n2 + n3;
                    rvo.setName(name.trim());
                    rvo.setDisLt(disLt);
                    Integer id = (cdRobot.getId() + 10) * 100 + k;
                    rvo.setUserId(id);
                    robot_map.put(id, rvo);
                    if (k < cdRobot.getNum()) {
                        robot_num_lt2.add(rvo);
                    }
                    putUserPicture(id, name, cdRobot.getLv(), disLt);
                }
                robot_map2.put(cdRobot.getLv(), robot_num_lt2);
            }
            ch.putObjectToCache(CacheNames.ROBOT_DATA_CACHE, ElementKeys.ROBOT_KEY, robot_map);
            ch.putObjectToCache(CacheNames.ROBOT_DATA_CACHE, ElementKeys.ROBOT_BROKEN_KEY, robot_map2);
            System.out.println("robot_map-------------------------" + robot_map.size());
            System.out.println("robot_map2-------------------------" + robot_map2.size());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    private int getRandomNum(int lv) {
        if (lv < 4) {
            return lv;
        }
        int[] is = new int[]{-3, -2, -1, 0, 1, 2, 3};
        int z = (int) (Math.random() * (is.length - 1));

        return lv + is[z];
    }

    private String randomizeInPlace(String[] data) {
        Random random = new Random(DateUtil.getCurrentDate().getTime());
        int len = data.length;
        for (int i = 0; i < len; i++) {
            int pos = (int) (random.nextDouble() * (len - i + 1) + i) - 1;
            System.out.println("i-------------" + i + "-----------pos:" + pos + "-----------(len - i + 1) + i) - 1:" + (((len - i + 1) + i) - 1));
            String temp = data[i];
            data[i] = data[pos];
            data[pos] = temp;
        }

        StringBuilder strb = new StringBuilder();
        for (int i = 0; i < data.length; i++) {
            strb.append(data[i]);
            if (i != data.length - 1) {
                strb.append(",");
            }
        }
        return strb.toString();
    }

    private static List<Integer> randomizeInPlace2(String[] data) {
        List<String> l1 = new ArrayList<String>();
        List<Integer> l2 = new ArrayList<Integer>();
        for (int i = 0; i < data.length; i++) {
            l1.add(data[i]);
        }
        while (!l1.isEmpty()) {
            int pos = (1 + (int) (Math.random() * l1.size()) - 1);
            l2.add(Integer.parseInt((String) l1.get(pos)));
            l1.remove(pos);
        }

        return l2;
    }
    //便利用户头像数据并存储至内存

    private void putUserPicture(int userId, String mpName, int level, List<Integer> linueups) throws Exception {
        try {
            UserPictureVo picvo = null;
            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, userId);
            if (obj != null) {
                picvo = (UserPictureVo) obj;
            } else {
                picvo = new UserPictureVo();
                picvo.setName(mpName);
                picvo.setLevel(level);
            }
            for (Integer str : linueups) {
                picvo.getDisCodeIds().add(str);
            }
            ch.putObjectToCache(CacheNames.USER_PICTURE_DATA_CACHE, userId, picvo);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void updateCacheDate(String type) throws Exception {
        startService.load(type);
    }
}
