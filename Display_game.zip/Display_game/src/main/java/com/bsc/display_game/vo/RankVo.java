/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.vo;

import com.bsc.util.list.BSCLinkedMap;

/**
 *
 * @author lxf
 */
public class RankVo implements java.io.Serializable {
    private int userId;//用户
    private long startTime;//当前位置的开始时间
    private BSCLinkedMap map = new BSCLinkedMap(5);//打过我的人列表
    private int site;//排行位置
    private int attackNum;//用户供给次数
    private String awardData;//用户获奖数据
    private int score;//积分
    
    
    
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public BSCLinkedMap getMap() {
        return map;
    }

    public void setMap(BSCLinkedMap map) {
        this.map = map;
    }

    public int getSite() {
        return site;
    }

    public void setSite(int site) {
        this.site = site;
    }
    public String getAwardData() {
        return awardData;
    }

    public void setAwardData(String awardData) {
        this.awardData = awardData;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getAttackNum() {
        return attackNum;
    }

    public void setAttackNum(int attackNum) {
        this.attackNum = attackNum;
    }
    
    
    
    
    
}
