/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.clinet.command.response.CJAchieveData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdChongzhi;
import com.bsc.protracted.domin.CmMpOtherData;
import com.bsc.recharge.bo.GameRechargeAppBo;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GameRechargeBo extends DaosPublic {

    private static final Logger log = LoggerFactory.getLogger(GameRechargeBo.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private PackageBo packageBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private GameRechargeAppBo gameRechargeAppBo;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private AchieveBo achieveBo;

    public RPChangeData rechage(String key, int userId, Integer rechangeId) throws Exception {
        try {
            RPChangeData change = gameRechargeAppBo.rechage(key, userId, rechangeId);
            if (ErrorCodeEnum.normal_success.value().equals(change.getSt())) {
                MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(userId);
                int old_vip = vo.getMpVip();
                Map<Integer, CdChongzhi> map = (Map<Integer, CdChongzhi>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RECHARGE_KEY);
                CdChongzhi cdChongzhi = map.get(rechangeId);

                if (vo.getMpVip() < cdChongzhi.getStage()) {
//                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.mp_vip.value(), String.valueOf(cdChongzhi.getStage() - vo.getMpVip())));
//                    menPaiBo.update_vip(userId, cdChongzhi.getStage());
//                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.mp_vip.value(), String.valueOf(codeId - 140030000)));
                    //int userId, int codeId, int exp, int level 增加成就
                    AchieveVo achieveVo = achieveBo.saveAchieve(userId, 150010002, 0, cdChongzhi.getStage());
                    if (achieveVo != null) {
                        Map<String, Object> m = new HashMap<String, Object>();
                        List<CJAchieveData> lt = new ArrayList<CJAchieveData>();
                        CJAchieveData cd = new CJAchieveData();
                        cd.setId(150010002);
                        cd.setLv(achieveVo.getLv());
                        m.put(ClientMapKeyEnum.achive.value(), lt.add(cd));
                        change.setAh(m);
                    }
                }
                Map<String, CmMpOtherData> od_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);

                CmMpOtherData cmMpOtherData = od_map.get("recharge_all_num");
                int num = Integer.parseInt(cmMpOtherData.getDataValue().split(":")[0]);
                int all_money = Integer.parseInt(cmMpOtherData.getDataValue().split(":")[1]);
                if (num == 1) {
                    CdChongzhi first_cz = map.get(0);
                    change = packageBo.open_package(userId, null, first_cz.getPacks(), 0, change);
                }
                if (cdChongzhi.getPacks() != 0) {
                    change = packageBo.open_package(userId, null, cdChongzhi.getPacks(), 0, change);
                }

                String vips = "1:10,2:40,3:50,4:100,5:200,6:500,7:1000,8:2000,9:5000,10:10000,11:15000,12:30000";
                String[] vip_array = vips.split(",");
                int a = 0;
                int b = -1000000;
                for (String s : vip_array) {
                    int vip = Integer.parseInt(s.split(":")[0]);
                    int money = Integer.parseInt(s.split(":")[1]);
                    if (all_money - money > 0 && money - all_money >= b) {
                        b = money - all_money;
                        a = vip;
                    }
                }
                if (a > vo.getMpVip()) {
                    menPaiBo.update_vip(userId, a);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.mp_vip.value(), String.valueOf(vo.getMpVip() - old_vip)));
                }
            }
            return change;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
