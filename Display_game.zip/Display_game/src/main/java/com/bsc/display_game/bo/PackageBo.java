/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.BrokenBo;
import com.bsc.commonproject.bo.DisCommonBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.CardTypeEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.PropConstants;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdBaby;
import com.bsc.protracted.domin.CdBox;
import com.bsc.protracted.domin.CdEquip;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CdPackageReward;
import com.bsc.protracted.domin.CdSkillcfg;
import com.bsc.protracted.domin.CmMpOtherData;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.random.server.RandomUtilService;
import com.bsc.random.vo.RandItem;
import com.bsc.random.vo.RandOnlyItem;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class PackageBo extends DaosPublic {

    @Resource
    private PropBo propBo;
    @Resource
    private AddCardBo addCardBo;
    @Resource
    private CacheHandler ch;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private RandomUtilService randomUtilService;
    @Resource
    private DisCommonBo disCommonBo;
    @Resource
    private BrokenBo brokenBo;
    private static final Logger log = LoggerFactory.getLogger(PackageBo.class);
    private final String BUY_BOX_AND_KEY_MOENY = "BUY_BOX_AND_KEY_MOENY";
    private final String CONSUM_BOX_MONEY = "CONSUM_BOX_MONEY";
    private final String CONSUM_BOX_ALL_MOEY = "CONSUM_BOX_ALL_MOEY";

    public RPChangeData open_package(int userId, CmMpProps prop, int packageCodeId, int num, RPChangeData change) throws Exception {
        try {
            Map<Integer, List<CdPackageReward>> CdPackageReward_map = (Map<Integer, List<CdPackageReward>>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.PACKAGE_REWARD_KEY);
//            CmMpProps package_prop = propBo.getCmMpPropsFromCacheBycardId(userId, packageId);
//            if(package_prop == null){
//                change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
//                return change;
//            }
            
            List<CdPackageReward> lt = CdPackageReward_map.get(packageCodeId);
            if (lt == null || lt.isEmpty()) {
                change.setSt("package no prop");
                return change;
            }
            if (prop != null) {
                //消耗道具
                change = consum_prop(prop, change, userId);
            }
            if (num == 0) {//箱子全部获得
                //增加道具
                for (CdPackageReward pr : lt) {
                    change = addCardBo.addAllGoods(userId, pr.getRewardId(), pr.getRewardNum(), pr.getRewardLv(), null, change);
                }
            } else {//获得箱子中随机的物品
                int all_rate = 0;
                List lt2 = new ArrayList();
                for (CdPackageReward pr : lt) {
                    all_rate = all_rate + pr.getRewardWeight();
                    lt2.add(new RandItem(pr, pr.getRewardWeight()));
                }
                List<RandOnlyItem> rits = randomUtilService.randomMultiDiffItem(lt2, all_rate, num);
                for (RandOnlyItem ri : rits) {
                    CdPackageReward pr = (CdPackageReward) ri.getItem();
                    change = addCardBo.addAllGoods(userId, pr.getItemId(), pr.getRewardLv(), 1, null, change);
                }
            }
            change.setSt(ErrorCodeEnum.normal_success.value());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    public RPChangeData open_box(int userId, CmMpProps prop, RPChangeData change) throws Exception {
        try {
            int keyCodeID = getKeyCodeIdFromPackageCodeId(prop.getPropId());
            if (keyCodeID == 0) {
                change.setSt("key error");
                return change;
            }
            //判定钥匙是否存在
            CmMpProps prop_key = propBo.getCmMpPropsFromCacheBycodeId(userId, keyCodeID);
            if (prop_key == null) {
                change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
                return change;
            }
            //判断产出类别
            int box_type = box_type(userId, prop.getPropId());
            if (box_type == 0) {
                change.setSt("data error");
                return change;
            }
            CdBox box = null;
            boolean is_clean_gold = false;
            //需要消耗的金币
            if (box_type == 1 || box_type == 3) {
                //开箱子的总钱数
                int concum_money = getBoxGold(userId, CONSUM_BOX_MONEY);
                //奖励上线
                //达到消耗上线，赠送7列表的随机物品
                if (getMessValue(3000) <= concum_money && getMessValue(8000) > concum_money ) {
                    if (PropConstants.JINDING_CODE_ID == prop.getPropId()) {
                        box = getreward(8);
                    } else if (PropConstants.YINPEN_CODE_ID == prop.getPropId()) {
                        box = getreward(9);
                    }
                    is_clean_gold = true;
                } else if (concum_money >= getMessValue(8000)) {
                    box = getreward(7);
                    //清空金币上线
                    is_clean_gold = true;
                }
                //修改奖金池的数据
                save_box_open_gold(userId, prop.getPropId(), getMessValue(prop.getPropId()));
            }
            if (box == null) {
                //随机出现的物品
                box = getreward(box_type);
            }
            if (box == null) {
                change.setSt("random error");
                return change;
            }
            //增加道具
            change = addCardBo.addAllGoods(userId, box.getItem(), box.getNum(), 1, null, change);
            //固定上限并且是甲级装备，清空奖金池
            if (is_clean_gold&& getGoodsPZ(box.getItem()) == 4&&mpcommonBo.getTableFromCodeId(box.getItem())==CardTypeEnum.EQUIP_CARD_TYPE.value()) {
                clean_buy_gold(userId);
            }
            //消耗道具,扣除箱子
            change = consum_prop(prop, change, userId);
            //扣除钥匙
            change = consum_prop(prop_key, change, userId);
            change.setSt(ErrorCodeEnum.normal_success.value());

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    //扣除道具
    public RPChangeData consum_prop(CmMpProps prop, RPChangeData change, int userId) throws Exception {
        try {
            if (prop.getPropNum() - 1 <= 0) {
                Map cmMpProps_map = (Map) ch.getObjectFromCache(CacheNames.USER_PROP_CACHE, userId);
                //删除数据库
                delete(prop);
                //删除内存
                cmMpProps_map.remove(prop.getMpPropId());
                change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), 0, Constants.DEFUALT_NULL, CardStatusEnum.del.value()));
                ch.putObjectToCache(CacheNames.USER_PROP_CACHE, userId, cmMpProps_map);
            } else {
                //消耗一个道具
                CmMpProps p = propBo.consumProp(userId, prop.getMpPropId(), 1);
                change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), p.getPropNum(), Constants.DEFUALT_NULL, CardStatusEnum.add.value()));
            }

            return change;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

//判断箱子的产出类型
    private int box_type(int userId, int codeId) throws Exception {
        try {
            if (PropConstants.JINDING_CODE_ID == codeId) {
                //买箱子钥匙花费的钱数
                int buy_box_money = getBoxGold(userId, BUY_BOX_AND_KEY_MOENY);
                //查找开箱子需要消耗的钱数
                int less_reward = getMessValue(codeId);
                if (buy_box_money - less_reward >= 0) {
                    return 1;
                } else {
                    return 2;
                }
            } else if (PropConstants.YINPEN_CODE_ID == codeId) {
                //买箱子钥匙花费的钱数
                int buy_box_money = getBoxGold(userId, BUY_BOX_AND_KEY_MOENY);
                //查找开箱子需要消耗的钱数
                int less_reward = getMessValue(codeId);
                if (buy_box_money - less_reward >= 0) {
                    return 3;
                } else {
                    return 4;
                }
            } else if (PropConstants.TONGXIANG_CODE_ID == codeId) {
                return 5;
            } else if (PropConstants.MUHE_CODE_ID == codeId) {
                return 6;
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }

        return 0;
    }
    //获取数据数据

    public CdBox getreward(int type) throws Exception {
        try {
            Map<Integer, List<CdBox>> CdBox_map = (Map<Integer, List<CdBox>>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.BOX_KEY);
            Object obj = CdBox_map.get(type);
            if (obj != null) {
                List<CdBox> boxlt = (List<CdBox>) obj;
                List lt = new ArrayList();
                int all_rate = 0;
                for (CdBox box : boxlt) {
                    all_rate = all_rate + box.getChance();
                    lt.add(new RandItem(box, box.getChance()));
                }
                RandItem rit = randomUtilService.getRandItem(lt, all_rate);
                if (rit != null) {
                    return (CdBox) rit.getItem();
                }
            }
            return null;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //存储用户打开箱子需要想要的金币
    public void save_box_open_gold(int userId, int codeId, int gold) throws Exception {
        try {
            if (is_save_box_gold(codeId)) {
                Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
                if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                    cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
                }
                //增加金币池
                Object money_obj = cmMpOtherData_map.get(CONSUM_BOX_MONEY);
                CmMpOtherData CmMpOtherData_money = null;
                if (money_obj != null) {
                    CmMpOtherData_money = (CmMpOtherData) money_obj;
                    CmMpOtherData_money.setDataValue(String.valueOf(Integer.parseInt(CmMpOtherData_money.getDataValue()) + gold));
                } else {
                    CmMpOtherData_money = new CmMpOtherData();
                    CmMpOtherData_money.setDataKey(CONSUM_BOX_MONEY);
                    CmMpOtherData_money.setDataValue(String.valueOf(gold));
                    CmMpOtherData_money.setUserId(userId);
                    int dataId = save(CmMpOtherData_money);
                    CmMpOtherData_money.setDataId(dataId);
                }
                //增加总金币池
                Object all_money_obj = cmMpOtherData_map.get(CONSUM_BOX_ALL_MOEY);
                CmMpOtherData CmMpOtherData_all_money = null;
                if (all_money_obj != null) {
                    CmMpOtherData_all_money = (CmMpOtherData) all_money_obj;
                    CmMpOtherData_all_money.setDataValue(String.valueOf(Integer.parseInt(CmMpOtherData_all_money.getDataValue()) + gold));
                } else {
                    CmMpOtherData_all_money = new CmMpOtherData();
                    CmMpOtherData_all_money.setDataKey(CONSUM_BOX_ALL_MOEY);
                    CmMpOtherData_all_money.setDataValue(String.valueOf(gold));
                    CmMpOtherData_all_money.setUserId(userId);
                }
                //消耗金币池
                Object counsm_obj = cmMpOtherData_map.get(BUY_BOX_AND_KEY_MOENY);
                CmMpOtherData CmMpOtherData_consum= null;
                if(counsm_obj !=null){
                    CmMpOtherData_consum = (CmMpOtherData) counsm_obj;
                }else{
                    CmMpOtherData_consum = new CmMpOtherData();
                    CmMpOtherData_consum.setDataKey(BUY_BOX_AND_KEY_MOENY);
                    CmMpOtherData_consum.setDataValue("0");
                    CmMpOtherData_consum.setUserId(userId);
                }
                CmMpOtherData_consum.setDataValue(String.valueOf(Integer.parseInt(CmMpOtherData_consum.getDataValue()) - gold));

                cmMpOtherData_map.put(BUY_BOX_AND_KEY_MOENY, CmMpOtherData_consum);
                cmMpOtherData_map.put(CONSUM_BOX_MONEY, CmMpOtherData_money);
                cmMpOtherData_map.put(CONSUM_BOX_ALL_MOEY, CmMpOtherData_all_money);
                ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //存储用户购买箱子消耗的金币
    public void save_box_buy_gold(int userId, int codeId, int num) throws Exception {
        try {
            int consum_gold = getMessValue(codeId);
            if (consum_gold != 0) {
                Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
                if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                    cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
                }
                Object all_money_obj = cmMpOtherData_map.get(BUY_BOX_AND_KEY_MOENY);
                CmMpOtherData CmMpOtherData_charge_num = null;
                if (all_money_obj != null) {
                    CmMpOtherData_charge_num = (CmMpOtherData) all_money_obj;
                    CmMpOtherData_charge_num.setDataValue(String.valueOf(Integer.parseInt(CmMpOtherData_charge_num.getDataValue()) + consum_gold*num));
                } else {
                    CmMpOtherData_charge_num = new CmMpOtherData();
                    CmMpOtherData_charge_num.setDataKey(BUY_BOX_AND_KEY_MOENY);
                    CmMpOtherData_charge_num.setDataValue(String.valueOf(consum_gold*num));
                    CmMpOtherData_charge_num.setUserId(userId);
                    int dataId = save(CmMpOtherData_charge_num);
                    CmMpOtherData_charge_num.setDataId(dataId);
                }
                cmMpOtherData_map.put(BUY_BOX_AND_KEY_MOENY, CmMpOtherData_charge_num);
                ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //清空指定金额的金币

    public void clean_buy_gold(int userId) throws Exception {
        try {

            Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
            Object all_money_obj = cmMpOtherData_map.get(CONSUM_BOX_MONEY);
            CmMpOtherData CmMpOtherData_charge_num = (CmMpOtherData) all_money_obj;
            CmMpOtherData_charge_num.setDataValue(String.valueOf(0));
            cmMpOtherData_map.put(CONSUM_BOX_MONEY, CmMpOtherData_charge_num);
            ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //查找奖金池数据

    private int getBoxGold(int userId, String key) throws Exception {
        try {
            Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
            if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
            }
            Object all_money_obj = cmMpOtherData_map.get(key);
            if (all_money_obj != null) {
                CmMpOtherData cmMpOtherData = (CmMpOtherData) all_money_obj;
                return Integer.parseInt(cmMpOtherData.getDataValue());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return 8000;
    }
    //判断是否增加奖金池

    private boolean is_save_box_gold(int codeId) {
        if (PropConstants.JINYAOSHI_CODE_ID == codeId//金钥匙
                || PropConstants.YINYAOSHI_CODE_ID == codeId//银钥匙
                || PropConstants.TONGYAOSHI_CODE_ID == codeId //铜钥匙
                || PropConstants.MUYAOSHI_CODE_ID == codeId//木钥匙
                || PropConstants.JINDING_CODE_ID == codeId//金宝箱
                || PropConstants.YINPEN_CODE_ID == codeId//银宝箱
                || PropConstants.TONGXIANG_CODE_ID == codeId//铜宝箱
                || PropConstants.MUHE_CODE_ID == codeId //木宝箱
                ) {
            return true;
        }
        return false;
    }
    //判断是否为打开箱子

    public boolean is_box(int codeId) {
        if (PropConstants.JINDING_CODE_ID == codeId//金宝箱
                || PropConstants.YINPEN_CODE_ID == codeId//银宝箱
                || PropConstants.TONGXIANG_CODE_ID == codeId//铜宝箱
                || PropConstants.MUHE_CODE_ID == codeId //木宝箱
                ) {
            return true;
        }
        return false;
    }
    //查找钥匙codeId

    private int getKeyCodeIdFromPackageCodeId(int codeId) {
        switch (codeId) {
            case PropConstants.JINDING_CODE_ID://金箱子
                return PropConstants.JINYAOSHI_CODE_ID;
            case PropConstants.YINPEN_CODE_ID://银箱子
                return PropConstants.YINYAOSHI_CODE_ID;
            case PropConstants.TONGXIANG_CODE_ID://铜箱子
                return PropConstants.TONGYAOSHI_CODE_ID;
            case PropConstants.MUHE_CODE_ID://木箱子
                return PropConstants.MUYAOSHI_CODE_ID;
        }
        return 0;
    }

//查找杂表配置值
    private int getMessValue(int codeId) {
        Map<String, CdMessyData> CdMessyData_map = (Map<String, CdMessyData>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
        String key = null;
        if (PropConstants.JINDING_CODE_ID == codeId) {//金宝箱
            key = "gold_box";
        } else if (PropConstants.YINPEN_CODE_ID == codeId) {//银宝箱
            key = "silver_box";
        } else if (codeId == 8000) {//获奖上线
            key = "max_box";
        } else if (codeId == 3000) {//获奖上线
            key = "max_box2";
        }
        if (key != null && CdMessyData_map != null && CdMessyData_map.get(key) != null) {
            CdMessyData cd = (CdMessyData) CdMessyData_map.get(key);
            return Integer.parseInt(cd.getMessyValue().trim());
        }
        return 0;
    }

    public int getGoodsPZ(int codeId) {
        if (CardTypeEnum.DISCIPLE_CARD_TYPE.value() == mpcommonBo.getTableFromCodeId(codeId)) {
            Map<Integer, CdBaby> baby_map = (Map<Integer, CdBaby>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
            CdBaby b = baby_map.get(codeId);
            return b.getPz();
        } else if (CardTypeEnum.EQUIP_CARD_TYPE.value() == mpcommonBo.getTableFromCodeId(codeId)) {
            Map<Integer, CdEquip> equipt_map = (Map<Integer, CdEquip>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.EQUIP_KEY);
            CdEquip e = equipt_map.get(codeId);
            return e.getPz();
        } else if (CardTypeEnum.GEST_CARD_TYPE.value() == mpcommonBo.getTableFromCodeId(codeId)) {
            Map<Integer, CdSkillcfg> cdSkillcfg_map = (Map<Integer, CdSkillcfg>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.SKILLCFG_KEY);
            CdSkillcfg k = cdSkillcfg_map.get(codeId);
            return k.getPz();
        } else if (CardTypeEnum.PROP_CARD_TYPE.value() == mpcommonBo.getTableFromCodeId(codeId)) {
            return 0;
        } else if (CardTypeEnum.SOUL_CARD_TYPE.value() == mpcommonBo.getTableFromCodeId(codeId)) {
            Map<Integer, CdBaby> baby_map = (Map<Integer, CdBaby>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
            CdBaby b = baby_map.get(disCommonBo.getDiscipleIdFromSoulId(codeId));
            return b.getPz();
        } else if (CardTypeEnum.BROKEN_CARD_TYPE.value() == mpcommonBo.getTableFromCodeId(codeId)) {
            Map<Integer, CdSkillcfg> cdSkillcfg_map = (Map<Integer, CdSkillcfg>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.SKILLCFG_KEY);
            CdSkillcfg k = cdSkillcfg_map.get(codeId);
            return k.getPz();
        }
        return 0;
    }
}
