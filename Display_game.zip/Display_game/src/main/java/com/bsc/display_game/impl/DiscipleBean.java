/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.DisCommonBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.GameConstants;
import com.bsc.commonproject.constants.MapKeyConstants;
import com.bsc.commonproject.constants.PropConstants;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.bo.DiscipleBo;
import com.bsc.display_game.constants.CstateConstants;
import com.bsc.display_game.constants.DataConstants;
import com.bsc.display_game.request.RecruitDisRQ;
import com.bsc.display_game.request.TrainConfirmRQ;
import com.bsc.display_game.request.TrainRQ;
import com.bsc.display_game.request.TransferRQ;
import com.bsc.display_game.request.TuPoRQ;
import com.bsc.display_game.service.DiscipleService;
import com.bsc.displaybases.SuperAction;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdBaby;
import com.bsc.protracted.domin.CdFormula;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpDiscipleSoul;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.random.impl.RandFuncationBean;
import com.bsc.random.vo.CdNatures;
import com.bsc.random.vo.DisDevPair;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;

import com.bsc.util.json.JsonHelper;
import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class DiscipleBean extends DaosPublic implements DiscipleService {

    private static final Logger log = LoggerFactory.getLogger(MenPaiBean.class);
    @Resource
    private DiscipleBo discipleBo;
    @Resource
    private AddCardBo addPropBo;
    @Resource
    private CacheHandler ch;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private DisCommonBo disCommonBo;
    @Resource
    private RandFuncationBean randFuncationBean;
    @Resource
    private PropBo propBo;
    @Resource
    private SaveLogBo saveLogBo;
    @Resource
    private RandFuncationBean rfBean;

    /**
     * 弟子招募
     */
    public void recruit(SuperAction sa) throws Exception {
        try {
            try {
                RPChangeData change = new RPChangeData();
                String json = sa.getRequestJson();
                RecruitDisRQ ecruitDisRQ = (RecruitDisRQ) JsonHelper.getBeanFromJson(json, RecruitDisRQ.class);
                int userId = ecruitDisRQ.getUserid();
                int soulid = ecruitDisRQ.getSoulid();
                //验证该魂魄是否存在，并且是否符合基本条件
                CmMpDiscipleSoul cmMpDiscipleSoul = discipleBo.getCmMpDiscipleSoulFromCache(userId, soulid);
                if (cmMpDiscipleSoul != null) {
                    //验证个数是否符合
                    Map cmMpDiscipleSoul_map = (Map) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId);
                    //验证用户是否含有该弟子
                    CmMpDisciple cmMpDisciple = addPropBo.IsHaveDisciple(userId, disCommonBo.getDiscipleIdFromSoulId(cmMpDiscipleSoul.getDiscipleId()));
                    if (cmMpDisciple == null) {
                        //查找弟子招募需要的魂魄数
                        int soul_num = discipleBo.getCdRecruitValue(disCommonBo.getDiscipleIdFromSoulId(cmMpDiscipleSoul.getDiscipleId()), MapKeyConstants.RECRUIT_CONSUME_NUM);
                        //验证魂魄是否够如破
                        int over_soul_num = cmMpDiscipleSoul.getSoulNum() - soul_num;
                        if (over_soul_num >= 0) {
                            //新增弟子和武功
                            cmMpDisciple = addPropBo.getCmMpDisciple(userId, disCommonBo.getDiscipleIdFromSoulId(cmMpDiscipleSoul.getDiscipleId()),GameConstants.DEFALUT_LEVEL);
                            //封装弟子卡牌
                            change.getCv().getCc().add(PackageCardBo.getDicCard(cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), cmMpDisciple.getDisLevel(), cmMpDisciple.getAllExp(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                            //封装武功卡牌
                            change.getCv().getCc().add(PackageCardBo.getGestCard(cmMpDisciple.getCmMpGest().getMpGestId(), cmMpDisciple.getCmMpGest().getGestId(), cmMpDisciple.getCmMpGest().getGestLevel(), CardStatusEnum.add.value()));
                            //魂魄数
                            change.getCv().getCc().add(PackageCardBo.getSoulCard(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul.getDiscipleId(), over_soul_num, CardStatusEnum.add.value()));
                            if (over_soul_num <= 0) {
                                //删除数据库
                                delete(cmMpDiscipleSoul);
                                //删除内存
                                cmMpDiscipleSoul_map.remove(cmMpDiscipleSoul.getSoulId());
                            } else {
                                cmMpDiscipleSoul.setSoulNum(over_soul_num);
                                cmMpDiscipleSoul_map.put(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul);
                            }
                            //更新内存----->魂魄
                            ch.putObjectToCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId, cmMpDiscipleSoul_map);
                            change.setSt(ErrorCodeEnum.normal_success.value());
                        } else {
                            change.setSt(CstateConstants.ZHAOMU_SOUL_NUM_NO);
                        }
                    } else {
                        change.setSt(CstateConstants.ZHAOMU_DISCIPLE_NO);
                    }
                } else {
                    change.setSt(CstateConstants.ZHAOMU_SOUL_NO);
                }
                sa.setResponseJson(JsonHelper.getJsonFromBean(change));
                sa.getSend().sendDataToClient(sa, true, true);
            } catch (Exception e) {
                log.error(LogHelper.getException(e));
                throw e;
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
//弟子之间传功

    public void transfer(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String transfer_disciple_json = sa.getRequestJson();
            TransferRQ transferRQ = (TransferRQ) JsonHelper.getBeanFromJson(transfer_disciple_json, TransferRQ.class);
            int userId = transferRQ.getUserid();
            int goaldid = transferRQ.getCardId();
            List<Integer> dids = transferRQ.getCardIds();
            int propid = transferRQ.getPropid();
            CmMpDisciple goalCmMpDisciple = disCommonBo.getCmMpDiscipleFromCache(userId, goaldid);
            Map cmMpDisciples_map = (Map) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
            Map geest_map = (Map) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
            int dle_num = 0;
            for (Integer ProptegeIDs : dids) {
                if (disCommonBo.find_battle_disciple(userId, ProptegeIDs)) {
                    dle_num++;
                }
            }
            if (dle_num == dids.size()) {

                if (goalCmMpDisciple != null) {
                    Map<Integer, CmMpProps> cmMpProps_map = (Map<Integer, CmMpProps>) ch.getObjectFromCache(CacheNames.USER_PROP_CACHE, userId);
                    CmMpProps cmMpProps = cmMpProps_map.get(propid);
                    if (cmMpProps != null && cmMpProps.getPropNum() > 0) {
                        Map prop_map = (Map) ch.getObjectFromCache(CacheNames.USER_PROP_CACHE, userId);
                        int all_exp = 0;
                        for (Integer ProptegeIDs : dids) {
                            CmMpDisciple delCmMpDisciple = disCommonBo.getCmMpDiscipleFromCache(userId, ProptegeIDs);
                            //计算折扣后的经验
                            all_exp = all_exp + delCmMpDisciple.getAllExp();

                            CmMpGest gest = delCmMpDisciple.getCmMpGest();
                            geest_map.remove(gest.getMpGestId());
                            //封装返回数据
                            change.getCv().getCc().add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), CardStatusEnum.del.value()));
                            //删除数据库
                            delete(delCmMpDisciple);
                            //删除内存
                            cmMpDisciples_map.remove(ProptegeIDs);
                            //删除的卡牌
                            change.getCv().getCc().add(PackageCardBo.getDicCard(delCmMpDisciple.getMpDisId(), delCmMpDisciple.getDiscipleId(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, CardStatusEnum.del.value(), delCmMpDisciple.getGestId()));
                        }
                        //扣除道具
                        cmMpProps.setPropNum(cmMpProps.getPropNum() - 1);
                        //减少的丹药
//                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(String.valueOf(cmMpProps.getMpPropId()), String.valueOf(cmMpProps.getPropNum() - 1)));
                        change.getCv().getCc().add(PackageCardBo.getPropCard(cmMpProps.getMpPropId(), cmMpProps.getPropId(), cmMpProps.getPropNum(), cmMpProps.getPropLv(), CardStatusEnum.add.value()));
                        //判断是否为非秘制丹药
                        all_exp = Tools.getNumberToInt(all_exp * propBo.getPropAttach(cmMpProps.getPropId()));
//                    int[] dis_data = discipleBo.getallExpToLevel(all_exp, goalCmMpDisciple.getDiscipleId());

                        List<Integer> lt = new ArrayList<Integer>();
                        lt.add(goalCmMpDisciple.getMpDisId());
                        List<CmMpDisciple> dis_lt = disCommonBo.disciple_exp(userId, lt, all_exp);
                        if (dis_lt != null&&!dis_lt.isEmpty()) {
                            CmMpDisciple dis = dis_lt.get(0);
                            //更新弟子的经验和等级
                            change.getCv().getCc().add(PackageCardBo.getDicCard(dis.getMpDisId(), dis.getDiscipleId(), dis.getDisLevel(), dis.getDisExp(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, CardStatusEnum.add.value(), Constants.DEFUALT_NULL));
                        }

                        //更新新的经验
//                    goalCmMpDisciple.setAllExp(goalCmMpDisciple.getAllExp() + all_exp);
//                    goalCmMpDisciple.setDisLevel(dis_data[0]);
//                    goalCmMpDisciple.setDisExp(dis_data[1]);
//                    //更新弟子cache
//                    cmMpDisciples_map.put(goalCmMpDisciple.getMpDisId(), goalCmMpDisciple);
//                    //更新弟子的经验和等级 int cardId, int codeId,int level, int exp,int topoLv,int poten ,int state
//                    change.getCv().getCc().add(PackageCardBo.getDicCard(goalCmMpDisciple.getMpDisId(), goalCmMpDisciple.getDiscipleId(), goalCmMpDisciple.getDisLevel(), goalCmMpDisciple.getDisExp(), Constants.DEFUALT_NULL, goalCmMpDisciple.getDisPotential(), CardStatusEnum.add.value(), goalCmMpDisciple.getGestId()));
//                    ch.putObjectToCache(CacheNames.USER_DISCIPLE_CACHE, userId, cmMpDisciples_map);
                        //更新道具cache
                        prop_map.put(cmMpProps.getMpPropId(), cmMpProps);
                        ch.putObjectToCache(CacheNames.USER_PROP_CACHE, userId, cmMpProps_map);
                        ch.putObjectToCache(CacheNames.USER_GEST_CACHE, userId, geest_map);
                        change.setSt(ErrorCodeEnum.normal_success.value());
                    } else {
                        change.setSt(CstateConstants.CHUANSHOU_PEIYANGDAN_NO);
                    }
                } else {
                    change.setSt(CstateConstants.CHUANSHOU_DEL_DISCIPLE_NO);
                }
            } else {
                change.setSt(ErrorCodeEnum.up_lineup_no_delete.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
//培养

    public void train(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String train_disciple_json = sa.getRequestJson();
            TrainRQ trainRQ = (TrainRQ) JsonHelper.getBeanFromJson(train_disciple_json, TrainRQ.class);
            int userId = trainRQ.getUserid();
            int did = trainRQ.getCardId();
            int type = trainRQ.getType();
            //查找用户的培养丹
            CmMpProps cmMpProps = propBo.getCmMpPropsFromCacheBycodeId(userId, PropConstants.PEIYANGDAN_CODE_ID);
            CmMpDisciple cmMpDisciple = disCommonBo.getCmMpDiscipleFromCache(userId, did);
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (cmMpDisciple != null) {
                if (cmMpProps != null && cmMpProps.getPropNum() > 0) {
                    Map<Integer, CdFormula> formulas = (Map<Integer, CdFormula>) ch.getObjectFromCache(CacheNames.FORMULABASIC_CODE_CACHE, ElementKeys.CODE_TABLE_KEY);
                    Map<Integer, CdBaby> babys = (Map<Integer, CdBaby>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
                    CdBaby cdBaby = babys.get(cmMpDisciple.getDiscipleId());
                    //扣除用户的道具，金币或者银币
                    int silver = 0;
                    int gold = 0;
                    int peiyangdan = 1;
                    //判断培养类型
                    switch (type) {
                        case 1://普通提升1次
                            peiyangdan = 5;
                            break;
                        case 2://元宝提升一次
                            gold = 1;
                            peiyangdan = 5;
                            break;
                        case 3://普通提升10次
                            peiyangdan = 50;
                            break;
                        case 4://元宝提升10次
                            gold = 10;
                            peiyangdan = 50;
                            break;
                    }
                    //判断金币
                    if (vo.getMpGold() >= gold) {
                        //判断培养单是否够
                        if (peiyangdan != 0 && peiyangdan <= cmMpProps.getPropNum()) {
                            int atk = Constants.DEFUALT_NULL;
                            int def = Constants.DEFUALT_NULL;
                            int hp = Constants.DEFUALT_NULL;
                            int mp = Constants.DEFUALT_NULL;
                            Map<String, Integer> m = new HashMap<String, Integer>();
                            m.put("id", cmMpDisciple.getMpDisId());
                            m.put("atk", 0);
                            m.put("def", 0);
                            m.put("hp", 0);
                            m.put("mp", 0);
                            // List<DisDevPair> childDevelop(Map<Integer, CdFormula> formulas, CdBaby baby, CmMpDisciple dis, int type)
                            List<DisDevPair> vli = randFuncationBean.childDevelop(formulas, cdBaby, cmMpDisciple, type);
                            if (vli != null && !vli.isEmpty() && vli.size() > 0) {
                                int a = ((DisDevPair) vli.get(0)).value;
                                int b = ((DisDevPair) vli.get(1)).value;
//                                System.out.println(a+"------------------"+b);
                                int addProValue = Math.abs(a) + Math.abs(b);
                                int qianli_value = a;
                                if (b >= 0) {
                                    qianli_value = b;
                                }
//                                System.out.println("qianli_value--------------"+qianli_value);
                                for (DisDevPair disDevPair : vli) {
                                    if (disDevPair.nature.equals(CdNatures.atk)) {
                                        atk = disDevPair.value;
                                        if (atk >= 0) {
                                            atk = addProValue;
                                        }
                                        m.put("atk", atk);
                                    }
                                    if (disDevPair.nature.equals(CdNatures.def)) {
                                        def = disDevPair.value;
                                        if (def >= 0) {
                                            def = addProValue;
                                        }
                                        m.put("def", def);
                                    }
                                    if (disDevPair.nature.equals(CdNatures.hp)) {
                                        hp = disDevPair.value;
                                        if (hp >= 0) {
                                            hp = addProValue;
                                        }
                                        m.put("hp", hp);
                                    }
                                    if (disDevPair.nature.equals(CdNatures.mp)) {
                                        mp = disDevPair.value;
                                        if (mp >= 0) {
                                            mp = addProValue;
                                        }
                                        m.put("mp", mp);
                                    }
                                }
//                                System.out.println(atk+"--------"+def+"--------"+hp+"--------"+mp+"--------"+(cmMpDisciple.getDisPotential()-qianli_value));
                                change.getCv().getCc().add(PackageCardBo.getDicCardAll(Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, atk, def, hp, mp, cmMpDisciple.getDisPotential()-qianli_value, cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                                if (silver != 0) {
                                    //修改用户银币
                                    mpcommonBo.consum_silver(userId, silver);
                                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(-silver)));
                                } else if (gold != 0) {
                                    //修改元宝
                                    mpcommonBo.consum_gold(userId, gold);
                                    saveLogBo.gold(ControlType.ROLE_DEVELOP, userId, vo.getMpName(), vo.getMpGold(), -gold, "train");
                                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(-gold)));
                                }
                                //修改用户的培养丹个数
                                CmMpProps prop = propBo.consumProp(userId, cmMpProps.getMpPropId(), peiyangdan);
                                change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), prop.getPropNum(), prop.getPropLv(), CardStatusEnum.add.value()));
//                                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.qianli.value(), String.valueOf(-qianli_value)));
                                //修改弟子数据
                                //查找对应品质增加的潜力值
                                m.put("qianli", qianli_value);
//                            cmMpDisciple.setDisPotential(cmMpDisciple.getDisPotential() - qianli_value);
                                ch.putObjectToCache(CacheNames.USER_TEMP_CACHE, userId + "_peiyang", m);
                                change.setSt(ErrorCodeEnum.normal_success.value());
//                                } else {
//                                    change.setSt(ErrorCodeEnum.qianli_not_enough.value());
//                                }
                            } else {
                                change.setSt(ErrorCodeEnum.random_error.value());
                            }
                        } else {
                            change.setSt(CstateConstants.TISHENG_PROP_NO);
                        }
                    } else {
                        change.setSt(CstateConstants.TISHENG_GOLD_NO);
                    }
                } else {
                    change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
                }
            } else {
                change.setSt(CstateConstants.TISHENG_DISCIPLE_NO);
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //培养确定

    public void train_confirm(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String confim_disciple_json = sa.getRequestJson();
            TrainConfirmRQ trainConfirmRQ = (TrainConfirmRQ) JsonHelper.getBeanFromJson(confim_disciple_json, TrainConfirmRQ.class);
            int userId = trainConfirmRQ.getUserid();
            String result = trainConfirmRQ.getReslut();
            Object obj = ch.getObjectFromCache(CacheNames.USER_TEMP_CACHE, userId + "_peiyang");
            if (obj != null) {
                if (DataConstants.DEFUL_CONFIRM_YES.equals(result)) {
                    Map<String, Integer> change_map = (Map<String, Integer>) obj;
                    //修改弟子潜力值
                    Map<Integer, CmMpDisciple> cmMpDisciples_map = (Map<Integer, CmMpDisciple>) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
                    CmMpDisciple old_cmMpDisciple = cmMpDisciples_map.get(change_map.get("id"));
                    if (old_cmMpDisciple != null) {
                        int atk = Constants.DEFUALT_NULL;
                        int def = Constants.DEFUALT_NULL;
                        int hp = Constants.DEFUALT_NULL;
                        int mp = Constants.DEFUALT_NULL;
                        int atk1 = Constants.DEFUALT_NULL;
                        int def1 = Constants.DEFUALT_NULL;
                        int hp1 = Constants.DEFUALT_NULL;
                        int mp1 = Constants.DEFUALT_NULL;
                        int qianli = change_map.get("qianli");
                        if (change_map.get("atk") != 0) {
                            atk1 = change_map.get("atk");
                            atk = old_cmMpDisciple.getDisAtk() + change_map.get("atk");
                            old_cmMpDisciple.setDisAtk(atk);
                        }
                        if (change_map.get("def") != 0) {
                            def1 = change_map.get("def");
                            def = old_cmMpDisciple.getDisDef() + change_map.get("def");
                            old_cmMpDisciple.setDisDef(def);
                        }
                        if (change_map.get("hp") != 0) {
                            hp1 = change_map.get("hp");
                            hp = old_cmMpDisciple.getDisHp() + change_map.get("hp");
                            old_cmMpDisciple.setDisHp(hp);
                        }
                        if (change_map.get("mp") != 0) {
                            mp1 = change_map.get("mp");
                            mp = old_cmMpDisciple.getDisMp() + change_map.get("mp");
                            old_cmMpDisciple.setDisMp(mp);
                        }
                        old_cmMpDisciple.setDisPotential(old_cmMpDisciple.getDisPotential() - qianli);
                        cmMpDisciples_map.put(old_cmMpDisciple.getMpDisId(), old_cmMpDisciple);
                        change.getCv().getCc().add(PackageCardBo.getDicCardAll(Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, atk1, def1, hp1, mp1, old_cmMpDisciple.getDisPotential(), old_cmMpDisciple.getMpDisId(), old_cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), old_cmMpDisciple.getGestId()));
                        //将修改的弟子数据存回内存
                        ch.putObjectToCache(CacheNames.USER_DISCIPLE_CACHE, userId, cmMpDisciples_map);
                    }
                } else {
                    ch.delMemoryForObject(CacheNames.USER_TEMP_CACHE, userId);
                }
                //清除cache数据
//                ch.delCache(CacheNames.USER_TEMP_CACHE);
                change.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                change.setSt(ErrorCodeEnum.info_error_server_error.value());
            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    /**
     * 弟子突破
     */
    public void tuPo(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String upgrade_disciple_json = sa.getRequestJson();
            TuPoRQ tuPoRQ = (TuPoRQ) JsonHelper.getBeanFromJson(upgrade_disciple_json, TuPoRQ.class);
            int userId = tuPoRQ.getUserid();
            int soulid = tuPoRQ.getSoulid();
            //验证该魂魄是否存在，并且是否符合基本条件
            CmMpDiscipleSoul cmMpDiscipleSoul = discipleBo.getCmMpDiscipleSoulFromCache(userId, soulid);
            if (cmMpDiscipleSoul != null) {
                //验证个数是否符合
                Map cmMpDiscipleSoul_map = (Map) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId);
                //查找突破弟子
                CmMpDisciple cmMpDisciple = addPropBo.IsHaveDisciple(userId, disCommonBo.getDiscipleIdFromSoulId(cmMpDiscipleSoul.getDiscipleId()));
                if (cmMpDisciple != null) {
                    int current_tp_lv = cmMpDisciple.getTupoLevel();
                    int next_tp_soul_num = discipleBo.getCdRecruitValue(cmMpDisciple.getDiscipleId(), "up" + current_tp_lv + "_num");

                    //验证魂魄是否够如破
                    if (cmMpDiscipleSoul.getSoulNum() >= next_tp_soul_num) {
                        int qianli_value = discipleBo.getCdRecruitValue(cmMpDisciple.getDiscipleId(), MapKeyConstants.RECRUIT_UP_LATENT);
                        Map cmMpDisciples_map = (Map) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
                        cmMpDisciple.setTupoLevel(cmMpDisciple.getTupoLevel() + 1);
                        //修改潜力值
                        cmMpDisciple.setDisPotential(cmMpDisciple.getDisPotential() + qianli_value);
                        cmMpDisciples_map.put(cmMpDisciple.getMpDisId(), cmMpDisciple);
                        //剩余魂魄数
                        int over_soul_num = cmMpDiscipleSoul.getSoulNum() - next_tp_soul_num;
                        if (over_soul_num <= 0) {
                            //删除数据库
                            delete(cmMpDiscipleSoul);
                            //删除内存
                            cmMpDiscipleSoul_map.remove(cmMpDiscipleSoul.getSoulId());
                            //变化的魂魄书
                            change.getCv().getCc().add(PackageCardBo.getSoulCard(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul.getDiscipleId(), over_soul_num, CardStatusEnum.del.value()));
                        } else {
                            cmMpDiscipleSoul.setSoulNum(over_soul_num);
                            cmMpDiscipleSoul_map.put(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul);
                            //变化的魂魄书
                            change.getCv().getCc().add(PackageCardBo.getSoulCard(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul.getDiscipleId(), over_soul_num, CardStatusEnum.add.value()));
                        }
                        //更新内存----->魂魄
                        ch.putObjectToCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId, cmMpDiscipleSoul_map);
                        //更新弟子
                        ch.putObjectToCache(CacheNames.USER_DISCIPLE_CACHE, userId, cmMpDisciples_map);

                        //突破等级 int level, int tupoLv, int exp, int atk, int def, int hp, int mp, int poten, int cardId, int codeId,int state,int sk
//                        change.getCv().getCc().add(PackageCardBo.getDicCard(cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, cmMpDisciple.getTupoLevel(), cmMpDisciple.getDisPotential(), CardStatusEnum.add.value(),cmMpDisciple.getGestId()));
                        change.getCv().getCc().add(PackageCardBo.getDicCardAll(Constants.DEFUALT_NULL, cmMpDisciple.getTupoLevel(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, cmMpDisciple.getDisPotential(), cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), Constants.DEFUALT_NULL));

                        change.setSt(ErrorCodeEnum.normal_success.value());
                    } else {
                        change.setSt(CstateConstants.TUPO_NO);
                    }
                } else {
                    change.setSt(CstateConstants.TUPO_DISCIPLE_NO);
                }
            } else {
                change.setSt(CstateConstants.TUPO_SOUL_NO);
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
