/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;



import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface GrudgeService extends BaseDao{
    public void invite(SuperAction sa)throws Exception;
    public void add(SuperAction sa)throws Exception;
    public void list(SuperAction sa)throws Exception;
    public void del(SuperAction sa)throws Exception;
    public void flower(SuperAction sa) throws Exception;
}
