/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.DisCommonBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.CJAchieveData;
import com.bsc.commonproject.clinet.command.response.CJShopItem;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPSummonProtog;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.GameConstants;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.constants.UserNoCleanDateMapKey;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.enums.MsgMode;
import com.bsc.message.server.NoteBoardService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdBaby;
import com.bsc.protracted.domin.CdMarket;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CdStore;
import com.bsc.protracted.domin.CdStoreAsk;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpDiscipleSoul;
import com.bsc.protracted.domin.CmMpOtherData;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.random.server.RandomUtilService;
import com.bsc.random.vo.RandItem;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.datas.DateUtil;
import com.bsc.util.json.JsonHelper;
import com.bsc.util.tools.FelCount;
import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class ShopBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private DiscipleBo discipleBo;
    @Resource
    private PackageBo packageBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private RandomUtilService randomUtilService;
    @Resource
    private AddCardBo addCardBo;
    @Resource
    private NoteBoardService noteBoardService;
    @Resource
    private SaveLogBo saveLogBo;
    @Resource
    private AchieveBo achieveBo;
    @Resource
    private DisCommonBo disCommonBo;
    @Resource
    private PropBo propBo;
    private static final Logger log = LoggerFactory.getLogger(ShopBo.class);
    private final String MARKET_FREE_DISCIPLE_NUM = "MARKET_FREE_DISCIPLE_NUM";
    private final String MARKET_CHARGE_DISCIPLE_NUM = "MARKET_CHARGE_DISCIPLE_NUM";
    private final String MARKET_CHARGE_ALL_MOENY_NUM = "MARKET_CHARGE_ALL_MOENY_NUM";
    private final String VIP_BUY_LIST = "VIP_BUY_LIST";

    //获取内存中的商城列表
    public List<CJShopItem> getShopListFromCache(String lan_key, int userId) throws Exception {
        Map<Integer, CdMarket> map = null;
        List<CJShopItem> lt = new ArrayList<CJShopItem>();
        try {
            Object obj = ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.MARKET_KEY);
            if (obj != null) {
                map = (Map<Integer, CdMarket>) obj;
            } else {
                List<CdMarket> marketlt = get("from CdMarket ORDER BY page, seq ");
                map = new HashMap<Integer, CdMarket>();
                for (CdMarket cdMarket : marketlt) {
                    map.put(cdMarket.getId(), cdMarket);
                }
                ch.putObjectToCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.MARKET_KEY, map);
            }

            Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
            if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
            }
            CmMpOtherData obj_num = cmMpOtherData_map.get(VIP_BUY_LIST);
            Map<String, Integer> sell_num = new HashMap<String, Integer>();
            if (obj_num != null) {
                sell_num = (Map<String, Integer>) JsonHelper.getBeanFromJson(obj_num.getDataValue(), Map.class);
            }
            for (Map.Entry entry_type : map.entrySet()) {
                int cardId = (Integer) entry_type.getKey();
                CdMarket market = (CdMarket) entry_type.getValue();
                boolean ble = true;
                if (market.getPage() == 3 && sell_num.containsKey(String.valueOf(market.getId())) && sell_num.get(String.valueOf(market.getId())) >= market.getNum()) {
                    ble = false;
                }
                if (ble) {
                    CJShopItem si = new CJShopItem();
                    si.setCid(market.getId());
                    si.setOp(market.getOriginalPrice());
//                    si.setNum(market.getNum());
                    si.setRp(market.getCurrentPrice());
                    si.setVl(market.getVipLv());
                    si.setLl(market.getPlayerLv());
                    si.setP(market.getPage());
                    si.setSeq(market.getSeq());
                    lt.add(si);
                }
            }
            Collections.sort(lt, new ShopComparator());
            return lt;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //集市中用戶獲得弟子或者魂魄

    public RPSummonProtog getDiscipleFromMarket(int userId, int type) throws Exception {
        RPSummonProtog change = new RPSummonProtog();
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
                int all_money = get_matket_mmoney(cmMpOtherData_map);
                int[] ints = getuser_fluysh_num(userId, type, all_money, cmMpOtherData_map);
                if (ints != null && ints.length == 3) {
                    int random_disId = 0;
                    int randomType = ints[0];
                    int gold = ints[1];
                    int storeType = ints[2];
                    //验证金币是否购
                    boolean gold_enough = true;
                    boolean is_consum = false;
                    if (gold != 0 && vo.getMpGold() - gold < 0) {
                        gold_enough = false;
                    }
                    if (gold_enough) {
                        if (gold != 0) {
                            //修改用户金币
                            mpcommonBo.consum_gold(userId, gold);
                            change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(-gold)));
                            is_consum = true;
                        }
                        random_disId = getRandomDisIdFromStore(randomType, storeType,vo.getMpLevel());
                        if (random_disId != 0) {
                            //查找弟子码表
                            Map baby_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
                            CdBaby cdBaby = (CdBaby) baby_map.get(random_disId);

                            CmMpDisciple cmMpDisciple = addCardBo.IsHaveDisciple(userId, random_disId);
                            //如果随机出的是甲级弟子，则验证是否需要再次进行随机
                            if (cdBaby.getPz() == 4) {
                                //判断甲级弟子的出现的几率
                                List<CmMpDisciple> dislt = discipleBo.getCmMpDiscipleListFromCacheFromPz(userId, 4);
                                int dis_4_num = dislt.size();
                                //查找咋表数据判断出现的几率
                                Map<String, CdMessyData> CdMessyData_map = (Map<String, CdMessyData>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
                                Object mess_obj = CdMessyData_map.get("market_baby_pro");
                                int pro_rate = 99;
                                if (mess_obj != null) {
                                    CdMessyData mess = (CdMessyData) mess_obj;
                                    if (mess.getMessyValue().indexOf(",") > 0) {
                                        String[] pro_num_array = mess.getMessyValue().split(",");
                                        int pro_num_a = 0;
                                        for (String strs : pro_num_array) {
                                            pro_num_a++;
                                            if (strs.indexOf(";") > 0) {
                                                if (dis_4_num == Integer.parseInt(strs.split(";")[0])) {
                                                    pro_rate = Integer.parseInt(strs.split(";")[1]);
                                                }
                                                //如果没随机到则获取最后一个几率
                                                if (pro_num_a == pro_num_array.length && pro_rate == 99) {
                                                    pro_rate = Integer.parseInt(strs.split(";")[1]);
                                                }
                                            }
                                        }
                                    }
                                }
                                int random = (1 + (int) (Math.random() * 100));
                                //判断用户是否可以获得该弟子
                                if (pro_rate < random) {
                                    int random_dis = (1 + (int) (Math.random() * dislt.size()));
                                    cmMpDisciple = (CmMpDisciple) dislt.get(random_dis - 1);
                                }
                            }
                            MsgMode msgModeType = null;
                            if (cmMpDisciple == null) {//用户没有就增加弟子
                                //如果是甲级弟子增加甲级弟子产出
                                msgModeType = MsgMode.market_accept_second;
                                if (cdBaby.getPz() == 4) {
                                    msgModeType = MsgMode.market_accept_first;
                                    //增加甲级弟子成就
                                    cmMpOtherData_map = save_dis_num(cmMpOtherData_map, is_consum, userId);
                                    AchieveVo achieveVo = achieveBo.saveAchieve(userId, 150010008, 1, 0);
                                    if (achieveVo != null) {
                                        Map<String, Object> m = new HashMap<String, Object>();
                                        List<CJAchieveData> lt = new ArrayList<CJAchieveData>();
                                        CJAchieveData cd = new CJAchieveData();
                                        cd.setId(150010008);
                                        cd.setLv(achieveVo.getLv());
                                        m.put(ClientMapKeyEnum.achive.value(), lt.add(cd));
                                        change.setAh(m);
                                    }
                                }
                                cmMpDisciple = addCardBo.getCmMpDisciple(userId, random_disId,GameConstants.DEFALUT_LEVEL);
                                //封装弟子卡牌 int cardId, int codeId,int level, int exp,int topoLv,int poten ,int state
                                change.getCv().getCc().add(PackageCardBo.getDicCard(cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), cmMpDisciple.getDisLevel(), cmMpDisciple.getDisExp(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                                //封装武功卡牌
                                change.getCv().getCc().add(PackageCardBo.getGestCard(cmMpDisciple.getCmMpGest().getMpGestId(), cmMpDisciple.getCmMpGest().getGestId(), cmMpDisciple.getCmMpGest().getGestLevel(), CardStatusEnum.add.value()));

                            } else {//用户已经还有该弟子则增加魂魄
                                String gs = "$('Math').pow(2,pz)";
                                Map map = new HashMap();
                                map.put("pz", cdBaby.getPz());
                                int num = Tools.getNumberToInt(FelCount.getCountResult(map, gs));
                                if (num >= 18) {
                                    num = 18;
                                }
                                CmMpDiscipleSoul soul = addCardBo.addDiscipleSoul(userId, disCommonBo.getSoulIdFromDiscipleId(cmMpDisciple.getDiscipleId()), num);
                                //魂魄数
                                change.getCv().getCc().add(PackageCardBo.getSoulCard(soul.getSoulId(), soul.getDiscipleId(), soul.getSoulNum(), CardStatusEnum.add.value()));
                                msgModeType = MsgMode.market_extraction_sencod;
                                if (cdBaby.getPz() == 4) {
                                    msgModeType = MsgMode.market_extraction_first;
                                }
                            }
                            saveLogBo.gold(ControlType.ENLIST, userId, vo.getMpName(), vo.getMpGold(), -gold, String.valueOf(random_disId));
                            change.setSt(ErrorCodeEnum.normal_success.value());
                            //增加走马灯消息, MsgMode mode, int userId, String mpName, int itemId, String itemName, int level
                            //(              MsgMode mode, String send_msg, int userId, String mpName, int disId, String disName)
                            if (cdBaby.getPz() == 4 || cdBaby.getPz() == 3) {
                                noteBoardService.addNodeBoardMsg(msgModeType, vo.getMpName(), vo.getUserId(), vo.getMpName(), cdBaby.getId(), cdBaby.getName());
                            }
                            ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);
                        } else {
                            change.setSt(ErrorCodeEnum.random_error.value());
                        }
                    } else {
                        change.setSt(ErrorCodeEnum.gold_not_enough.value());
                    }
                } else {
                    change.setSt(ErrorCodeEnum.info_error_member_error.value());
                }
            } else {
                change.setSt(ErrorCodeEnum.user_not_exist.value());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(ShopBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return change;
    }

    private int[] getuser_fluysh_num(int userId, int type, int all_money, Map<String, CmMpOtherData> cmMpOtherData_map) throws Exception {
        try {
            int gold = 0;
            int randomType = 0;
            int storeType = 0;
            Map<String, Object> user_data_map = (Map<String, Object>) ch.getObjectFromCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, userId);
            if (user_data_map == null || user_data_map.isEmpty()) {
                user_data_map = new HashMap<String, Object>();
            }
            if (type == 1) {//十里挑一
                Object typ1_time_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_1);
                randomType = 210;
                if (typ1_time_obj != null) {
                    long type_time = (Long) typ1_time_obj;
                    Object typ1_num_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_NUM_TYPE_1);
                    long num = (Long) typ1_num_obj;
                    int min = getTimeMin(type_time);
                    if (!isNextDay(type_time)) {
                        num = 0;
                    }
                    if (num <= 5 && min >= 10) {//判断是否为免费
                        num++;
                        user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_1, DateUtil.getCurrentDate().getTime());
                        user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_NUM_TYPE_1, num);
                    } else {
                        randomType = 310;
                        gold = 10;
                    }
                } else {
                    user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_1, DateUtil.getCurrentDate().getTime());
                    user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_NUM_TYPE_1, new Long(1));
                }

            } else if (type == 2) {//百里挑一
                Object typ2_time_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_2);
                randomType = 2100;
                if (typ2_time_obj != null) {
                    long type_time = (Long) typ2_time_obj;
//                    int min = getTimeHour(type_time);
                    long min = DateUtil.getCurrentDate().getTime() - type_time;
                    if (min >= 24 * 60 * 60 * 1000) {//判断是否为免费
                        user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_2, DateUtil.getCurrentDate().getTime());
                    } else {
                        randomType = 3100;
                        gold = 100;
                        save_matket_mmoney(userId, cmMpOtherData_map, "100", 100);
                    }
                } else {
                    user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_2, DateUtil.getCurrentDate().getTime());
                }
                if (gold == 100 && is_first_flush(cmMpOtherData_map, "100")) {
                    storeType = 3;
                } else {
                    //根据用户的全部消费情况进行类别区分
                    storeType = getStoreType(userId, all_money);
                }

            } else if (type == 3) {
                Object typ3_time_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_3);
                randomType = 2300;
                if (typ3_time_obj != null) {
                    long type_time = (Long) typ3_time_obj;
                    long hour = DateUtil.getCurrentDate().getTime() - type_time;
                    if (hour >= 72 * 60 * 60 * 1000) {//判断是否为免费
                        user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_3, DateUtil.getCurrentDate().getTime());
                    } else {
                        randomType = 3300;
                        gold = 300;
                        save_matket_mmoney(userId, cmMpOtherData_map, "300", 300);
                    }
                } else {
                    user_data_map.put(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_3, DateUtil.getCurrentDate().getTime());
                }
                if (gold == 300 && is_first_flush(cmMpOtherData_map, "300")) {
                    storeType = 4;
                } else {
                    //根据用户的全部消费情况进行类别区分
                    storeType = getStoreType(userId, all_money);
                }
            }
            int[] ints = new int[3];
            ints[0] = randomType;
            ints[1] = gold;
            ints[2] = storeType;
            ch.putObjectToCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, userId, user_data_map);
            return ints;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public String[] get_flush_time(int userId) throws Exception {
        String[] strs = new String[3];
        try {
            Map<String, Object> user_data_map = (Map<String, Object>) ch.getObjectFromCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, userId);
            if (user_data_map == null || user_data_map.isEmpty()) {
                user_data_map = new HashMap<String, Object>();
            }
            String b = "0:5";
            String q = "0";
            String w = "0";
            //十里挑一
            Object typ1_time_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_1);
            if (typ1_time_obj != null) {

                long type_time = (Long) typ1_time_obj;
                Object typ1_num_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_NUM_TYPE_1);
                long num = (Long) typ1_num_obj;
                int min = getTimeMin(type_time);
                if (!isNextDay(type_time)) {
                    b = 0 + ":" + 5;
                } else {
                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(type_time);
                    if (num > 5) {
                        cal.add(Calendar.DATE, 1);
                        b = (cal.getTime().getTime() - DateUtil.getCurrentDate().getTime()) / 1000 + ":" + 0;
                    } else {
                        cal.add(Calendar.MINUTE, 10);
                        b = (cal.getTime().getTime() - DateUtil.getCurrentDate().getTime()) / 1000 + ":" + (5 - num);
//                    if (min >=10) {//判断是否为免费
//                        b = (cal.getTime().getTime() - DateUtil.getCurrentDate().getTime()) / 1000 + ":" + (5- num);
//                    } else {
//                       
//                        // DateUtil.getCurrentDate().getTime() - start_time/1000
//                        b = (cal.getTime().getTime() - DateUtil.getCurrentDate().getTime()) + ":" + (5- num);
//                    }
                    }
                }
            }
            //百里挑一
            Object typ2_time_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_2);
            if (typ2_time_obj != null) {
                long type_time = (Long) typ2_time_obj;
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(type_time);
                cal.add(Calendar.HOUR, 24);
                long t = cal.getTime().getTime() - DateUtil.getCurrentDate().getTime();
                if (t < 0) {
                    t = 0;
                }
                q = String.valueOf(t / 1000);

            }
            Object typ3_time_obj = user_data_map.get(UserNoCleanDateMapKey.MARKET_RECUIT_TIME_TYPE_3);
            if (typ3_time_obj != null) {
                long type_time = (Long) typ3_time_obj;
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(type_time);
                cal.add(Calendar.HOUR, 72);
                long t = cal.getTime().getTime() - DateUtil.getCurrentDate().getTime();
                if (t < 0) {
                    t = 0;
                }
                w = String.valueOf(t / 1000);

            }
            strs[0] = b;
            strs[1] = q;
            strs[2] = w;
            return strs;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public int get_matket_mmoney(Map<String, CmMpOtherData> cmMpOtherData_map) throws Exception {
        try {
            Object all_money_obj = cmMpOtherData_map.get(MARKET_CHARGE_ALL_MOENY_NUM);
            Map<Integer, Integer> money_map = null;
            int all_money = 0;
            if (all_money_obj != null) {
                CmMpOtherData cmMpOtherData_all_moey = (CmMpOtherData) all_money_obj;
                money_map = (Map<Integer, Integer>) JsonHelper.getBeanFromJson(cmMpOtherData_all_moey.getDataValue(), Map.class);
                for (Map.Entry entry_type : money_map.entrySet()) {
//                int cardId = (Integer) entry_type.getKey();
                    int money = (Integer) entry_type.getValue();
                    all_money = all_money + money;
                }
            }
            return all_money;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public boolean is_first_flush(Map<String, CmMpOtherData> cmMpOtherData_map, String type) throws Exception {
        try {
            Object all_money_obj = cmMpOtherData_map.get(MARKET_CHARGE_ALL_MOENY_NUM);
            if (all_money_obj != null) {
                CmMpOtherData cmMpOtherData_all_moey = (CmMpOtherData) all_money_obj;
                Map<String, Integer> money_map = (Map<String, Integer>) JsonHelper.getBeanFromJson(cmMpOtherData_all_moey.getDataValue(), Map.class);
                Object obj = money_map.get(type);
                if (obj != null && (Integer) obj == Integer.parseInt(type)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public Map<String, CmMpOtherData> save_matket_mmoney(int userId, Map<String, CmMpOtherData> cmMpOtherData_map, String type, int num) throws Exception {
        try {
            if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
            }
            Object all_money_obj = cmMpOtherData_map.get(MARKET_CHARGE_ALL_MOENY_NUM);
            CmMpOtherData cmMpOtherData_all_moey = null;
            Map<String, Integer> money_map = null;
            if (all_money_obj != null) {
                cmMpOtherData_all_moey = (CmMpOtherData) all_money_obj;
                money_map = (Map<String, Integer>) JsonHelper.getBeanFromJson(cmMpOtherData_all_moey.getDataValue(), Map.class);
                Object obj = money_map.get(type);
                if (obj == null) {
                    money_map.put(type, num);
                } else {
                    money_map.put(type, (Integer) obj + num);
                }
            } else {
                money_map = new HashMap<String, Integer>();
                money_map.put(type, num);
                cmMpOtherData_all_moey = new CmMpOtherData();
                cmMpOtherData_all_moey.setDataKey(MARKET_CHARGE_ALL_MOENY_NUM);
                cmMpOtherData_all_moey.setDataValue(String.valueOf(0));
                cmMpOtherData_all_moey.setUserId(userId);
            }
            cmMpOtherData_all_moey.setDataValue(JsonHelper.getJsonFromBeanNoSrting(money_map));
            cmMpOtherData_map.put(MARKET_CHARGE_ALL_MOENY_NUM, cmMpOtherData_all_moey);
            return cmMpOtherData_map;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    private int getRandomDisIdFromStore(int feeType, int storeType,int user_lv) throws Exception {
        try {
            Map<Integer, List<CdStore>> CdStore_map = null;
            if(user_lv < 10){
                CdStore_map = (Map<Integer, List<CdStore>>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RECRUIT_DISCIPLE_STORE_KEY_DES10);
            }else{
                CdStore_map = (Map<Integer, List<CdStore>>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RECRUIT_DISCIPLE_STORE_KEY);
            }
            
            if (CdStore_map != null && !CdStore_map.isEmpty()) {
                List<CdStore> stlt = CdStore_map.get(storeType);
                List<RandItem> lt = new ArrayList<RandItem>();
                int all_rate = 0;
                for (CdStore store : stlt) {
                    int rate = 0;
                    switch (feeType) {
                        case 210://免费10
                            rate = store.getM10();
                            break;
                        case 2100://免费100
                            rate = store.getM100();
                            break;
                        case 2300://免费300
                            rate = store.getM300();
                            break;
                        case 310://收费10
                            rate = store.getF10();
                            break;
                        case 3100://收费100
                            rate = store.getF100();
                            break;
                        case 3300://收费300
                            rate = store.getF300();
                            break;
                        case 20://百里首刷
                            rate = 1;
                            break;
                        case 30://万里首刷
                            rate = 1;
                            break;
                    }
                    if (store.getId() != 0) {
                        lt.add(new RandItem(store.getId(), rate));
                        all_rate = all_rate + rate;
                    }
                }
                RandItem rit = randomUtilService.getRandItem(lt, all_rate);
                int num = (Integer) rit.getItem();
                return (Integer) rit.getItem();
            }

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return 0;
    }
    //几率弟子产出个数

    public Map<String, CmMpOtherData> save_dis_num(Map<String, CmMpOtherData> cmMpOtherData_map, boolean is_consum, int userId) {
        int num = 1;
        if (is_consum) {
            Object all_money_obj = cmMpOtherData_map.get(MARKET_CHARGE_DISCIPLE_NUM);
            CmMpOtherData CmMpOtherData_charge_num = null;
            if (all_money_obj != null) {
                CmMpOtherData_charge_num = (CmMpOtherData) all_money_obj;
                CmMpOtherData_charge_num.setDataValue(String.valueOf(Integer.parseInt(CmMpOtherData_charge_num.getDataValue()) + num));
            } else {
                CmMpOtherData_charge_num = new CmMpOtherData();
                CmMpOtherData_charge_num.setDataKey(MARKET_CHARGE_DISCIPLE_NUM);
                CmMpOtherData_charge_num.setDataValue(String.valueOf(num));
                CmMpOtherData_charge_num.setUserId(userId);
            }
            cmMpOtherData_map.put(MARKET_CHARGE_DISCIPLE_NUM, CmMpOtherData_charge_num);
        } else {
            Object all_money_obj = cmMpOtherData_map.get(MARKET_FREE_DISCIPLE_NUM);
            CmMpOtherData CmMpOtherData_free_num = null;
            if (all_money_obj != null) {
                CmMpOtherData_free_num = (CmMpOtherData) all_money_obj;
                CmMpOtherData_free_num.setDataValue(String.valueOf(Integer.parseInt(CmMpOtherData_free_num.getDataValue()) + num));
            } else {
                CmMpOtherData_free_num = new CmMpOtherData();
                CmMpOtherData_free_num.setDataKey(MARKET_FREE_DISCIPLE_NUM);
                CmMpOtherData_free_num.setDataValue(String.valueOf(num));
                CmMpOtherData_free_num.setUserId(userId);
            }
            cmMpOtherData_map.put(MARKET_FREE_DISCIPLE_NUM, CmMpOtherData_free_num);
        }

        return cmMpOtherData_map;
    }

    public int getStoreType(int userId, int allgold) throws Exception {
        int storeType = 0;
        try {
            List<CdStoreAsk> asklt = (List<CdStoreAsk>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RECRUIT_DISCIPLE_STORE_ASK_KEY);
            List<CmMpDisciple> dislt = discipleBo.getCmMpDiscipleListFromCacheFromPz(userId, GameConstants.QUALITY_JIA);
            int jia_num = 0;
            if (dislt != null) {
                jia_num = dislt.size();
            }
            for (int i = 0; i < asklt.size(); i++) {
                CdStoreAsk ask = (CdStoreAsk) asklt.get(i);
                if (allgold > ask.getBabyGold() && jia_num < ask.getBabyNum()) {
                    storeType = ask.getBabyType();
                    return storeType;
                }
//                if (i == 0 && allgold < ask.getBabyGold()) {
//                    break;
//                }
//                CdStoreAsk next_ask = null;
//                if (i + 1 < asklt.size()) {
//                    next_ask = (CdStoreAsk) asklt.get(i + 1);
//                }
//                if (next_ask != null && allgold > ask.getBabyGold() && allgold < next_ask.getBabyGold() && jia_num < ask.getBabyNum()) {
//                    storeType = ask.getBabyType();
//                    break;
//                }
//                storeType = ask.getBabyType();
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }

        return storeType;
    }

    private int getTimeMin(long start_time) {
        long diff = DateUtil.getCurrentDate().getTime() - start_time;
        return (int) (diff / (1000 * 60));

    }

    private int getTimeHour(long start_time) {
        long diff = DateUtil.getCurrentDate().getTime() - start_time;
        return (int) (diff / (1000 * 60 * 60));
    }

    private boolean isNextDay(long time) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(time);
        String up_date = DateUtil.format(cal.getTime(), DateUtil.C_DATA_PATTON_YYYYMMDD);
        String current_date = DateUtil.getCurrentDateStr(DateUtil.C_DATA_PATTON_YYYYMMDD);
        if (up_date.equals(current_date)) {
            return true;
        }
        return false;
    }

    public RPChangeData buy(int userId, int codeId, int num, int type) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            Map<Integer, CdMarket> map = (Map<Integer, CdMarket>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.MARKET_KEY);
            CdMarket cdMarket = map.get(codeId);
            if (cdMarket == null) {
                change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
                return change;
            }
            if (type == 3) {//购买礼包
                MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(userId);
                if (vo.getMpVip() < codeId - 140030000) {
                    change.setSt(ErrorCodeEnum.mp_vip_lev_no_enough.value());
                    return change;
                }
                Map<String, CmMpOtherData> cmMpOtherData_map = (Map<String, CmMpOtherData>) ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
                if (cmMpOtherData_map == null || cmMpOtherData_map.isEmpty()) {
                    cmMpOtherData_map = new HashMap<String, CmMpOtherData>();
                }
                Object obj = cmMpOtherData_map.get(VIP_BUY_LIST);
                CmMpOtherData cmMpOtherData = null;
                Map<String, Integer> buy_map = null;
                if (obj == null) {
                    buy_map = new HashMap();
                    cmMpOtherData = new CmMpOtherData();
                    cmMpOtherData.setUserId(userId);
                    cmMpOtherData.setDataKey(VIP_BUY_LIST);
                    buy_map.put(String.valueOf(codeId), 1);
                    cmMpOtherData.setDataValue(JsonHelper.getJsonFromBeanNoSrting(buy_map));
                } else {
                    cmMpOtherData = (CmMpOtherData) obj;
                    buy_map = (Map<String, Integer>) JsonHelper.getBeanFromJson(cmMpOtherData.getDataValue(), Map.class);
                    if (buy_map.containsKey(String.valueOf(codeId)) && buy_map.get(String.valueOf(codeId)) >= cdMarket.getNum()) {
                        change.setSt(ErrorCodeEnum.arrive_limit.value());
                        return change;
                    } else {
                        int num_z = 0;
                        Object o_n = buy_map.get(String.valueOf(codeId));
                        if (o_n != null) {
                            num_z = buy_map.get(String.valueOf(codeId));
                        }
                        buy_map.put(String.valueOf(codeId), num_z + 1);
                    }
                    cmMpOtherData.setDataValue(JsonHelper.getJsonFromBeanNoSrting(buy_map));
                }
                num = 1;
                cmMpOtherData_map.put(VIP_BUY_LIST, cmMpOtherData);
                ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, userId, cmMpOtherData_map);
            } else if (type == 2) {
                if (cdMarket.getNum() < num) {
                    change.setSt(ErrorCodeEnum.arrive_limit.value());
                    return change;
                }
            }
            return buy(userId, codeId, num, cdMarket, change);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    private RPChangeData buy(int userId, int codeId, int num, CdMarket cdMarket, RPChangeData change) throws Exception {

        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                int all_gold = cdMarket.getCurrentPrice() * num;
                if (vo.getMpGold() - all_gold >= 0) {
                    //
                    CmMpProps prop = addCardBo.addProp(userId, num, codeId);
                    change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), codeId, prop.getPropNum(), Constants.DEFUALT_NULL, CardStatusEnum.add.value()));
                    //修改用户金币数
                    mpcommonBo.consum_gold(userId, all_gold);
                    saveLogBo.gold(ControlType.MALL_BUY, userId, vo.getMpName(), vo.getMpGold(), -all_gold, codeId + ":" + num);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(-all_gold)));
                    change.setSt(ErrorCodeEnum.normal_success.value());
                    //几率宝箱消耗的金币数
                    packageBo.save_box_buy_gold(userId, codeId, num);
                } else {
                    change.setSt(ErrorCodeEnum.gold_not_enough.value());
                }
            } else {
                change.setSt(ErrorCodeEnum.user_not_exist.value());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }
}
