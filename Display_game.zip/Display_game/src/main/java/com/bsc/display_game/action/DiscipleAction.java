/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;


import com.bsc.display_game.service.DiscipleService;
import com.bsc.displaybases.SuperAction;
import static com.opensymphony.xwork2.Action.SUCCESS;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/disciple")
public class DiscipleAction extends SuperAction {

    @Resource
    private DiscipleService discipleService;
    
    @Action(value = "recruit", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String recruit() {
        try {
            discipleService.recruit(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
     @Action(value = "transfer", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String transfer() {
        try {
            discipleService.transfer(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
      @Action(value = "train", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String train() {
        try {
            discipleService.train(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
       @Action(value = "confirm", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String confirm() {
        try {
            discipleService.train_confirm(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
        @Action(value = "tupo", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
     public String tupo() {
        try {
            discipleService.tuPo(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
}
