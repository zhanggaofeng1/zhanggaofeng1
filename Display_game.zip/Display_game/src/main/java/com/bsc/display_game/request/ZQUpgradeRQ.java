/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;


import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class ZQUpgradeRQ extends ReceiveJson {

    @JsonProperty("id")
    private int cardId;
    @JsonProperty("il")
    private List<Integer> delCardIds;

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public List<Integer> getDelCardIds() {
        return delCardIds;
    }

    public void setDelCardIds(List<Integer> delCardIds) {
        this.delCardIds = delCardIds;
    }
}
