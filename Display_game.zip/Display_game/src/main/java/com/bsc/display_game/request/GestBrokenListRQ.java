/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.ArrayList;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class GestBrokenListRQ extends ReceiveJson{
    @JsonProperty("cid")
    private int gestCodeId;
     @JsonProperty("tl")
    private List<String> typeList = new ArrayList();
    

    public int getGestCodeId() {
        return gestCodeId;
    }

    public void setGestCodeId(int gestCodeId) {
        this.gestCodeId = gestCodeId;
    }

    public List<String> getTypeList() {
        return typeList;
    }

    public void setTypeList(List<String> typeList) {
        this.typeList = typeList;
    }

   
    
    
    
    
}
