/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.clinet.command.response.CJAchieveData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.CardTypeEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.constants.CstateConstants;
import com.bsc.display_game.request.EquipRefining;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.enums.MsgMode;
import com.bsc.message.server.NoteBoardService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdEquip;
import com.bsc.protracted.domin.CdEquipUpMoney;
import com.bsc.protracted.domin.CmMpEquip;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.random.impl.RandFuncationBean;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class EquipBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private CommonBo commonBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private RandFuncationBean randFuncationBean;
    @Resource
    private PropBo propBo;
    @Resource
    private NoteBoardService noteBoardService;
    @Resource
    private AchieveBo achieveBo;
    private static final Logger log = LoggerFactory.getLogger(EquipBo.class);

    //精炼
    public RPChangeData refining(int userId, int cardId, List<EquipRefining> del_props, RPChangeData change) throws Exception {
        CmMpEquip cmMpEquip = null;
        try {
            Map prop_map = (Map) ch.getObjectFromCache(CacheNames.USER_PROP_CACHE, userId);
            Map equid_map = (Map) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
            Object obj_equip = equid_map.get(cardId);
            if (obj_equip != null) {
                cmMpEquip = (CmMpEquip) obj_equip;
                if (cmMpEquip.getRefiningLevel() < 10) {
                    int all_exp = 0;
                    for (EquipRefining equipRefining : del_props) {
                        //验证该用户是否含有该装备
                        Object obj = prop_map.get(equipRefining.getCardId());
                        //判定该道具是否存在
                        if (obj != null) {
                            CmMpProps prop = (CmMpProps) obj;
                            //判断适量是否够
                            if (prop.getPropNum() - equipRefining.getNum() >= 0) {
                                if (prop.getPropNum() - equipRefining.getNum() == 0) {
                                    //删除数据库数据
                                    delete(prop);
                                    //删除内存数据
                                    prop_map.remove(prop.getMpPropId());

                                    change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), prop.getPropNum(), prop.getPropLv(), CardStatusEnum.del.value()));
                                } else {
                                    prop.setPropNum(prop.getPropNum() - equipRefining.getNum());
                                    prop_map.put(prop.getMpPropId(), prop);
                                    //int cardId, int codeId, int num, int lv,int state
                                    change.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), prop.getPropNum(), prop.getPropLv(), CardStatusEnum.add.value()));
                                    ch.putObjectToCache(CacheNames.USER_PROP_CACHE, userId, prop_map);
                                }
                                //获取该物品的原始数据
                                all_exp = Tools.getNumberToInt(propBo.getPropAttach(prop.getPropId()) * equipRefining.getNum()) + all_exp;
                            }
                        } else {
                            change.setSt(CstateConstants.JINGLIAN_PROP_NO);
                        }
                    }
                    if (all_exp != 0) {
                        //获取精炼之后精炼等级与剩余经验
                        cmMpEquip.setRefiningExp(cmMpEquip.getRefiningExp() + all_exp);
                        //根据当前精炼等级查看下一集需要的经验数据
                        //查找码表数据
                        Map cdEquip_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.EQUIP_KEY);
                        CdEquip cdEquip = (CdEquip) cdEquip_map.get(cmMpEquip.getEquipId());
                        //封装公式需要的参数
//                        Map formula_value_map = new HashMap();
//                        formula_value_map.put("pz", cdEquip.getPz());
//                        formula_value_map.put("equip_refine", cmMpEquip.getRefiningLevel());
//                        int final_exp_int = commonBo.getIntFromFormula(18, formula_value_map);
//
//                        if (cmMpEquip.getRefiningExp() > final_exp_int) {
//                            cmMpEquip.setRefiningExp(cmMpEquip.getRefiningExp() - final_exp_int);
//                            cmMpEquip.setRefiningLevel(cmMpEquip.getRefiningLevel() + 1);
//                        }
                         cmMpEquip = getUpLevel(cmMpEquip.getRefiningLevel(), cmMpEquip.getRefiningExp(), cdEquip.getPz(),  cmMpEquip);
                        //返回封装的精炼经验变化
                        change.getCv().getCc().add(PackageCardBo.getEquipCard(cmMpEquip.getMpEquipId(), cmMpEquip.getEquipId(), cmMpEquip.getEquipLevel(), cmMpEquip.getRefiningLevel(), cmMpEquip.getRefiningExp(), CardStatusEnum.add.value()));
                        equid_map.put(cmMpEquip.getMpEquipId(), cmMpEquip);
                        ch.putObjectToCache(CacheNames.USER_EQUIP_CACHE, userId, equid_map);
                        change.setSt(ErrorCodeEnum.normal_success.value());
                    }
                } else {
                    change.setSt(CstateConstants.JINGLIAN_ZHUANGBEI_SHANGXINA);
                }
            } else {
                change.setSt(CstateConstants.JINGLIAN_ZHUANGBEI_NO);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    public CmMpEquip getUpLevel(int current_lv, int all_exp, int pz, CmMpEquip cmMpEquip) {
        Map formula_value_map = new HashMap();
        formula_value_map.put("pz", pz);
        formula_value_map.put("equip_refine", cmMpEquip.getRefiningLevel());
        int final_exp_int = commonBo.getIntFromFormula(18, formula_value_map);
        int over_exp = all_exp - final_exp_int;
        if (over_exp >= 0) {
            //封装公式需要的参数
            cmMpEquip.setRefiningExp(over_exp);
            cmMpEquip.setRefiningLevel(cmMpEquip.getRefiningLevel() + 1);
            getUpLevel(cmMpEquip.getRefiningLevel(), over_exp, pz, cmMpEquip);
        } else {
            cmMpEquip.setRefiningExp(all_exp);
        }
        return cmMpEquip;
    }

    //买出装备
    public RPChangeData sell(List<Integer> list, int userId, RPChangeData change) throws Exception {
        try {
            //用户装备列表
            Map equip_map = (Map) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
            //查找码表数据
            Map cdEquip_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.EQUIP_KEY);
            // CacheNames.EQUIP_SELLANDUPGRADE_CODE_CACHE,获取需要扣除的银币
            Map sell_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.EQUIP_UP_MONEY_KEY);
            int del_num = 0;
            for (Integer propo : list) {
                Object obj = equip_map.get(propo);
                if (obj != null) {
                    CmMpEquip equip = (CmMpEquip) obj;
                    if (equip.getBattleDIscipleId() == 0) {
                        del_num++;
                    }
                }
            }
            if (del_num != list.size()) {
                change.setSt(ErrorCodeEnum.up_lineup_no_delete.value());
                return change;
            }

            int silver = 0;
            //验证用户是有该装备
            for (Integer propo : list) {
                Object obj = equip_map.get(propo);
                if (obj != null) {
                    CmMpEquip equip = (CmMpEquip) obj;
                    //获取原始数据
                    Object cdEquipUpMoney_obj = sell_map.get(equip.getEquipLevel());
                    int money_con = 0;
                    if (cdEquipUpMoney_obj != null) {
                        CdEquipUpMoney cdEquipUpMoney = (CdEquipUpMoney) cdEquipUpMoney_obj;
                        money_con = cdEquipUpMoney.getMoneyCon();
                    }
                    //获取码表数据
                    CdEquip cdEquip = (CdEquip) cdEquip_map.get(equip.getEquipId());
                    //计算本次买出可以获得的银币数
                    //power*pz*1.6*200+baseconsume*money_con/75                          
                    //封装公式需要的参数
                    Map formula_value_map = new HashMap();
                    formula_value_map.put("power", cdEquip.getPower());
                    formula_value_map.put("pz", cdEquip.getPz());
                    formula_value_map.put("baseconsume", cdEquip.getBaseconsume());
                    formula_value_map.put("money_con", money_con);

                    silver = silver + commonBo.getIntFromFormula(15, formula_value_map);

                    //删除装备
                    //数据库删除
                    delete(equip);
                    //删除内存表
                    equip_map.remove(equip.getMpEquipId());
                    //封装返回数据
                    change.getCv().getCc().add(PackageCardBo.getEquipCard(equip.getMpEquipId(), equip.getEquipId(), 1, 0, CardTypeEnum.EQUIP_CARD_TYPE.value(), CardStatusEnum.del.value()));
//                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(silver)));
                }
            }
            //更新用户银元宝
            mpcommonBo.add_silver(userId, silver);
            //返回封装的消耗的银币数字
            change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(silver)));
            change.setSt(ErrorCodeEnum.normal_success.value());
            ch.putObjectToCache(CacheNames.USER_EQUIP_CACHE, userId, equip_map);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }
    //装备升级

    public RPChangeData upgrade(int cardId, int silver, int userId, int vip, RPChangeData change, CdEquip cdEquip, MenPaiCacheVo vo) throws Exception {
        int level = 0;
        try {
            //更新装备
            Map CmMpEquip_map = (Map) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
            Object obj = CmMpEquip_map.get(cardId);
            if (obj != null) {
                CmMpEquip equip = (CmMpEquip) obj;
                level = randFuncationBean.randEquipUpVal(vip);//获得底层随机等级
                if (level > 0) {
                    //扣除银币
                    mpcommonBo.consum_silver(userId, silver);
                    equip.setEquipLevel(equip.getEquipLevel() + level);
                    CmMpEquip_map.put(equip.getMpEquipId(), equip);
                    ch.putObjectToCache(CacheNames.USER_EQUIP_CACHE, userId, CmMpEquip_map);
                    change.getCv().getCc().add(PackageCardBo.getEquipCard(equip.getMpEquipId(), equip.getEquipId(), equip.getEquipLevel(), equip.getRefiningLevel(), equip.getRefiningExp(), CardStatusEnum.add.value()));

                    //int userId, int codeId, int exp, int level 增加成就
                    AchieveVo achieveVo = achieveBo.saveAchieve(userId, 150010010, 0, equip.getEquipLevel());
                    if (achieveVo != null) {
                        Map<String, Object> m = new HashMap<String, Object>();
                        List<CJAchieveData> lt = new ArrayList<CJAchieveData>();
                        CJAchieveData cd = new CJAchieveData();
                        cd.setId(150010010);
                        cd.setLv(achieveVo.getLv());
                        m.put(ClientMapKeyEnum.achive.value(), lt.add(cd));
                        change.setAh(m);
                    }

                    if (equip.getEquipLevel() >= 80) {
                        noteBoardService.addNodeBoardMsg(MsgMode.equipment_strengthen, vo.getUserId(), vo.getMpName(), cdEquip.getId(), cdEquip.getName(), level);
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(EquipBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return change;
    }
    //更换，使用装备

    public boolean replace(int down_cardId, int up_carsId, int userId, int site, int battleId) throws Exception {
        boolean ble = false;
        try {
            Map CmMpEquip_map = (Map) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
            Object down_obj = CmMpEquip_map.get(down_cardId);
            Object up_obj = CmMpEquip_map.get(up_carsId);
            if (up_obj != null) {
                CmMpEquip CmMpEquip_up = (CmMpEquip) up_obj;
                if (down_obj == null) {
                    CmMpEquip_up.setEquipSite(site);
                    CmMpEquip_up.setBattleDIscipleId(battleId);
                    CmMpEquip_map.put(CmMpEquip_up.getMpEquipId(), CmMpEquip_up);
                } else {
                    CmMpEquip CmMpEquip_down = (CmMpEquip) down_obj;
                    CmMpEquip_up.setEquipSite(CmMpEquip_down.getEquipSite());
                    CmMpEquip_up.setBattleDIscipleId(battleId);
                    CmMpEquip_down.setEquipSite(0);
                    CmMpEquip_down.setBattleDIscipleId(0);
                    CmMpEquip_map.put(CmMpEquip_down.getMpEquipId(), CmMpEquip_down);
                    CmMpEquip_map.put(CmMpEquip_up.getMpEquipId(), CmMpEquip_up);
                }
                ch.putObjectToCache(CacheNames.USER_EQUIP_CACHE, userId, CmMpEquip_map);
            }
            ble = true;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return ble;
    }

    //根据位置查找装备
    public CmMpEquip getCmMpEquipFromCacheBySite(int userId, int battleId, int site) {
        Map<Integer, CmMpEquip> cmMpProps_map = (Map<Integer, CmMpEquip>) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
        if (cmMpProps_map != null) {
            Map map = (Map) cmMpProps_map;
            Iterator barriers_data_map_type_it = map.entrySet().iterator();
            while (barriers_data_map_type_it.hasNext()) {
                Map.Entry entry_type = (Map.Entry) barriers_data_map_type_it.next();
//                    int  cardId =  (Integer) entry_type.getKey();
                CmMpEquip cmMpEquip = (CmMpEquip) entry_type.getValue();
                if (cmMpEquip.getEquipSite() == site && cmMpEquip.getBattleDIscipleId() == battleId) {
                    return cmMpEquip;
                }
            }
        }
        return null;
    }
    //根据位置查找装备

    public List<CmMpEquip> getCmMpEquipFromCacheByCardSite(int userId, int battliId) {
        List<CmMpEquip> list = new ArrayList();
        Map<Integer, CmMpEquip> cmMpProps_map = (Map<Integer, CmMpEquip>) ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
        if (cmMpProps_map != null && !cmMpProps_map.isEmpty()) {
            for (Map.Entry entry_type : cmMpProps_map.entrySet()) {
//                    int  cardId =  (Integer) entry_type.getKey();
                CmMpEquip cmMpEquip = (CmMpEquip) entry_type.getValue();
                if (cmMpEquip.getBattleDIscipleId() == battliId) {
                    list.add(cmMpEquip);
                }
            }
        }
        return list;
    }
}
