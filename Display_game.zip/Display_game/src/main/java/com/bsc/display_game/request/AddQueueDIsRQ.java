/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class AddQueueDIsRQ extends ReceiveJson {

    @JsonProperty("id")
    private int disCardId;
    @JsonProperty("p")
    private int site;

    public int getDisCardId() {
        return disCardId;
    }

    public void setDisCardId(int disCardId) {
        this.disCardId = disCardId;
    }

    public int getSite() {
        return site;
    }

    public void setSite(int site) {
        this.site = site;
    }
}
