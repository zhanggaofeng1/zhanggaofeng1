/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;


import com.bsc.display_game.service.QueueService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import static com.opensymphony.xwork2.Action.SUCCESS;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/queue")
public class QueueAction extends SuperAction {

    @Resource
    private QueueService queueService;

    @Action(value = "list", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String list() {
        try {
            queueService.getQueueList(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "adddis", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String adddis() {
        try {
            queueService.addQueueDIs(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "editcardsite", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String editcardsite() {
        try {
            queueService.editCardSite(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "editqueue", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String editqueue() {
        try {
            queueService.changeQueue(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
    
    
}
