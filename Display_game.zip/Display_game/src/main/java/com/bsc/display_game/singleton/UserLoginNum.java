/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.singleton;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author lxf
 */
public class UserLoginNum {
    private static UserLoginNum uniqueInstance = null;
    private static Set<Integer> user_set;
    public static UserLoginNum getInstance() {
       if (uniqueInstance == null) {
           uniqueInstance = new UserLoginNum();
       }
       return uniqueInstance;
    }

    public UserLoginNum() {
        user_set = new HashSet<Integer>();
    }

   public void add(int userId){
       user_set.add(userId);
   }
    public void del(int userId){
        user_set.remove(userId);
    }
    
    public int getOnLineUserNum(){
        return user_set.size();
    }
    
    public static Set<Integer> getUser_set() {
        return user_set;
    }

    public static void setUser_set(Set<Integer> user_set) {
        UserLoginNum.user_set = user_set;
    }
    
    
    
   
}
