/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.vo;

/**
 *
 * @author lxf
 */
public class ReturnStatusVo {
     private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
