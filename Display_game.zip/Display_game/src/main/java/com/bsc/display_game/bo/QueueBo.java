/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.clinet.command.response.CJAchieveData;
import com.bsc.commonproject.clinet.command.response.CJFData;
import com.bsc.commonproject.clinet.command.response.CJFMember;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CmBattleDisciple;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpEquip;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpGestZhenqi;
import com.bsc.protracted.domin.CmMpLineup;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;

import com.bsc.util.datas.StringUtil;
import com.bsc.util.json.JsonHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class QueueBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private GestBo gestBo;
    @Resource
    private EquipBo equipBo;
    @Resource
    private ZhenQiBo zhenqiBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private AchieveBo achieveBo;
    @Resource
    private MenPaiBo mpBo;
    private static final Logger log = LoggerFactory.getLogger(QueueBo.class);

    //弟子阵型位置变更，上阵新弟子
    public void replace(int site, int cardId, int userId) throws Exception {
        try {
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            Map<Integer, CmBattleDisciple> lineup_map = (Map<Integer, CmBattleDisciple>) ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
            if (lineup_map == null || lineup_map.isEmpty()) {
                lineup_map = new HashMap<Integer, CmBattleDisciple>();
            }
            Object obj = lineup_map.get(site);
            CmBattleDisciple cmBattleDisciple = null;
            if (obj != null) {
                cmBattleDisciple = (CmBattleDisciple) lineup_map.get(site);
                cmBattleDisciple.setUserid(userId);
                cmBattleDisciple.setDisId(cardId);
                lineup_map.put(site, cmBattleDisciple);
                if (vo != null && vo.getCmMpLineup() != null) {
                    changeQueue(userId, vo.getCmMpLineup().getBitArray() + "," + (site - 1));
                }
                //抹掉真气
                remove_zq(userId, cmBattleDisciple.getBattleId());

            } else {
                cmBattleDisciple = new CmBattleDisciple();
                cmBattleDisciple.setDisId(cardId);
                cmBattleDisciple.setLineupSite(site);
                cmBattleDisciple.setUserid(userId);
                int lineupid = save(cmBattleDisciple);
                cmBattleDisciple.setBattleId(lineupid);
                lineup_map.put(site, cmBattleDisciple);
                if (vo != null && vo.getCmMpLineup() != null) {
                    changeQueue(userId, vo.getCmMpLineup().getBitArray() + "," + (site - 1));
                }
            }
            ch.putObjectToCache(CacheNames.USER_LINEUP_CACHE, userId, lineup_map);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //抹掉真气标记
    public void remove_zq(int userId, int battleDIscipleId) throws Exception {
        try {
            Map cmMpGestZhenqi_map = (Map) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
            if (cmMpGestZhenqi_map != null && !cmMpGestZhenqi_map.isEmpty()) {
                Iterator barriers_data_map_type_it = cmMpGestZhenqi_map.entrySet().iterator();
                while (barriers_data_map_type_it.hasNext()) {
                    Map.Entry entry_type = (Map.Entry) barriers_data_map_type_it.next();
//                    int  cardId =  (Integer) entry_type.getKey();
                    CmMpGestZhenqi cMpGestZhenqi = (CmMpGestZhenqi) entry_type.getValue();
                    if (cMpGestZhenqi.getBattleDIscipleId() == battleDIscipleId) {
                        cMpGestZhenqi.setZhenqiSite(0);
                        cMpGestZhenqi.setBattleDIscipleId(0);
                        cmMpGestZhenqi_map.put(cMpGestZhenqi.getMpZhenqiId(), cMpGestZhenqi);
                    }
                }
                ch.putObjectToCache(CacheNames.USER_ZHENQI_CACHE, userId, cmMpGestZhenqi_map);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public Object[] getCJFData(int userId, boolean is_lodd_card) throws Exception {
        CJFData fd = new CJFData();
        List<Integer> codeIdsLt = new ArrayList<Integer>();
        List<CJFMember> cjm_lt = new ArrayList();
        List lt = new ArrayList();
        //查找卡槽位
        MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
        if (vo == null) {
            return getCJFDataFomDB(userId, is_lodd_card, codeIdsLt);
        }
        if (vo.getCmMpLineup() == null) {
            log.error("vo.getCmMpLineup() is null");
            return null;
        }
        if (!StringUtil.isNotNull(vo.getCmMpLineup().getBitArray()) && vo.getCmMpLineup().getBitArray().indexOf(",") <= 0) {
            log.error("&vo.getCmMpLineup().getBitArray() data error");
            return null;
        }
        String[] cardSite = vo.getCmMpLineup().getBitArray().split(",");
        StringBuilder strb = new StringBuilder();
        int z = 0;
        //查找卡槽位对应的各种数据
        Map<Integer, CmBattleDisciple> battle_map = (Map<Integer, CmBattleDisciple>) ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
        if (battle_map == null || battle_map.isEmpty()) {
            CmMenpai mp = mpcommonBo.getMenpaiFromDB(userId);
            mpcommonBo.valiteCacheDate(mp);
            battle_map = (Map<Integer, CmBattleDisciple>) ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
        }

        Map<Integer, CmMpDisciple> cmMpDisciple_map = (Map<Integer, CmMpDisciple>) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);

        for (String str : cardSite) {
            //索引位置
            CmBattleDisciple bd = (CmBattleDisciple) battle_map.get(Integer.parseInt(str.trim()) + 1);
            if (bd != null) {
                z++;
                strb.append(str).append(",");
                CJFMember cm = new CJFMember();
                cm.setIdx(bd.getLineupSite() - 1);
                //弟子ID
                cm.setId(bd.getDisId());
                CmMpDisciple cmMpDisciple = (CmMpDisciple) cmMpDisciple_map.get(bd.getDisId());
                if (cmMpDisciple != null) {
                    codeIdsLt.add(cmMpDisciple.getDiscipleId());
                    if (is_lodd_card) {
                        //封装门徒卡牌
                        lt.add(PackageCardBo.getDicCardAll(cmMpDisciple.getDisLevel(), cmMpDisciple.getTupoLevel(), cmMpDisciple.getDisExp(), cmMpDisciple.getDisAtk(), cmMpDisciple.getDisDef(), cmMpDisciple.getDisHp(), cmMpDisciple.getDisMp(), cmMpDisciple.getDisPotential(), cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                        //天生法术
                        CmMpGest gest = cmMpDisciple.getCmMpGest();
                        lt.add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), CardStatusEnum.add.value()));
                    }
                }
                //装备
                List<CmMpEquip> eqlt = equipBo.getCmMpEquipFromCacheByCardSite(userId, bd.getBattleId());
                for (CmMpEquip equip : eqlt) {
                    codeIdsLt.add(equip.getEquipId());
                    cm.getIl().add((equip.getEquipSite() - 1) + ":" + equip.getMpEquipId());
                    if (is_lodd_card) {
                        lt.add(PackageCardBo.getEquipCard(equip.getMpEquipId(), equip.getEquipId(), equip.getEquipLevel(), equip.getRefiningLevel(), equip.getRefiningExp(), CardStatusEnum.add.value()));
                    }
                }
                //武功
                List<CmMpGest> gelt = gestBo.getCmMpGestFromCacheByCardSite(userId, bd.getBattleId());
                for (CmMpGest gest : gelt) {
                    codeIdsLt.add(gest.getGestId());
                    cm.getIl().add((gest.getGestSite() - 1) + ":" + gest.getMpGestId());
                    if (is_lodd_card) {
                        lt.add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), CardStatusEnum.add.value()));
                    }
                }
                //真气
                List<CmMpGestZhenqi> zqlt = zhenqiBo.getCmMpZhenQiFromCacheByCardSite(userId, bd.getBattleId());
                for (CmMpGestZhenqi zq : zqlt) {
                    codeIdsLt.add(zq.getZhenqiId());
                    cm.getIl().add((zq.getZhenqiSite() - 1) + ":" + zq.getMpZhenqiId());
                    if (is_lodd_card) {
                        lt.add(PackageCardBo.getZhenQiCard(zq.getMpZhenqiId(), zq.getZhenqiId(), zq.getZhenqiLevel(), zq.getZhenqiExp(), CardStatusEnum.add.value()));
                    }
                }
                cjm_lt.add(cm);
            }
        }
        if (cardSite.length != z && StringUtil.isNotNull(strb.toString()) && strb.toString().indexOf(",") > 0) {
            changeQueue(userId, strb.toString().substring(0, strb.toString().length() - 1));
        }
        fd.setAc(achieveBo.getCJAchieveDataList(userId));
        fd.setQs(achieveBo.getAchieveValue(userId));
        fd.setL(cjm_lt);
        fd.setLc(lt);
        Object[] objs = new Object[2];
        objs[0] = fd;
        objs[1] = codeIdsLt;

        return objs;
    }

    public Object[] getCJFDataFomDB(int userId, boolean is_lodd_card, List<Integer> codeIdsLt) throws Exception {
        Object[] objs = new Object[2];
        List<CJFMember> cjm_lt = new ArrayList();
        List lt = new ArrayList();
        //查找卡槽位
        CmMenpai cmMenpai = mpcommonBo.getMenpaiFromDB(userId);
        if (cmMenpai == null) {
            return null;
        }
        CJFData fd = new CJFData();
        if (cmMenpai.getCmMpLineup() == null) {
            log.error("vo.getCmMpLineup() is null");
            return null;
        }
        if (!StringUtil.isNotNull(cmMenpai.getCmMpLineup().getBitArray()) && cmMenpai.getCmMpLineup().getBitArray().indexOf(",") <= 0) {
            log.error("&vo.getCmMpLineup().getBitArray() data error");
            return null;
        }
        String[] cardSite = cmMenpai.getCmMpLineup().getBitArray().split(",");
        StringBuilder strb = new StringBuilder();
        int z = 0;
        //查找卡槽位对应的各种数据
        Map<Integer, CmBattleDisciple> battle_map = cmMenpai.getCmBattleDisciples();
        Map<Integer, CmMpDisciple> cmMpDisciple_map = cmMenpai.getCmMpDisciples();
        for (String str : cardSite) {
            CJFMember cm = new CJFMember();
            //索引位置
            CmBattleDisciple bd = (CmBattleDisciple) battle_map.get(Integer.parseInt(str.trim()) + 1);
            if (bd != null) {
                cm.setIdx(bd.getLineupSite() - 1);
                //弟子ID
                cm.setId(bd.getDisId());

                CmMpDisciple cmMpDisciple = (CmMpDisciple) cmMpDisciple_map.get(bd.getDisId());
                if (cmMpDisciple != null) {
                    codeIdsLt.add(cmMpDisciple.getDiscipleId());
                    if (is_lodd_card) {
                        //封装门徒卡牌
                        lt.add(PackageCardBo.getDicCardAll(cmMpDisciple.getDisLevel(), cmMpDisciple.getTupoLevel(), cmMpDisciple.getDisExp(), cmMpDisciple.getDisAtk(), cmMpDisciple.getDisDef(), cmMpDisciple.getDisHp(), cmMpDisciple.getDisMp(), cmMpDisciple.getDisPotential(), cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                        //天生法术
                        CmMpGest gest = cmMpDisciple.getCmMpGest();
                        lt.add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), CardStatusEnum.add.value()));
                    }
                }
                //装备
                Map<Integer, CmMpEquip> cmMpEquip_map = cmMenpai.getCmMpEquips();
                for (Map.Entry entry_type : cmMpEquip_map.entrySet()) {
                    CmMpEquip equip = (CmMpEquip) entry_type.getValue();
                    if (equip.getBattleDIscipleId() == bd.getBattleId()) {
                        codeIdsLt.add(equip.getEquipId());
                        cm.getIl().add((equip.getEquipSite() - 1) + ":" + equip.getMpEquipId());
                        if (is_lodd_card) {
                            lt.add(PackageCardBo.getEquipCard(equip.getMpEquipId(), equip.getEquipId(), equip.getEquipLevel(), equip.getRefiningLevel(), equip.getRefiningExp(), CardStatusEnum.add.value()));
                        }
                    }
                }
                //武功
                Map<Integer, CmMpGest> cmMpGest_map = cmMenpai.getCmMpGests();
                for (Map.Entry entry_type : cmMpGest_map.entrySet()) {
                    CmMpGest gest = (CmMpGest) entry_type.getValue();
                    if (gest.getBattleDIscipleId() == bd.getBattleId()) {
                        codeIdsLt.add(gest.getMpGestId());
                        cm.getIl().add((gest.getGestSite() - 1) + ":" + gest.getMpGestId());
                        if (is_lodd_card) {
                            lt.add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), CardStatusEnum.add.value()));
                        }
                    }
                }
                //真气
                Map<Integer, CmMpGestZhenqi> zq_map = cmMenpai.getCmMpGestZhenqis();
                for (Map.Entry entry_type : zq_map.entrySet()) {
                    CmMpGestZhenqi zq = (CmMpGestZhenqi) entry_type.getValue();
                    if (zq.getBattleDIscipleId() == bd.getBattleId()) {
                        codeIdsLt.add(zq.getMpZhenqiId());
                        cm.getIl().add((zq.getZhenqiSite() - 1) + ":" + zq.getMpZhenqiId());
                        if (is_lodd_card) {
                            lt.add(PackageCardBo.getZhenQiCard(zq.getMpZhenqiId(), zq.getZhenqiId(), zq.getZhenqiLevel(), zq.getZhenqiExp(), CardStatusEnum.add.value()));
                        }
                    }
                }
                cjm_lt.add(cm);
            }
        }
        if (cardSite.length != z && StringUtil.isNotNull(strb.toString()) && strb.toString().indexOf(",") > 0) {
            changeQueue(userId, strb.toString().substring(0, strb.toString().length() - 1));
        }

        List<CJAchieveData> alt = new ArrayList<CJAchieveData>();
        if (cmMenpai.getCmMpAchievement() != null && cmMenpai.getCmMpAchievement().getAchieveData() != null && StringUtil.isNotNull(cmMenpai.getCmMpAchievement().getAchieveData())) {
            Map<Integer, AchieveVo> map = (Map<Integer, AchieveVo>) JsonHelper.getBeanFromJson(cmMenpai.getCmMpAchievement().getAchieveData(), Map.class);
            for (Map.Entry entry_type : map.entrySet()) {
                String codeId = (String) entry_type.getKey();
                Map m = (Map) entry_type.getValue();
                AchieveVo achieveVo = AchieveVo.maptovo(m);
                alt.add(achieveBo.getCJAchieveData(Integer.parseInt(codeId), achieveVo.getLv(), achieveVo.getExp()));
            }
            fd.setQs(cmMenpai.getCmMpAchievement().getAchieveValue());
        }
        fd.setAc(alt);
        fd.setL(cjm_lt);
        fd.setLc(lt);

        objs[0] = fd;
        objs[1] = codeIdsLt;
        return objs;
    }

    //便利用户头像数据并存储至内存
    public void getUserPicture(int userId, String mpName, int level) throws Exception {
        try {
            UserPictureVo picvo = null;
            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, userId);
            if (obj != null) {
                picvo = (UserPictureVo) obj;
            } else {
                picvo = new UserPictureVo();
                picvo.setName(mpName);
                picvo.setLevel(level);
            }
            //查找卡槽位
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (vo.getCmMpLineup() == null || !StringUtil.isNotNull(vo.getCmMpLineup().getBitArray())) {
                log.error("vo.getCmMpLineup() is null");
            }

            String[] cardSite = vo.getCmMpLineup().getBitArray().split(",");
            //查找卡槽位对应的各种数据
            Map<Integer, CmBattleDisciple> battle_map = (Map<Integer, CmBattleDisciple>) ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
            if (battle_map == null || battle_map.isEmpty()) {
                CmMenpai mp = mpcommonBo.getMenpaiFromDB(userId);
                ch.putObjectToCache(CacheNames.USER_LINEUP_CACHE, userId, mp.getCmBattleDisciples());
            }

            Map<Integer, CmMpDisciple> cmMpDisciple_map = (Map<Integer, CmMpDisciple>) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
            if (cmMpDisciple_map == null || cmMpDisciple_map.isEmpty()) {
                CmMenpai mp = mpcommonBo.getMenpaiFromDB(userId);
                ch.putObjectToCache(CacheNames.USER_DISCIPLE_CACHE, userId, mp.getCmMpDisciples());
            }
            int i = 0;
            if (picvo.getDisCodeIds() != null && picvo.getDisCodeIds().size() > 0) {
                picvo.getDisCodeIds().clear();
            }
            for (String str : cardSite) {
                i++;
                //索引位置
                CmBattleDisciple bd = (CmBattleDisciple) battle_map.get(Integer.parseInt(str.trim()) + 1);
                //弟子ID
                CmMpDisciple cmMpDisciple = (CmMpDisciple) cmMpDisciple_map.get(bd.getDisId());
                //封装门徒卡牌
                picvo.getDisCodeIds().add(cmMpDisciple.getDiscipleId());
            }
            ch.putObjectToCache(CacheNames.USER_PICTURE_DATA_CACHE, userId, picvo);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void getUserPictureFromDB(CmMenpai mp) throws Exception {
        try {
            UserPictureVo picvo = new UserPictureVo();
            picvo.setName(mp.getMpName());
            picvo.setLevel(mp.getMpLevel());
            picvo.setVip(mp.getMpVip());
            //查找卡槽位
            if (mp.getCmMpLineup() == null || !StringUtil.isNotNull(mp.getCmMpLineup().getBitArray())) {
                log.error("vo.getCmMpLineup() is null");
            }

            String[] cardSite = mp.getCmMpLineup().getBitArray().split(",");
            //查找卡槽位对应的各种数据
            Map<Integer, CmBattleDisciple> battle_map = mp.getCmBattleDisciples();
            Map<Integer, CmMpDisciple> cmMpDisciple_map = mp.getCmMpDisciples();
            for (String str : cardSite) {
                //索引位置
                CmBattleDisciple bd = (CmBattleDisciple) battle_map.get(Integer.parseInt(str.trim()) + 1);
                //弟子ID
                CmMpDisciple cmMpDisciple = (CmMpDisciple) cmMpDisciple_map.get(bd.getDisId());
                if (cmMpDisciple != null) {
                    //封装门徒卡牌
                    picvo.getDisCodeIds().add(cmMpDisciple.getDiscipleId());
                }
            }
            ch.putObjectToCache(CacheNames.USER_PICTURE_DATA_CACHE, mp.getMpId(), picvo);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void changeQueue(int userId, String lineup) throws Exception {
        try {
            //修改阵型数据
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            CmMpLineup cmMpLineup = vo.getCmMpLineup();
            if (lineup.indexOf(",") > 0) {
                String[] strs = lineup.split(",");
                List<String> lt = new ArrayList<String>();
                for (int i = 0; i < strs.length; i++) {
                    if (!lt.contains(strs[i].trim())) {
                        lt.add(strs[i].trim());
                    }
                }
                StringBuilder strb = new StringBuilder();
                for (String i : lt) {
                    strb.append(i).append(",");
                }
                lineup = strb.toString().substring(0, strb.toString().length() - 1);
                lt = null;
            }

            if (cmMpLineup == null) {
                cmMpLineup = new CmMpLineup();
                cmMpLineup.setBitArray(lineup);
                cmMpLineup.setUserId(userId);
                int id = save(cmMpLineup);
                cmMpLineup.setMpLineupId(id);
                //更新数据
                CmMenpai cmMenpai = (CmMenpai) get(CmMenpai.class, userId);
                if (cmMenpai != null) {
                    cmMenpai.setLineupId(id);
                    update(cmMenpai);
                }

            } else {
                cmMpLineup.setBitArray(lineup);
                update(cmMpLineup);
            }
            vo.setCmMpLineup(cmMpLineup);

            ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, userId, vo);
            //修改存储用户头像数据
            getUserPicture(userId, vo.getMpName(), vo.getMpLevel());

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public int find_battle_disciple(int userId, int queue_site) throws Exception {
        try {
            Map<Integer, CmBattleDisciple> battle_map = (Map<Integer, CmBattleDisciple>) ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
            for (Map.Entry entry_type : battle_map.entrySet()) {
                CmBattleDisciple cmBattleDisciple = (CmBattleDisciple) entry_type.getValue();
                if (cmBattleDisciple.getLineupSite() == queue_site) {
                    return cmBattleDisciple.getBattleId();
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return 0;
    }

    public boolean is_dis_up_battle(int userId, int dis_cardId) throws Exception {
        try {
            Map<Integer, CmBattleDisciple> battle_map = (Map<Integer, CmBattleDisciple>) ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(userId);
            String[] linups = null;
            if (vo.getCmMpLineup() != null && vo.getCmMpLineup().getBitArray() != null && StringUtil.isNotNull(vo.getCmMpLineup().getBitArray())) {
                linups = vo.getCmMpLineup().getBitArray().split(",");
            }
            for (Map.Entry entry_type : battle_map.entrySet()) {
                CmBattleDisciple cmBattleDisciple = (CmBattleDisciple) entry_type.getValue();
                if (cmBattleDisciple.getDisId() == dis_cardId) {
                    return false;
                }
//                if (cmBattleDisciple.getDisId() == dis_cardId) {
//                    if (linups != null) {
//                        for (String str : linups) {
//                            if (Integer.parseInt(str) == cmBattleDisciple.getLineupSite()) {
//                                return false;
//                            }
//                        }
//                    }
//                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return true;
    }

    public void addUserInPicture(int userId) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, userId);
            if (obj == null) {
                MenPaiCacheVo uvo = mpcommonBo.getCmMenpaiFromCache(userId);
                if (uvo != null) {
                    getUserPicture(userId, uvo.getMpName(), uvo.getMpLevel());
                } else {
                    CmMenpai mp = mpcommonBo.getMenpaiFromDB(userId);
                    if (mp != null) {
                        getUserPictureFromDB(mp);
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
