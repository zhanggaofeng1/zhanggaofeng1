/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;


import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class EditCardSiteRQ extends ReceiveJson {

    @JsonProperty("id")
    private int cardId;
    @JsonProperty("idx")
    private int queueSite;//阵容位置
    @JsonProperty("it")
    private int equipType;//装备类别
    @JsonProperty("p")
    private int equipSite;//装备位置

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public int getQueueSite() {
        return queueSite;
    }

    public void setQueueSite(int queueSite) {
        this.queueSite = queueSite;
    }

    public int getEquipType() {
        return equipType;
    }

    public void setEquipType(int equipType) {
        this.equipType = equipType;
    }

    public int getEquipSite() {
        return equipSite;
    }

    public void setEquipSite(int equipSite) {
        this.equipSite = equipSite;
    }

   
    
    
    
    
}
