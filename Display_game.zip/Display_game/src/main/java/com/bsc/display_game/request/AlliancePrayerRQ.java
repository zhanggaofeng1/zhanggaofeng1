/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class AlliancePrayerRQ extends ReceiveJson{
     @JsonProperty("pt")
    private int prayerType;

    public int getPrayerType() {
        return prayerType;
    }

    public void setPrayerType(int prayerType) {
        this.prayerType = prayerType;
    }
    
    
    
    
}
