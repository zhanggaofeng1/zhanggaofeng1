/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.CJAMember;
import com.bsc.commonproject.clinet.command.response.CJAlliance;
import com.bsc.commonproject.clinet.command.response.CJCompetitor;
import com.bsc.commonproject.clinet.command.response.RPAlliance;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPCreateAlliance;
import com.bsc.commonproject.clinet.command.response.RPSearchAList;
import com.bsc.commonproject.clinet.command.response.RPSearchAMList;
import com.bsc.commonproject.clinet.command.response.RPSearchPlayerList;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.FixTimeCleanMapKey;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.Message;
import com.bsc.commonproject.vo.ResItem;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.display_game.bo.AllianceBo;
import com.bsc.display_game.bo.CommonBo;
import com.bsc.display_game.bo.MenPaiBo;
import com.bsc.display_game.bo.QueueBo;
import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.constants.AllianceOperationEnum;
import com.bsc.display_game.constants.DataConstants;
import com.bsc.display_game.request.AllianceApplyRQ;
import com.bsc.display_game.request.AllianceBuyRQ;
import com.bsc.display_game.request.AllianceDateRQ;
import com.bsc.display_game.request.AllianceDisbandRQ;
import com.bsc.display_game.request.AllianceListRQ;
import com.bsc.display_game.request.AllianceMemberRQ;
import com.bsc.display_game.request.AlliancePayRQ;
import com.bsc.display_game.request.AllianceOperateRQ;
import com.bsc.display_game.request.AlliancePrayerRQ;
import com.bsc.display_game.request.AllianceQuitRQ;
import com.bsc.display_game.request.AllanceCreateRQ;
import com.bsc.display_game.request.AllianceFindUserRQ;
import com.bsc.display_game.request.MessageReturnRQ;
import com.bsc.display_game.service.AllianceService;
import com.bsc.display_game.vo.AllianceVo;
import com.bsc.display_game.vo.MemberVo;
import com.bsc.display_game.vo.RankVo;
import com.bsc.displaybases.SuperAction;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.CommMsgBean;
import com.bsc.message.server.FactionService;
import com.bsc.message.server.LevelMsgService;
import com.bsc.message.server.SystemMsgService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdUnion;
import com.bsc.protracted.domin.CmAlliance;
import com.bsc.protracted.domin.CmAllianceMember;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.datas.DateUtil;
import com.bsc.util.datas.StringUtil;
import com.bsc.util.json.JsonHelper;
import com.bsc.util.list.BSCLinkedMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class AllianceBean extends DaosPublic implements AllianceService {

    private static final Logger log = LoggerFactory.getLogger(AllianceBean.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private AllianceBo allianceBo;
    @Resource
    private CommonBo commonBo;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private LevelMsgService levelMsgService;
    @Resource
    private SystemMsgService systemMsgService;
    @Resource
    private CommMsgBean commMsgBean;
    @Resource
    private FactionService factionService;
    @Resource
    private SaveLogBo saveLogBo;
    @Resource
    private RankBo rankBo;
    @Resource
    private QueueBo queueBo;

    public void create(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllanceCreateRQ create = (AllanceCreateRQ) JsonHelper.getBeanFromJson(json, AllanceCreateRQ.class);
            int userId = create.getUserid();
            String allianceName = create.getName();
            RPCreateAlliance pa = new RPCreateAlliance();
            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                if (vo.getMpVip() > 1) {
                    if (vo.getMpGold() >= 10) {
                        CmAlliance alliance = allianceBo.find_alliance_userId(userId);
                        if (alliance == null && allianceName != null && StringUtil.isNotNull(allianceName)) {
                            //验证联盟名字是否粗存在
                            List list = get(CmAlliance.class, "allianceName", allianceName, true);
                            if (list == null || list.isEmpty()) {
                                CmAlliance cl = new CmAlliance();
                                cl.setAllianceName(allianceName);
                                cl.setCreateUserId(userId);
                                cl.setAllanceExp(0);
                                cl.setAllanceLevel(1);
                                cl.setCreateDate(DateUtil.getCurrentDate());
                                int allianceId = save(cl);
                                cl.setAllianceId(allianceId);

                                CmAllianceMember cm = new CmAllianceMember();
                                cm.setAllianceId(allianceId);
                                cm.setPost(DataConstants.ALLIANCE_POST_MENGZHU);
                                cm.setUserId(userId);
                                cm.setDevoteValue(0);
                                int memberId = save(cm);
                                cm.setMemberId(memberId);
                                cl.getMembers().put(userId, cm);

                                ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId, (CmAlliance) get(CmAlliance.class, allianceId));
                                //修改用户加入联盟状态
                                allianceBo.edit_user_AllianceId(userId, allianceId);
                                pa.setId(allianceId);
                                mpcommonBo.consum_gold(userId, 10);
                                pa.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(10)));

                                pa.setSt(ErrorCodeEnum.normal_success.value());
                            } else {
                                pa.setSt(ErrorCodeEnum.alliance_have_exist.value());
                            }
                        } else {
                            pa.setSt(ErrorCodeEnum.info_error_must_data_null.value());
                        }
                    } else {
                        pa.setSt(ErrorCodeEnum.gold_not_enough.value());
                    }
                } else {
                    pa.setSt(ErrorCodeEnum.mp_vip_lev_no_enough.value());
                }
            } else {
                pa.setSt(ErrorCodeEnum.user_not_exist.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(pa));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void apply(SuperAction sa) throws Exception {
        try {
            RPState publicRP = new RPState();
            String json = sa.getRequestJson();
            AllianceApplyRQ apply = (AllianceApplyRQ) JsonHelper.getBeanFromJson(json, AllianceApplyRQ.class);
            int userId = apply.getUserid();
            int allianceId = apply.getAllianceId();
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null && vo.getAllianceId() == 0) {
                // int senderId, String senderName, int mpLev, int rank, int factionId
                RankVo rankvo = rankBo.getUserRankDataFromUserId(userId);
                int rank = 0;
                if (rankvo != null) {
                    rank = rankvo.getSite() + 1;
                }
                //int senderId, String senderName, int mpLev, int rank, int factionId
                factionService.someOneRequestJoinFaction(vo.getUserId(), vo.getMpName(), vo.getMpLevel(), rank, allianceId);
                publicRP.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                publicRP.setSt(ErrorCodeEnum.alliance_have_exist.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void memeberlist(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceMemberRQ ml = (AllianceMemberRQ) JsonHelper.getBeanFromJson(json, AllianceMemberRQ.class);
            int userId = ml.getUserid();
            int allianceId = ml.getAllianceId();
            RPSearchAMList aml = new RPSearchAMList();
            CmAlliance cmAlliance = allianceBo.find_alliance(allianceId);
            if (cmAlliance != null) {
                List<MemberVo> nl = new ArrayList<MemberVo>();
                List<Integer> userId_lt = new ArrayList<Integer>();
                Map<Integer, CmAllianceMember> memebers = cmAlliance.getMembers();
                for (Map.Entry entry_type : memebers.entrySet()) {
                    CmAllianceMember member = (CmAllianceMember) entry_type.getValue();
//                    Object picture_obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, member.getUserId());
                    Object picture_obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, member.getUserId());
                    if (picture_obj == null) {
                        queueBo.addUserInPicture(member.getUserId());
                        picture_obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, member.getUserId());
                    }
                    if (picture_obj != null) {
                        //获取用户的名称和等级
                        MemberVo allianceVo = new MemberVo();
                        UserPictureVo picture = (UserPictureVo) picture_obj;

                        allianceVo.setName(picture.getName());
                        allianceVo.setPostId(member.getPost());
                        allianceVo.setLevel(picture.getLevel());
                        allianceVo.setDevote(member.getDevoteValue());
                        allianceVo.setUserId(member.getUserId());
                        nl.add(allianceVo);
                        userId_lt.add(member.getUserId());
                    }
                }
                //封装返回数据
                int i = -1;
                for (MemberVo vo : nl) {
                    i++;
                    CJAMember m = new CJAMember();

                    m.setCv(vo.getDevote());
                    Map map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
                    Object devote_obj = map.get(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE);
                    int devote = 0;
                    if (devote_obj != null) {
                        devote = Integer.parseInt((String) devote_obj);
                    }
                    m.setCvt(devote);
                    m.setPost(vo.getPostId());
                    RankVo rankVo = rankBo.getUserRankDataFromUserId(vo.getUserId());
                    int rank = 0;
                    if (rankVo != null) {
                        rank = rankVo.getSite() + 1;
                    }
                    m.setRank(rank);
                    m.setId(vo.getUserId());
                    m.setLv(vo.getLevel());
                    m.setN(vo.getName());

                    aml.getAmlist().add(m);
                }
                aml.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                aml.setSt(ErrorCodeEnum.alliance_not_exist.value());
            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(aml));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void alliancelist(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceListRQ al = (AllianceListRQ) JsonHelper.getBeanFromJson(json, AllianceListRQ.class);
            int userId = al.getUserid();
            String name = al.getName();
            RPSearchAList alt = new RPSearchAList();
            List<AllianceVo> volt = allianceBo.getAllianceRank(name, 1, 20);
            int i = 0;
            for (AllianceVo vo : volt) {
                i++;
                CJAlliance ci = new CJAlliance();
                ci.setCid(vo.getAlliance().getCreateUserId());
                ci.setCn(vo.getUserName());
                ci.setExp(vo.getAlliance().getAllanceExp());
                ci.setId(vo.getAlliance().getAllianceId());
                ci.setLv(vo.getAlliance().getAllanceLevel());
                ci.setMc(vo.getAlliance().getMembers().size());
                ci.setN(vo.getAlliance().getAllianceName());
                ci.setRk(i);
                alt.getAlist().add(ci);
            }
//            CmAllianceMember member = allianceBo.is_alliance_member(userId);
//            CJAMember m = new CJAMember();
//            m.setCv(member.getDevoteValue());
//            m.setPost(member.getPost());
//            m.setRank(devote);
//            Object site_obj = site_lt.get(i);
//            int rank = 0;
//            if (site_obj != null) {
//                rank = (Integer) site_obj;
//            }
//            m.setRank(rank);

            alt.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(alt));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void applyresult(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            RPState ps = new RPState();
            MessageReturnRQ ar = (MessageReturnRQ) JsonHelper.getBeanFromJson(json, MessageReturnRQ.class);
            int userId = ar.getUserid();
            int messageId = ar.getMessageId();
            int messageType = ar.getMessageType();
            String result = ar.getResult();
            Message m = commMsgBean.getDifTypeOfMessage(userId, messageId, messageType);
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (m != null) {
                int applay_userId = m.getSenderId();
                int applay_user_allianceId = 0;
                CmAllianceMember member = allianceBo.is_alliance_member(userId);
                CmAlliance alliance = (CmAlliance) ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, member.getAllianceId());
                if (AllianceOperationEnum.AGREE_APPLY.value().equals(result)) {

                    MenPaiCacheVo apply_vo = menPaiBo.getCmMenpaiFromCache(applay_userId);
                    if (apply_vo == null) {
                        CmMenpai mp = menPaiBo.getCmMenpaiFromDB(applay_userId);
                        if (mp != null) {
                            applay_user_allianceId = mp.getAllianceId();
                        }
                    } else {
                        applay_user_allianceId = apply_vo.getAllianceId();
                    }
                    if (applay_user_allianceId == 0) {
                        //验证用户是否为盟主或者副盟主
                        if (DataConstants.ALLIANCE_POST_FUMENGZHU == member.getPost() || DataConstants.ALLIANCE_POST_MENGZHU == member.getPost()) {
                            Map<Integer, CdUnion> map = (Map<Integer, CdUnion>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                            CdUnion cdUnion = (CdUnion) map.get(alliance.getAllanceLevel());
                            if (alliance.getMembers().size() <= cdUnion.getUnionNum()) {
                                ps.setSt(ErrorCodeEnum.normal_success.value());
                                allianceBo.add_alliance(member.getAllianceId(), applay_userId);
                                //int senderId, String senderName, int recId, String recName, String factionName
                                String recName = menPaiBo.getMenPaiName(applay_userId);
                                systemMsgService.someOneAgreeSomeOneRequest(vo.getUserId(), vo.getMpName(), applay_userId, recName, alliance.getAllianceName());
                            } else {
                                ps.setSt(ErrorCodeEnum.arrive_limit.value());
                            }
                        } else {
                            ps.setSt(ErrorCodeEnum.alliance_post_error.value());
                        }
                    } else {
                        ps.setSt(ErrorCodeEnum.alliance_have_exist.value());
                    }
                } else {//决绝
                    //int senderId, String senderName, int recId, String factionName
                    levelMsgService.someOneRefuseSomeOneInvateJoinFc(vo.getUserId(), vo.getMpName(), applay_userId, alliance.getAllianceName());
                    ps.setSt(ErrorCodeEnum.normal_success.value());
                }
            } else {
                ps.setSt("message is not have");
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(ps));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void prayer(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String json = sa.getRequestJson();
            AlliancePrayerRQ prayer = (AlliancePrayerRQ) JsonHelper.getBeanFromJson(json, AlliancePrayerRQ.class);
            int userId = prayer.getUserid();
            int prayerType = prayer.getPrayerType();
            CmAllianceMember member = allianceBo.is_alliance_member(userId);
            if (member != null) {
                MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
                int devote = 0;
                Map<String, String> map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
                if (DataConstants.ALLIANCE_PRAYER_TYPE_1 == prayerType) {
                    if (!map.containsKey(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_1)) {
                        map.put(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_1, "1");
                        devote = 100;
                        //int senderId, String senderName, int factionId, int expVal, int contributeVal
                        factionService.factionPlayerPraySliver(userId, vo.getMpName(), vo.getAllianceId(), devote, devote);
                    } else {
                        change.setSt(ErrorCodeEnum.count_not_enough.value());
                    }
                } else if (DataConstants.ALLIANCE_PRAYER_TYPE_2 == prayerType) {
                    int num = 0;
                    if (!map.containsKey(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_2)) {
                        num = 1;
                    } else {
                        num = Integer.parseInt(map.get(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_2));
                        num++;
                    }
                    //100*a 计算需要消耗的金币数
                    Map formula_value_map = new HashMap();
                    formula_value_map.put("a", num);
                    int final_int = commonBo.getIntFromFormula(48, formula_value_map);
                    if (vo.getMpGold() - final_int >= 0) {
                        devote = 300;
                        //修改元宝
                        mpcommonBo.consum_gold(userId, final_int);
                        saveLogBo.gold(ControlType.ALLIANCE_PRAYER, userId, vo.getMpName(), vo.getMpGold(), -final_int, "prayer");
                        change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(-final_int)));

                        // factionPlayerPrayGold(int senderId, String senderName, int factionId, int costGold, int expVal, int contributeVal) 
                        factionService.factionPlayerPrayGold(userId, vo.getMpName(), vo.getAllianceId(), final_int, devote, devote);
                        //存储次数
                        map.put(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_2, String.valueOf(num));
                    } else {
                        change.setSt(ErrorCodeEnum.gold_not_enough.value());
                    }
                }
                if (devote != 0) {
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.alliance_devote.value(), String.valueOf(devote)));
                    //修改联盟经验
                    change = allianceBo.update_exp(member.getAllianceId(), devote, change);
                    //修改成员贡献
                    allianceBo.update_devote(member.getAllianceId(), userId, devote);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.member_devote.value(), String.valueOf(devote)));

                    Object v_obj = map.get(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE);
                    if (v_obj != null) {
                        devote = devote + Integer.parseInt((String) v_obj);
                    }
                    map.put(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE, String.valueOf(devote));
                    ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId), map);
                    change.setSt(ErrorCodeEnum.normal_success.value());
                }
            } else {
                change.setSt(ErrorCodeEnum.no_alliance_member.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void pay(SuperAction sa) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            String json = sa.getRequestJson();
            AlliancePayRQ pay = (AlliancePayRQ) JsonHelper.getBeanFromJson(json, AlliancePayRQ.class);
            int userId = pay.getUserid();
            //验证该用户是否为联盟用户
            CmAllianceMember member = allianceBo.is_alliance_member(userId);
            if (member != null) {
                MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);

                Map<String, String> map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
                if (!map.containsKey(FixTimeCleanMapKey.ALLIANCE_PAY)) {
                    map.put(FixTimeCleanMapKey.ALLIANCE_PAY, "1");

                    CmAlliance alliance = (CmAlliance) ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, vo.getAllianceId());
                    //player_lv为玩家等级，uinon_lv为该联盟等级，player_union_exp为玩家的个人联盟贡献经验
                    Map<String, Integer> formula_value_map = new HashMap<String, Integer>();
                    formula_value_map.put("player_lv", vo.getMpLevel());
                    formula_value_map.put("union_lv", alliance.getAllanceLevel());
                    formula_value_map.put("player_union_exp", member.getDevoteValue());
                    int final_int = commonBo.getIntFromFormula(49, formula_value_map);
                    mpcommonBo.consum_silver(userId, final_int);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(final_int)));
                    change.setSt(ErrorCodeEnum.normal_success.value());
                    //int senderId, String senderName, int factionId, int sliverCount
                    factionService.factionPlayerGetPay(userId, vo.getMpName(), vo.getAllianceId(), final_int);
//                    map.put(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE, String.valueOf(devote));
                    ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId), map);
                } else {
                    change.setSt(ErrorCodeEnum.count_not_enough.value());
                }
            } else {
                change.setSt(ErrorCodeEnum.no_alliance_member.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void buy(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceBuyRQ buy = (AllianceBuyRQ) JsonHelper.getBeanFromJson(json, AllianceBuyRQ.class);
            int userId = buy.getUserid();
            int propId = buy.getBuyHSPropId();
            RPChangeData change = allianceBo.buyFromHS(userId, propId);

            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void applylist(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceQuitRQ aq = (AllianceQuitRQ) JsonHelper.getBeanFromJson(json, AllianceQuitRQ.class);
            int userId = aq.getUserid();
            CmAllianceMember member = allianceBo.is_alliance_member(userId);
            if (member != null && (member.getPost() == DataConstants.ALLIANCE_POST_FUMENGZHU || member.getPost() == DataConstants.ALLIANCE_POST_MENGZHU)) {
                Object obj = null;//ch.getObjectFromCache(CacheNames.ALLIANCE_APPLY_CACHE, member.getAllianceId());
                if (obj != null) {
                    BSCLinkedMap map = (BSCLinkedMap) obj;
                    Iterator map_it = map.entrySet().iterator();
                    while (map_it.hasNext()) {
                        Map.Entry entry = (Map.Entry) map_it.next();
//                            int attach_userd = (Integer) entry.getKey();
//                        Message message = (Message) entry.getValue();
                    }
                }
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(aq));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void disband(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceDisbandRQ disband = (AllianceDisbandRQ) JsonHelper.getBeanFromJson(json, AllianceDisbandRQ.class);
            RPState state = new RPState();
            int userId = disband.getUserid();
            CmAlliance mengzhu = allianceBo.is_mengzhu(userId);
            if (mengzhu != null) {
                Map<Integer, CmAllianceMember> memebers = mengzhu.getMembers();
                for (Map.Entry entry_type : memebers.entrySet()) {
                    CmAllianceMember member = (CmAllianceMember) entry_type.getValue();
                    allianceBo.edit_user_AllianceId(member.getUserId(), 0);
                }
                delete(mengzhu);
                ch.delMemoryForObject(CacheNames.ALLIANCE_DATA_CACHE, mengzhu.getAllianceId());
                state.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                state.setSt("no menzhu");
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(state));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void douzhanshengfo_apply(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceDisbandRQ disband = (AllianceDisbandRQ) JsonHelper.getBeanFromJson(json, AllianceDisbandRQ.class);
            int userId = disband.getUserid();
            allianceBo.douzhanshengnfo(userId);
            sa.setResponseJson(JsonHelper.getJsonFromBean(disband));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void douzhanshengfo_result(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceDisbandRQ disband = (AllianceDisbandRQ) JsonHelper.getBeanFromJson(json, AllianceDisbandRQ.class);
            int userId = disband.getUserid();
            CmAllianceMember member = allianceBo.is_alliance_member(userId);
            if (member != null) {
                Map<String, Object> douzhanshengfo_map = commonBo.getFixTimeCleanMap("allianceId_" + member.getAllianceId());
                if (douzhanshengfo_map != null && !douzhanshengfo_map.isEmpty()) {
                    if (douzhanshengfo_map.size() < 10) {
                        douzhanshengfo_map.clear();
                        ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, "allianceId_" + member.getAllianceId(), douzhanshengfo_map);
                    }
                }
            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(disband));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void alliance(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceDateRQ alliance = (AllianceDateRQ) JsonHelper.getBeanFromJson(json, AllianceDateRQ.class);
            int userId = alliance.getUserid();
            int allianceId = alliance.getAllianceId();
            CmAlliance cmAlliance = null;
            if (allianceId != 0) {
                cmAlliance = allianceBo.find_alliance(allianceId);
                userId = cmAlliance.getCreateUserId();
            } else {
                cmAlliance = allianceBo.find_alliance_userId(userId);
            }

            RPAlliance rpa = new RPAlliance();
            CJAlliance ci = new CJAlliance();
            if (cmAlliance != null) {
                ci.setCid(cmAlliance.getCreateUserId());
                String name = "";
                int lv = 0;
                MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
                if (vo != null) {
                    name = vo.getMpName();
                    lv = vo.getMpLevel();
                } else {
                    CmMenpai mp = menPaiBo.getCmMenpaiFromDB(userId);
                    if (mp != null) {
                        name = mp.getMpName();
                        lv = mp.getMpLevel();
                    }
                }
                ci.setCn(name);
                ci.setExp(cmAlliance.getAllanceExp());
                ci.setId(cmAlliance.getAllianceId());
                ci.setLv(cmAlliance.getAllanceLevel());
                ci.setMc(cmAlliance.getMembers().size());
                ci.setN(cmAlliance.getAllianceName());

                rpa.setAlliance(ci);

                Map<Integer, CmAllianceMember> mp = cmAlliance.getMembers();
                if (mp != null && !mp.isEmpty()) {
                    CmAllianceMember member = mp.get(userId);
                    MenPaiCacheVo m_vo = menPaiBo.getCmMenpaiFromCache(userId);
                    CJAMember m = new CJAMember();
                    m.setCv(member.getDevoteValue());
                    Map map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
                    Object devote_obj = map.get(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE);
                    int devote = 0;
                    if (devote_obj != null) {
                        devote = Integer.parseInt((String) devote_obj);
                    }
                    int paryer = 0;
                    Object devote_obj_today = map.get(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_1);
                    if (devote_obj_today != null) {
                        paryer = Integer.parseInt((String) devote_obj_today);
                    }
                    int pay = 0;
                    Object pay_obj_today = map.get(FixTimeCleanMapKey.ALLIANCE_PAY);
                    if (pay_obj_today != null) {
                        pay = Integer.parseInt((String) pay_obj_today);
                    }
                    int num = 0;
                    Object num_obj_today = map.get(FixTimeCleanMapKey.ALLIANCE_PRAYER_TYPE_2);
                    if (num_obj_today != null) {
                        num = Integer.parseInt((String) num_obj_today);
                    }

                    m.setCo(num);
                    m.setGt(pay);
                    m.setPt(paryer);
                    m.setCvt(devote);
                    m.setPost(member.getPost());
                    m.setRank(devote);
                    m.setId(userId);
                    m.setLv(lv);
                    m.setN(name);
                    rpa.setMember(m);
                }
                rpa.setSt(ErrorCodeEnum.normal_success.value());
                //加载联盟数据
                ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, cmAlliance.getAllianceId(), cmAlliance);

            } else {
                rpa.setSt(ErrorCodeEnum.alliance_not_exist.value());
            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(rpa));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void inviteresut(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            RPState ps = new RPState();
            MessageReturnRQ ar = (MessageReturnRQ) JsonHelper.getBeanFromJson(json, MessageReturnRQ.class);
            int userId = ar.getUserid();
            int messageId = ar.getMessageId();
            int messageType = ar.getMessageType();
            String result = ar.getResult();
            Message m = commMsgBean.getDifTypeOfMessage(userId, messageId, messageType);
            if (m != null) {
                ResItem res = (ResItem) m.getRes().get(0);
                int allianceId = res.getItemId();
                //验证用户是否存在联盟
                MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
                CmAlliance alliance = allianceBo.find_alliance(allianceId);
                if (Constants.DEFALUT_OK_1.equals(result)) {
                    if (vo.getAllianceId() == 0) {
                        Map<Integer, CdUnion> map = (Map<Integer, CdUnion>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                        CdUnion cdUnion = (CdUnion) map.get(alliance.getAllanceLevel());
                        //判断联盟认识是否符合
                        if (alliance.getMembers().size() <= cdUnion.getUnionNum()) {
                            allianceBo.add_alliance(allianceId, userId);
                            String recName = menPaiBo.getMenPaiName(m.getSenderId());
                            //int senderId, String senderName, int recId, String recName, String factionName
                            systemMsgService.someOneAgreeSomeOneInvate(userId, vo.getMpName(), m.getSenderId(), recName, alliance.getAllianceName());
                            ps.setSt(ErrorCodeEnum.normal_success.value());
                        } else {
                            ps.setSt(ErrorCodeEnum.arrive_limit.value());
                        }
                    }
                } else {
                    //int senderId, String senderName, int recId, String factionName
                    levelMsgService.someOneRefuseSomeOneInvateJoinFc(userId, vo.getMpName(), m.getSenderId(), alliance.getAllianceName());
                    ps.setSt(ErrorCodeEnum.normal_success.value());
                }
            } else {
                ps.setSt("message is not have");
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(ps));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void findUserList(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            AllianceFindUserRQ fn = (AllianceFindUserRQ) JsonHelper.getBeanFromJson(json, AllianceFindUserRQ.class);
            int userId = fn.getUserid();
            RPSearchPlayerList sp = new RPSearchPlayerList();
            List<CmMenpai> lt = allianceBo.getCmUserSearch(userId, fn.getName(), 0, 20);
            for (CmMenpai cm : lt) {
                CJCompetitor cc = new CJCompetitor();
                cc.setId(cm.getMpId());
                cc.setLv(cm.getMpLevel());
                cc.setN(cm.getMpName());
                cc.setVip(cm.getMpVip());
                sp.getPl().add(cc);
            }
            sp.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(sp));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }

    }

    public void manager(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            RPState p = null;
            AllianceOperateRQ op = (AllianceOperateRQ) JsonHelper.getBeanFromJson(json, AllianceOperateRQ.class);
            int userId = op.getUserid();
            int postUserId = op.getOp_userId();
            int operation = op.getOperationType();
            if (operation == 1) {//邀请用户加入
                p = allianceBo.invite(userId, postUserId, operation);
            } else if (operation == 4) {//删除用户
                p = allianceBo.delmember(userId, postUserId, operation);
            } else if (operation == 5 || operation == 6) {//5:任命副盟主，6：解除用户职位
                p = allianceBo.post(userId, postUserId, operation);
            } else if (operation == 7) {
                p = allianceBo.quit(userId, postUserId, operation);
            } else if (operation == 8) {
                p = allianceBo.disband(userId, postUserId, operation);
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(p));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
