/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.constants;

/**
 *
 * @author lxf
 */
public class UserNoCleanDateMapKey {
    //十里挑一时间
    public static final String MARKET_RECUIT_TIME_TYPE_1 ="market_recuit_time_type_1";
    //十里挑一次数
    public static final String MARKET_RECUIT_NUM_TYPE_1 ="market_recuit_num_type_1";
    //百里挑一时间
    public static final String MARKET_RECUIT_TIME_TYPE_2="market_recuit_time_type_2";
    //万里里挑一时间
    public static final String MARKET_RECUIT_TIME_TYPE_3 ="market_recuit_time_type_3";
    
    
}
