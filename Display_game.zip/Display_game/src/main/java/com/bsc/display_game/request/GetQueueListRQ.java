/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class GetQueueListRQ extends ReceiveJson {

    @JsonProperty("id")
    private int find_user_id;
    @JsonProperty("t")
    private int request_type;

    public int getRequest_type() {
        return request_type;
    }

    public void setRequest_type(int request_type) {
        this.request_type = request_type;
    }

    public int getFind_user_id() {
        return find_user_id;
    }

    public void setFind_user_id(int find_user_id) {
        this.find_user_id = find_user_id;
    }
    
    
    
    
}
