/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.CJLianQiRS;
import com.bsc.commonproject.clinet.command.response.CJPackage;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPZhenQiData;
import com.bsc.commonproject.clinet.command.response.RPZhenQiLianQi;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.MapKeyConstants;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.constants.CstateConstants;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdAir;
import com.bsc.protracted.domin.CdAirOutput;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CmMpGestZhenqi;
import com.bsc.random.impl.RandFuncationBean;
import com.bsc.random.vo.IntThree;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.temporary.ehcache.vo.AirOutPutVo;
import com.bsc.util.datas.DateUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class ZhenQiBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private CommonBo commonBo;
    @Resource
    private RandFuncationBean randFuncationBean;
    @Resource
    private AddCardBo addCardBo;
    @Resource
    private SaveLogBo saveLogBo;
    private static final Logger log = LoggerFactory.getLogger(ZhenQiBo.class);
//    private final int[] feiqi_array = new int[]{100000500, 100000501, 100000502, 100000504};
//    private final int[] zhenyuan_array = new int[]{100000503};

    //真气升级
    public RPChangeData upgrade_zq(List<Integer> del_list, int userId, int cardId, RPChangeData change) throws Exception {
        try {
            if(del_list == null || del_list.isEmpty()){
                change.setSt(ErrorCodeEnum.info_error_must_data_null.value());
                return change;
            }
            boolean ble = true;
            //验证该用户是否含有该真气
            Map CmMpGestZhenqi_map = (Map) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
            //真气码表数据
            Map map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.AIR_KEY);
            int del_num = 0;
            boolean ble_b = false;
            for (Integer del_cardId : del_list) {
                Object obj = CmMpGestZhenqi_map.get(del_cardId);
                if (obj != null) {
                    del_num++;
                    CmMpGestZhenqi cmMpGestZhenqi = (CmMpGestZhenqi) obj;
                    if (cmMpGestZhenqi.getBattleDIscipleId() > 0) {
                        ble_b = true;
                        break;
                    }
                } else {
                    ble = false;
                    break;
                }
            }
            //验证目标真气
            Object cmMpGestZhenqi_obj = CmMpGestZhenqi_map.get(cardId);
            if (cmMpGestZhenqi_obj == null) {
                change.setSt(CstateConstants.ZHENQI_SHENGJI_GOAL_NO);
                return change;
            }
            if (ble_b) {
                change.setSt(ErrorCodeEnum.user_data_error.value());
                return change;
            }

            if (!ble) {
                change.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
                return change;
            }
            //验证消耗真气
            if (del_num != del_list.size()) {
                change.setSt(ErrorCodeEnum.user_data_error.value());
                return change;
            }
            CmMpGestZhenqi cmMpGestZhenqi_up = (CmMpGestZhenqi) CmMpGestZhenqi_map.get(cardId);
            //验证是否达到上限
            if (cmMpGestZhenqi_up.getZhenqiLevel() > 9) {
                change.setSt(CstateConstants.ZHENQI_SHENGJI_SHANGXIAN);
                return change;
            }

            int all_exp = 0;
            //删除用户需要消耗掉的真气
            for (Integer del_cardId : del_list) {
                CmMpGestZhenqi cmMpGestZhenqi = (CmMpGestZhenqi) CmMpGestZhenqi_map.get(del_cardId);
                // CdAir
                CdAir delAir = (CdAir) map.get(cmMpGestZhenqi.getZhenqiId());
                //封装公式需要的参数 pz*30+air_exp
                Map formula_value_map = new HashMap();
                formula_value_map.put("pz", delAir.getPz());
                formula_value_map.put("air_exp", cmMpGestZhenqi.getZhenqiExp());
                all_exp = all_exp + commonBo.getIntFromFormula(23, formula_value_map);
                //删除数据库
                delete(cmMpGestZhenqi);
                //删除内存
                CmMpGestZhenqi_map.remove(cmMpGestZhenqi.getMpZhenqiId());
                //封装返回数据
                change.getCv().getCc().add(PackageCardBo.getZhenQiCard(cmMpGestZhenqi.getMpZhenqiId(), cmMpGestZhenqi.getZhenqiId(), cmMpGestZhenqi.getZhenqiLevel(), cmMpGestZhenqi.getZhenqiExp(), CardStatusEnum.del.value()));
            }
            //计算该经验是否可以升级,如果升级则更新等级
            // CdAir
            CdAir upAir = (CdAir) map.get(cmMpGestZhenqi_up.getZhenqiId());

            all_exp = cmMpGestZhenqi_up.getZhenqiExp() + all_exp;
            //验证经验是否可以升级
            cmMpGestZhenqi_up = getCmMpGestZhenqiUp(all_exp, cmMpGestZhenqi_up, upAir);

//            if (cmMpGestZhenqi_old.getZhenqiLevel() != cmMpGestZhenqi_up.getZhenqiLevel()) {
//                //封装返回的等级变化
//                change.getCv().getCp().add(commonBo.getCJProptyty(ClientMapKeyEnum.level.value(), String.valueOf(cmMpGestZhenqi_up.getZhenqiLevel())));
//            }
//int cardId, int codeId, int lv, int exp,int state
            //封装返回的升级真气变化的经验
            change.getCv().getCc().add(PackageCardBo.getZhenQiCard(cardId, cmMpGestZhenqi_up.getZhenqiId(), cmMpGestZhenqi_up.getZhenqiLevel(), cmMpGestZhenqi_up.getZhenqiExp(), CardStatusEnum.add.value()));

            CmMpGestZhenqi_map.put(cmMpGestZhenqi_up.getCmMenpai(), cmMpGestZhenqi_up);
            ch.putObjectToCache(CacheNames.USER_ZHENQI_CACHE, userId, CmMpGestZhenqi_map);
            change.setSt(ErrorCodeEnum.normal_success.value());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    //更换,装备真气
    public void replace_zq(int down_cardId, int up_carsId, int userId, int site, int battleId) throws Exception {

        try {
            Map cmMpGestZhenqi_map = (Map) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
            Object down_obj = cmMpGestZhenqi_map.get(down_cardId);
            Object up_obj = cmMpGestZhenqi_map.get(up_carsId);
            if (up_obj != null) {
                CmMpGestZhenqi CmMpGestZhenqi_up = (CmMpGestZhenqi) up_obj;
                if (down_obj == null) {
                    CmMpGestZhenqi_up.setZhenqiSite(site);
                    CmMpGestZhenqi_up.setBattleDIscipleId(battleId);
                    cmMpGestZhenqi_map.put(CmMpGestZhenqi_up.getMpZhenqiId(), CmMpGestZhenqi_up);
                } else {
                    CmMpGestZhenqi CmMpGestZhenqi_down = (CmMpGestZhenqi) down_obj;
                    CmMpGestZhenqi_up.setZhenqiSite(CmMpGestZhenqi_down.getZhenqiSite());
                    CmMpGestZhenqi_up.setBattleDIscipleId(battleId);
                    CmMpGestZhenqi_down.setZhenqiSite(0);
                    CmMpGestZhenqi_down.setBattleDIscipleId(0);
                    cmMpGestZhenqi_map.put(CmMpGestZhenqi_down.getMpZhenqiId(), CmMpGestZhenqi_down);
                    cmMpGestZhenqi_map.put(CmMpGestZhenqi_up.getMpZhenqiId(), CmMpGestZhenqi_up);
                }
                ch.putObjectToCache(CacheNames.USER_ZHENQI_CACHE, userId, cmMpGestZhenqi_map);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //根据位置查找真气

    public CmMpGestZhenqi getCmMpGestZhenqiFromCacheBySite(int userId, int battleId, int site) {
        Map cmMpGestZhenqi_map = (Map) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
        if (cmMpGestZhenqi_map != null) {
            Map map = (Map) cmMpGestZhenqi_map;
            Iterator barriers_data_map_type_it = map.entrySet().iterator();
            while (barriers_data_map_type_it.hasNext()) {
                Map.Entry entry_type = (Map.Entry) barriers_data_map_type_it.next();
//                    int  cardId =  (Integer) entry_type.getKey();
                CmMpGestZhenqi cmMpGestZhenqi = (CmMpGestZhenqi) entry_type.getValue();
                if (cmMpGestZhenqi.getZhenqiSite() == site && cmMpGestZhenqi.getBattleDIscipleId() == battleId) {
                    return cmMpGestZhenqi;
                }
            }
        }
        return null;
    }

    //根据位置查找真气
    public boolean getCmMpGestZhenqiFromCacheByApp(int userId, int battleId, int codeId) {
        Map cmMpGestZhenqi_map = (Map) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
        if (cmMpGestZhenqi_map != null) {
            Map map = (Map) cmMpGestZhenqi_map;
            Iterator barriers_data_map_type_it = map.entrySet().iterator();
            while (barriers_data_map_type_it.hasNext()) {
                Map.Entry entry_type = (Map.Entry) barriers_data_map_type_it.next();
//                    int  cardId =  (Integer) entry_type.getKey();
                CmMpGestZhenqi cmMpGestZhenqi = (CmMpGestZhenqi) entry_type.getValue();
                if (cmMpGestZhenqi.getBattleDIscipleId() == battleId && cmMpGestZhenqi.getZhenqiId() == codeId) {
                    return false;
                }
            }
        }
        return true;
    }
    //练气

    public RPZhenQiLianQi Lianqi(int userId, int random_type, RPZhenQiLianQi zqchange) throws Exception {
        try {
            int open = mpcommonBo.getPlayNum(20, userId, 1, false);
            if (open != 1) {
                zqchange.setSt(ErrorCodeEnum.mp_level_no_enough.value());
                return zqchange;
            }


            CJPackage uv = new CJPackage();
            Map user_other_data_map = null;
            //查找存储用户杂项数据,
            Object obj_map = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, userId);
            if (obj_map != null) {
                //获取用户上次开始时间
                user_other_data_map = (Map) obj_map;
            }
            //记录练气停留的最后位置与时间
            if (user_other_data_map == null) {
                user_other_data_map = new HashMap();
            }
//            if (random_type != 1) {
            List<CJLianQiRS> rs = new ArrayList();
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            Map other_code_data = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
            //获取码表默认的返还金额
            int feiqi_return = 4000;
            Object obj = other_code_data.get(MapKeyConstants.FEIQI_RETURN_SILVER);
            if (obj != null) {
                feiqi_return = (Integer) obj;
            }
            boolean ble = true;
            //默认起始位置
            int stop_site = 1;
            //计算时间
            if (obj_map != null) {
                //获取用户上次开始时间
                user_other_data_map = (Map) obj_map;
                Object time_obj = user_other_data_map.get(MapKeyConstants.USER_LIANQI_TIME);
                if (time_obj != null) {
                    stop_site = (Integer) user_other_data_map.get(MapKeyConstants.USER_LIANQI_STOP_SIET);
                    int cd_time = getCdAirOutput(stop_site, MapKeyConstants.ZHENQI_CD_TIME);
                    long up_end_time = (Long) time_obj;
                    //查找码表数据当前位置需要持续的时间
                    long diff = DateUtil.getCurrentDate().getTime() - up_end_time;
                    long hour = diff / (1000 * 60 * 60);
                    if (hour < cd_time) {
                        ble = false;
                    }
                }
            }
            //用户消耗的总钱数
            int consume_silver = 0;
//            if (!ble) {
//                consume_silver = getCdAirOutput(stop_site, MapKeyConstants.ZHENQI_CONSUME_SILVER);
//            }
            //判断用户的银币是否够消耗的,优先判断背刺费用
            int user_silver = vo.getMpSilver();
            //用户含有的钱数
            int user_have_silver = user_silver - consume_silver;
            if (user_have_silver > 0) {
                //获取随机的真气过程
                List<IntThree> list = randFuncationBean.getTrainAirRdomResult(random_type, stop_site);
                if (list != null && list.size() > 0) {
                    int z = 0;
                    for (IntThree intThree : list) {
                        z++;
                        if (user_have_silver - intThree.money <= 0) {
                            break;
                        }
                        stop_site = intThree.pos;
                        int counsum_s = intThree.money;
                        if (z == 1 && ble) {
                            counsum_s = 0;
                        }
                        CJLianQiRS cjl = new CJLianQiRS();
                        consume_silver = consume_silver + counsum_s;
                        user_have_silver = user_have_silver - counsum_s;
                        cjl.setCt(intThree.money);
                        cjl.setN(intThree.pos);
                        if (110020500 == intThree.codeId || 110020501 == intThree.codeId || 110020502 == intThree.codeId || 110020504 == intThree.codeId) {//废弃
                            consume_silver = consume_silver - feiqi_return;
                            //消耗返还
                            cjl.setFq(feiqi_return);
//                            //如果失败则返回到初始阶段
//                            stop_site = 1;
//                            cjl.setN(1);
                            //ControlType controlType, int userId, String mp_name, int silver, int counsu_silver, String result, int type
                            saveLogBo.sliver(ControlType.TRAIN_QI, userId, vo.getMpName(), vo.getMpSilver(), feiqi_return, "", 0);
                        } else if (110020503 == intThree.codeId) {//真元
                            mpcommonBo.update_zhenyuan(userId, intThree.money);
                            //修改真元
                            cjl.setZyc(intThree.money);
                        } else {
                            CmMpGestZhenqi cmMpGestZhenqi = addCardBo.addZhenqi(userId, intThree.codeId, 1);
                            cjl.setZq(PackageCardBo.getZhenQiCard(cmMpGestZhenqi.getMpZhenqiId(), cmMpGestZhenqi.getZhenqiId(), cmMpGestZhenqi.getZhenqiLevel(), cmMpGestZhenqi.getZhenqiExp(), CardStatusEnum.add.value()));
                            saveLogBo.sliver(ControlType.TRAIN_QI, userId, vo.getMpName(), vo.getMpSilver(), -intThree.money, "", 0);
                        }
                        rs.add(cjl);
                    }
                    if (consume_silver == 0) {
                        zqchange.setSt(ErrorCodeEnum.silver_not_enough.value());
                        return zqchange;
                    }

                    //修改本次练气的全部消耗
                    mpcommonBo.consum_silver(userId, consume_silver);
                    uv.getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(-consume_silver)));
                    zqchange.setRs(rs);
                    zqchange.setUv(uv);
                    //重新计算用户练气时间
                    user_other_data_map.put(MapKeyConstants.USER_LIANQI_TIME, DateUtil.getCurrentDate().getTime());
                    //重新封装用户最后停留的位置
                    user_other_data_map.put(MapKeyConstants.USER_LIANQI_STOP_SIET, stop_site);
                    ch.putObjectToCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, ElementKeys.CODE_TABLE_KEY, user_other_data_map);
                    zqchange.setSt(ErrorCodeEnum.normal_success.value());
                } else {
                    zqchange.setSt(ErrorCodeEnum.random_error.value());
                }
            } else {
                zqchange.setSt(ErrorCodeEnum.silver_not_enough.value());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return zqchange;
    }

    public RPZhenQiData load(int userId) throws Exception {
        RPZhenQiData zq = new RPZhenQiData();
        try {
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (vo == null) {
                zq.setSt(ErrorCodeEnum.user_not_exist.value());
                return zq;
            }
            zq.setZy(vo.getMpZhenyuan());
            int stop_site = 1;
            long lefttime = 0;
            Object obj_map = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, ElementKeys.CODE_TABLE_KEY);
            Map user_other_data_map = null;
            if (obj_map != null) {
                //获取用户上次开始时间
                user_other_data_map = (Map) obj_map;
            }
            if (obj_map != null) {
                //获取用户上次开始时间
                user_other_data_map = (Map) obj_map;
                Object time_obj = user_other_data_map.get(MapKeyConstants.USER_LIANQI_TIME);
                if (time_obj != null) {
                    stop_site = (Integer) user_other_data_map.get(MapKeyConstants.USER_LIANQI_STOP_SIET);
                    int cd_time = getCdAirOutput(stop_site, MapKeyConstants.ZHENQI_CD_TIME);
                    long up_end_time = (Long) time_obj;
                    long diff = DateUtil.getCurrentDate().getTime() - up_end_time;
                    long hour = diff / (1000 * 60 * 60);
                    if (hour < cd_time) {
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(up_end_time);
                        cal.add(Calendar.HOUR, cd_time);
                        lefttime = (cal.getTime().getTime() - DateUtil.getCurrentDate().getTime()) / 1000;
                    }
                }
            }
            zq.setPs(stop_site);
            zq.setLt(String.valueOf(lefttime));
            zq.setSt(ErrorCodeEnum.normal_success.value());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return zq;
    }

    public RPChangeData exchange(int userId, int codeId, RPChangeData change) throws Exception {
        try {
            //查找真气对换码表 
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (vo == null) {
                change.setSt(ErrorCodeEnum.user_not_exist.value());
                return change;
            }
            Map<Integer, CdAir> air_map = (Map<Integer, CdAir>) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.AIR_KEY);
            Object obj = air_map.get(codeId);
            if (obj == null) {
                change.setSt(ErrorCodeEnum.info_error_member_error.value());
                return change;
            }
            CdAir air = air_map.get(codeId);
            //验证真元是否够本次兑换
            if (vo.getMpZhenyuan() - air.getNum() < 0) {
                change.setSt(CstateConstants.ZHENQI_DUIHUAN_NUM_NO);
                return change;
            }
            if (vo.getMpLevel() < air.getLvBuy()) {
                change.setSt(ErrorCodeEnum.mp_level_no_enough.value());
                return change;
            }
            if (vo.getMpVip() < air.getVipLv()) {
                change.setSt(ErrorCodeEnum.mp_vip_lev_no_enough.value());
                return change;
            }

            //修改真元
            mpcommonBo.update_zhenyuan(userId, -air.getNum());
            //生成卡牌
            CmMpGestZhenqi cmMpGestZhenqi = addCardBo.addZhenqi(userId, codeId, 1);
            //修改真元
            change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.zhenyuan.value(), String.valueOf(-air.getNum())));
            //封装新增真气
            change.getCv().getCc().add(PackageCardBo.getZhenQiCard(cmMpGestZhenqi.getMpZhenqiId(), cmMpGestZhenqi.getZhenqiId(), cmMpGestZhenqi.getZhenqiLevel(), cmMpGestZhenqi.getZhenqiExp(), CardStatusEnum.add.value()));
            change.setSt(ErrorCodeEnum.normal_success.value());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    public RPChangeData xinwupangwu(int userId) throws Exception {
        RPChangeData change = new RPChangeData();
        try {
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (vo != null && vo.getMpGold() >= 200) {
                Map user_other_data_map = null;
                //查找存储用户杂项数据,
                Object obj_map = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, ElementKeys.CODE_TABLE_KEY);
                if (obj_map != null) {
                    //获取用户上次开始时间
                    user_other_data_map = (Map) obj_map;
                }
                //记录练气停留的最后位置与时间
                if (user_other_data_map == null) {
                    user_other_data_map = new HashMap();
                }

                int n = (int) (Math.random() * 100);
                Map map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
                Object obj_num = map.get("air_yuan");
                int m = 0;
                if (obj_num != null) {
                    CdMessyData cme = (CdMessyData) obj_num;
                    m = Integer.parseInt(cme.getMessyValue());
                }
                if (n <= m) {
                    mpcommonBo.update_zhenyuan(userId, 1);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.zhenyuan.value(), String.valueOf(1)));
                }
                //重新计算用户练气时间
                user_other_data_map.remove(MapKeyConstants.USER_LIANQI_TIME);
                //重新封装用户最后停留的位置
                user_other_data_map.put(MapKeyConstants.USER_LIANQI_STOP_SIET, 4);
                ch.putObjectToCache(CacheNames.USER_FIX_TIME_TWO_DAY_CLEAN_CACHE, ElementKeys.CODE_TABLE_KEY, user_other_data_map);
                mpcommonBo.consum_gold(userId, 200);
                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(-200)));
                change.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                change.setSt(ErrorCodeEnum.gold_not_enough.value());
            }

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    public int getCdAirOutput(int site, int MapKey) {
        AirOutPutVo vo = (AirOutPutVo) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.AIR_OUTPUT_KEY);
        Map air_counsum_map = vo.getAir_consum_map();
        CdAirOutput cdAirOutput = (CdAirOutput) air_counsum_map.get(MapKey);
        int num = 0;
        switch (site) {
            case 1:
                num = cdAirOutput.getFirstImage();
                break;
            case 2:
                num = cdAirOutput.getSecondImage();
                break;
            case 3:
                num = cdAirOutput.getThreeImage();
                break;
            case 4:
                num = cdAirOutput.getFourImage();
                break;
            case 5:
                num = cdAirOutput.getLastImage();
                break;
        }
        return num;
    }

    public CmMpGestZhenqi getCmMpGestZhenqiUp(int all_exp, CmMpGestZhenqi zq, CdAir upAir) {
        //封装公式需要的参数 60* $('Math').pow(2,pz)*(1>$('Math').pow(2,(air_lv-2))?1:$('Math').pow(2,(air_lv-2)))
        Map formula_value_map2 = new HashMap();
        formula_value_map2.put("pz", upAir.getPz());
        formula_value_map2.put("air_lv", zq.getZhenqiLevel());

        int upexp = commonBo.getIntFromFormula(21, formula_value_map2);

        if (all_exp - upexp >= 0) {
            zq.setZhenqiLevel(zq.getZhenqiLevel() + 1);
            zq.setZhenqiExp(all_exp - upexp);
            return getCmMpGestZhenqiUp(all_exp - upexp, zq, upAir);
        } else {
            zq.setZhenqiExp(all_exp);
            return zq;
        }
    }

    public List<CmMpGestZhenqi> getCmMpZhenQiFromCacheByCardSite(int userId, int battliId) {
        List<CmMpGestZhenqi> list = new ArrayList();
        Map<Integer, CmMpGestZhenqi> cmMpGestZhenqi_map = (Map<Integer, CmMpGestZhenqi>) ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
        if (cmMpGestZhenqi_map != null && !cmMpGestZhenqi_map.isEmpty()) {
            for (Map.Entry entry_type : cmMpGestZhenqi_map.entrySet()) {
//                    int  cardId =  (Integer) entry_type.getKey();
                CmMpGestZhenqi cmMpGestZhenqi = (CmMpGestZhenqi) entry_type.getValue();
                if (cmMpGestZhenqi.getBattleDIscipleId() == battliId) {
                    list.add(cmMpGestZhenqi);
                }
            }
        }
        return list;
    }
}
