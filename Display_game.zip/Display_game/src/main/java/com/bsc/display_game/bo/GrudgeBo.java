/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.battle.server.BattlePlInfoBean;
import com.bsc.battle.server.BattleUtilService;
import com.bsc.battle.vo.AttackUnit;
import com.bsc.battle.vo.PlayerBase;
import com.bsc.battle.vo.enums.BattleType;
import com.bsc.commonproject.bo.FriendBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.RPBattleData;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.LevelMsgService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CmAttention;
import com.bsc.protracted.domin.CmFriend;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.util.datas.StringUtil;
import com.bsc.util.json.JsonHelper;
import com.bsc.util.list.BSCLinkedMap;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Resource;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GrudgeBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private BattleUtilService battleUtilService;
    @Resource
    private BattlePlInfoBean battlePlInfoBean;
    @Resource
    private LevelMsgService levelMsgService;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private CommonBo commonBo;
    @Resource
    private FriendBo friendBo;
    private static final Logger log = LoggerFactory.getLogger(GrudgeBo.class);
    //添加好友，互相添加，先验证好友关系是否存在（好友删除时是单向删除）

    public int add_friend(int userId, int fid) throws Exception {
        try {
            if (userId == fid) {
                return -3;
            }

            //验证是否为仇敌关系
            if (!is_create_friend(userId, fid)) {
                return -1;
            }
            List<CmFriend> list3 = friendBo.getCmFriendList(userId, 0);
            int num = mpcommonBo.getPlayNum(3, userId, 2, false);
            if (list3 != null && list3.size() >= num) {
                return -2;
            }
            List<CmFriend> list1 = friendBo.getCmFriendList(userId, fid);
            if (list1 == null || list1.isEmpty()) {
                CmFriend cmFriend = new CmFriend();
                cmFriend.setFriendId(fid);
                cmFriend.setUserId(userId);
                save(cmFriend);
            }
            List<CmFriend> list2 = friendBo.getCmFriendList(fid, userId);
            if (list2 == null || list2.isEmpty()) {
                CmFriend cmFriend2 = new CmFriend();
                cmFriend2.setFriendId(userId);
                cmFriend2.setUserId(fid);
                save(cmFriend2);
            }
            return 1;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //获取三种用户列表信息

    public List<CmMenpai> getCmMenpaiList(int userId, final int page, final int num, String info) {

        StringBuilder strb = new StringBuilder("select menpai from CmMenpai menpai,");
        //拼装3中sql
        strb.append(" CmFriend grudge  where grudge.friendId = menpai.mpId");
        strb.append(" and grudge.userId = ").append(userId);
        if (info != null && StringUtil.isNotNull(info)) {
            strb.append(" and menpai.mpName like '%").append(info).append("%'");
        }
        final String hq = strb.toString();
        return getHibernateTemplate().executeFind(new HibernateCallback() {
            public List doInHibernate(Session session) throws HibernateException, SQLException {
                Query query = session.createQuery(hq);
                query.setFirstResult((page - 1) * num);
                query.setMaxResults(num);
                return query.list();
            }
        });
    }
    //搜索好友列表信息

    public List<CmMenpai> getCmFriendSearch(int userId, String info, final int page, final int num, String except_ids) {

        StringBuilder strb = new StringBuilder("select menpai from CmMenpai menpai where (");
        strb.append(" select f.id from CmFriend f where f.userId =  ").append(userId);
        strb.append(" and f.friendId = menpai.userId ) is null");
        strb.append(" and menpai.mpId <>").append(userId);
        if (info != null && StringUtil.isNotNull(info)) {
            if (info.matches("[0-9]+")) {
                strb.append(" and menpai.mpLevel = ").append(info.trim());
            } else {
                strb.append(" and menpai.mpName like '%").append(info.trim()).append("%'");
            }
        }
        if (except_ids != null && StringUtil.isNotNull(except_ids)) {
            strb.append(" and menpai.mpId not in (").append(except_ids).append(")");
        }
        strb.append("order by menpai.mpLevel desc");
        final String hq = strb.toString();
        return getHibernateTemplate().executeFind(new HibernateCallback() {
            public List doInHibernate(Session session) throws HibernateException, SQLException {
                Query query = session.createQuery(hq);
                query.setFirstResult((page - 1) * num);
                query.setMaxResults(num);
                return query.list();
            }
        });
    }

    public String getFriendIds(int userId) {
        final String sql = "select group_concat(f.friend_id) from cimo_game_server_db.cm_friend f where f.user_id = " + userId;
        List<String> lt = getHibernateTemplate().executeFind(new HibernateCallback() {
            public List doInHibernate(Session session) throws HibernateException, SQLException {
                Query query = session.createSQLQuery(sql);
                return query.list();
            }
        });
        if (lt != null && !lt.isEmpty()) {
            return (String) lt.get(0);
        }
        return null;
    }

//增加关注
    public int add_attention(int fid, int userId) {
        CmAttention cmAttention = new CmAttention();
        cmAttention.setAttentId(fid);
        cmAttention.setUserId(userId);

        List<CmAttention> list = getCmAttentionList(userId, fid);
        if (list == null || list.isEmpty()) {
            return save(cmAttention);
        }
        return 0;
    }

    //获取仇敌关系列表
    public BSCLinkedMap getCmEnemyList(Integer userId) {
        Object obj = ch.getObjectFromCache(CacheNames.USER_EMENY_CACHE, userId);
        if (obj != null) {
            return (BSCLinkedMap) obj;
//            Iterator it = map.entrySet().iterator();
//            while (it.hasNext()) {
//                Map.Entry entry = (Map.Entry) it.next();
//                Integer key = (Integer)entry.getKey();
//                lt.add(key);
////                Object value = entry.getValue();
////                System.out.println("key=" + key + " value=" + value);
//            }
        }
        return null;
    }
    //获取关注关系列表

    public List<CmAttention> getCmAttentionList(int userId, int fid) {
        Map map = new HashMap();
        map.put("userId", userId);
        if (fid != 0) {
            map.put("attentId", fid);
        }
        return get(CmAttention.class, map, true);
    }

    public boolean is_create_friend(int userId, int friendId) {
        Object my_obj = ch.getObjectFromCache(CacheNames.USER_EMENY_CACHE, userId);
        if (my_obj != null) {
            BSCLinkedMap map = (BSCLinkedMap) my_obj;
            if (map.containsKey(friendId)) {
                return false;
            }
        }
        Object friend_obj = ch.getObjectFromCache(CacheNames.USER_EMENY_CACHE, friendId);
        if (friend_obj != null) {
            BSCLinkedMap map = (BSCLinkedMap) friend_obj;
            if (map.containsKey(userId)) {
                return false;
            }
        }

        return true;
    }

    public RPBattleData learn(int userId, int friendId, RPBattleData rpbd) throws Exception, Throwable {
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            //加载自己信息对象
            PlayerBase my_playerBase = battlePlInfoBean.getPlayerBattleData(userId, userId, false, true, BattleType.pvp_bt, 0);
            //加载对手对象
            PlayerBase you_playerBase = battlePlInfoBean.getPlayerBattleData(friendId, userId, true, false, BattleType.pvp_bt, 0);
            //验证对方和己方数据都没问题
            if (you_playerBase != null && my_playerBase != null) {
                //加载战斗过程数据
                AttackUnit attackUnit = battleUtilService.requestBattle(my_playerBase, you_playerBase);
                //判断战斗结果
                if (attackUnit != null) {
                    //用户战斗胜利
                    if (attackUnit.getBatResult() > 0) {
                        //封装数据
                        rpbd.setOl(attackUnit.getChInitData());
                        rpbd.setTr(attackUnit.getAk_round());
                        rpbd.setCf(my_playerBase.getCjfData());
                        rpbd.setCi(my_playerBase.getCjMpInfo());
                        levelMsgService.someOneToFriendBattle(vo.getUserId(), vo.getMpName(), friendId, true);
                    } else {//战斗失败
                        levelMsgService.someOneToFriendBattle(vo.getUserId(), vo.getMpName(), friendId, false);
                    }
                }
            }
            return rpbd;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public boolean receive_flower_num(int userId) throws Exception {
        try {
            Map map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
            Object obj = map.get("user_receive_flower_num");
            int num = 0;
            if (obj != null) {
                num = (Integer) obj;
            }
            if (num < 6) {
                map.put("user_receive_flower_num", num + 1);
                ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId), map);
                return true;
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return false;
    }

    public boolean my_send_user(int my_userId, int you_userId) throws Exception {
        try {
            Map map = commonBo.getFixTimeCleanMap(String.valueOf(my_userId));
            Object obj = map.get("my_send_flower_user");
            Set set = null;
            if (obj != null) {
                set = (Set) JsonHelper.getBeanFromJson((String) obj, Set.class);
            } else {
                set = new HashSet();
            }
            if (!set.contains(you_userId)) {
                map.put("my_send_flower_user", JsonHelper.getJsonFromBean(set));
                ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(my_userId), map);
                return true;
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return false;
    }
}
