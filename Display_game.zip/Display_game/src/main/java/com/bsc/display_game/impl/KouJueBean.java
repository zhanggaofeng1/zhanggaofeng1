/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.clinet.command.response.RPUpdateXiuShenData;
import com.bsc.commonproject.clinet.command.response.RPUserXiuShenData;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.display_game.bo.KoujueBo;
import com.bsc.display_game.request.KouJueGradeRQ;
import com.bsc.display_game.request.KoujueListRQ;
import com.bsc.display_game.service.KouJueService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.util.json.JsonHelper;
import java.util.List;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class KouJueBean extends DaosPublic implements KouJueService {

    @Resource
    private KoujueBo koujueBo;
    private static final Logger log = LoggerFactory.getLogger(KouJueBean.class);

    public void list(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            KoujueListRQ kjlt = (KoujueListRQ) JsonHelper.getBeanFromJson(json, KoujueListRQ.class);
            int userId = kjlt.getUserid();
            RPUserXiuShenData xsd = new RPUserXiuShenData();
            xsd.getLi().addAll(koujueBo.getKoujueList(userId));
            xsd.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(xsd));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void upgrade(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            KouJueGradeRQ up = (KouJueGradeRQ) JsonHelper.getBeanFromJson(json, KouJueGradeRQ.class);
            int userId = up.getUserid();
            String type = up.getType();
            List<Integer> disCardId = up.getDisCardId();
            List<String> soulCardIds = up.getSoulCardIds();
            //int userId,String type , List<Integer> dislt, List<String> souls,RPUpdateXiuShenData uprq
            RPUpdateXiuShenData uprq = koujueBo.upgrade(userId, type, disCardId, soulCardIds);
            sa.setResponseJson(JsonHelper.getJsonFromBean(uprq));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
