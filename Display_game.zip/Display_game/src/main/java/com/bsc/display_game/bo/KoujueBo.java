/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.DisCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.clinet.command.response.CJPackage;
import com.bsc.commonproject.clinet.command.response.CJXiuShen;
import com.bsc.commonproject.clinet.command.response.RPUpdateXiuShenData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.CardTypeEnum;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.GameConstants;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.constants.CstateConstants;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdBaby;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpDiscipleSoul;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpKoujue;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.tools.FelCount;
import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class KoujueBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private DisCommonBo disCommonBo;
    private static final Logger log = LoggerFactory.getLogger(KoujueBo.class);
    private String[] client_type = new String[]{"atk", "def", "mp", "hp"};
    private String[] map_key = new String[]{"atk_koujue_lv", "def_koujue_lv", "mp_koujue_lv", "hp_koujue_lv"};
    //获得一个口诀或者增加经验

    public void addKoujue(int userId, String koujueKey, int exp) throws Exception {
        try {
            Map<String, CmMpKoujue> map = (Map<String, CmMpKoujue>) ch.getObjectFromCache(CacheNames.USER_KOUJUE_CACHE, userId);
            Object obj = map.get(koujueKey);
            CmMpKoujue kj = null;
            if (obj == null) {//没有则新增口诀、
                kj = new CmMpKoujue();
                kj.setKoujueKey(koujueKey);
                kj.setKoujueExp(GameConstants.DEFUL_EXP);
                kj.setKoujueLevel(0);
                kj.setUserId(userId);
                int cardId = save(kj);
                kj.setMpKoujueId(cardId);

            } else {
                kj = (CmMpKoujue) obj;
                int all_exp = kj.getKoujueExp() + exp;
                kj.setKoujueExp(all_exp);
                //需要判断该口诀是否升级
                if (true) {
                    kj.setKoujueLevel(kj.getKoujueLevel() + 1);
                }
            }

            map.put(kj.getKoujueKey(), kj);
            ch.putObjectToCache(CacheNames.USER_KOUJUE_CACHE, userId, map);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //加载口诀列表

    public List<CJXiuShen> getKoujueList(int userId) throws Exception {
        List<CJXiuShen> lt = new ArrayList<CJXiuShen>();
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            Map<String, CmMpKoujue> map = (Map<String, CmMpKoujue>) ch.getObjectFromCache(CacheNames.USER_KOUJUE_CACHE, userId);

            for (int i = 0; i < client_type.length; i++) {
                if (koujue_open(vo.getMpLevel(), client_type[i])) {
                    CJXiuShen xs = new CJXiuShen();
                    Object obj = null;
                    if (map != null && !map.isEmpty()) {
                        obj = map.get(client_type[i]);
                    }
                    if (obj != null) {
                        CmMpKoujue kj = (CmMpKoujue) obj;
                        xs.setExp(kj.getKoujueExp());
                        xs.setLv(kj.getKoujueLevel());
                        xs.setXt(kj.getKoujueKey());
                    } else {
                        addKoujue(userId, client_type[i], 0);
                        xs.setExp(0);
                        xs.setLv(0);
                        xs.setXt(client_type[i]);
                    }
                    lt.add(xs);
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return lt;
    }

    //升级
    public RPUpdateXiuShenData upgrade(int userId, String type, List<Integer> dislt, List<String> souls) throws Exception {
        try {
            RPUpdateXiuShenData uprq = new RPUpdateXiuShenData();
            CJPackage cv = new CJPackage();
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo == null) {
                return uprq;
            }
            if (!koujue_open(vo.getMpLevel(), type)) {
                uprq.setSt(CstateConstants.KOUJUE_STARTR_NO);
                return uprq;
            }
            Map<String, CmMpKoujue> cmMpKoujues = (Map<String, CmMpKoujue>) ch.getObjectFromCache(CacheNames.USER_KOUJUE_CACHE, userId);
            Object obj = cmMpKoujues.get(type);
            if (obj == null) {
                uprq.setSt(CstateConstants.KOUJUE_STARTR_NO);
                return uprq;
            }
            CmMpKoujue kj = (CmMpKoujue) obj;
            int current_exp = kj.getKoujueExp();
            int current_lv = kj.getKoujueLevel();
            //0:等级，1:剩余经验
            int soul_exp = 0;
            if (souls != null && !souls.isEmpty()) {
                Object[] objs = upgrade_count_soul(userId, souls, cv);
                soul_exp = (Integer) objs[0];
                if (soul_exp < 0) {
                    if (soul_exp == -2) {
                        uprq.setSt(CstateConstants.KOUJUE_SOUL_FORMAT_NO);
                        return uprq;
                    } else {
                        uprq.setSt(CstateConstants.KOUJUE_SOUL_NO);
                        return uprq;
                    }
                }
                cv = (CJPackage) objs[1];
            }
            int dis_exp = 0;
            if (dislt != null && !dislt.isEmpty()) {
                Object[] objs = upgrade_count_disciple(userId, dislt, cv);
                dis_exp = (Integer) objs[0];
                if (dis_exp < 0) {
                    uprq.setSt(CstateConstants.KOUJUE_DISCIPLE_NO);
                    return uprq;
                }
                cv = (CJPackage) objs[1];
            }
            if (dis_exp >= 0 && dis_exp >= 0) {
                int all_exp = dis_exp + soul_exp + current_exp;
                int[] i2 = getLevel(current_lv, all_exp);
                kj.setKoujueExp(i2[1]);
                kj.setKoujueKey(type);
                kj.setKoujueLevel(i2[0]);
                CJXiuShen xs = new CJXiuShen();
                xs.setExp(i2[1]);
                xs.setLv(i2[0]);
                xs.setXt(type);
                uprq.getLi().add(xs);
                uprq.setCv(cv);
                cmMpKoujues.put(type, kj);
                ch.putObjectToCache(CacheNames.USER_KOUJUE_CACHE, userId, cmMpKoujues);
                uprq.setSt(ErrorCodeEnum.normal_success.value());
            }
            return uprq;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public int[] getLevel(int current_lv, int all_exp) {
        int[] ints = new int[2];
        ints[0] = current_lv;
        ints[1] = all_exp;
        //升级经验
        int up_exp = 4 * (current_lv + 1);
        if (all_exp - up_exp > 0) {
            ints[0] = current_lv + 1;
            ints[1] = all_exp - up_exp;
            return getLevel(ints[0], ints[1]);
        }
        return ints;
    }
    //判断是否可以升级

    public Object[] upgrade_count_soul(int userId, List<String> souls, CJPackage cv) throws Exception {
        Object[] objs = new Object[2];
        try {
            int exp = 0;
            Map baby_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
            Map<Integer, CmMpDiscipleSoul> cmMpDiscipleSouls_map = (Map<Integer, CmMpDiscipleSoul>) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId);

            for (String str : souls) {
                if (str.indexOf(":") < 0) {
                    objs[0] = -2;
                    return objs;
                }
                //0:魂魄cardID,1:数量
                String[] strs = str.split(":");
                if (cmMpDiscipleSouls_map.get(Integer.parseInt(strs[0])) == null) {
                    objs[0] = -1;
                    return objs;
                }
            }
            for (String str : souls) {
                String[] strs = str.split(":");
                int soulId = Integer.parseInt(strs[0]);
                int num = Integer.parseInt(strs[1]);
                CmMpDiscipleSoul soul = cmMpDiscipleSouls_map.get(soulId);
                int card_status = CardStatusEnum.add.value();

                if (soul.getSoulNum() <= num) {
                    num = soul.getSoulNum();
                    //删除魂魄
                    delete(soul);
                    //内存
                    cmMpDiscipleSouls_map.remove(soul.getSoulId());
                    card_status = CardStatusEnum.del.value();
                } else {
                    soul.setSoulNum(soul.getSoulNum() - num);
                    cmMpDiscipleSouls_map.put(soul.getSoulId(), soul);
                }
                //魂魄数
                cv.getCc().add(PackageCardBo.getSoulCard(soul.getSoulId(), soul.getDiscipleId(), soul.getSoulNum(), card_status));

                CdBaby cdBaby = (CdBaby) baby_map.get(disCommonBo.getDiscipleIdFromSoulId(soul.getDiscipleId()));
                exp = exp + num * cdBaby.getPz();
            }
            ch.putObjectToCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId, cmMpDiscipleSouls_map);
            objs[0] = exp;
            objs[1] = cv;
            return objs;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public Object[] upgrade_count_disciple(int userId, List<Integer> disciples, CJPackage cv) throws Exception {
        Object[] objs = new Object[2];
        try {
            int exp = 0;
            Map baby_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
            Map geest_map = (Map) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
            Map cmMpDisciples_map = (Map) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
            String gongshi = "72<pz*$('Math').pow(3,(pz-1))?72:pz*$('Math').pow(3,(pz-1))";
            Map<Integer, CmMpDisciple> cmMpDisciple_map = (Map<Integer, CmMpDisciple>) ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
            for (Integer i : disciples) {
                if (cmMpDisciple_map.get(i) == null) {
                    objs[0] = -3;
                    return objs;
                }
            }
            for (Integer i : disciples) {
                CmMpDisciple dis = cmMpDisciple_map.get(i);
                CdBaby cdBaby = (CdBaby) baby_map.get(dis.getDiscipleId());
                Map map = new HashMap();
                map.put("pz", cdBaby.getPz());
//                int final_pz_int = commonBo.getIntFromFormula(3, map);
                Number final_exp_number = FelCount.getCountResult(map, gongshi);

                CmMpGest gest = dis.getCmMpGest();
                geest_map.remove(gest.getMpGestId());
                //封装返回数据
                cv.getCc().add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), CardTypeEnum.GEST_CARD_TYPE.value(), CardStatusEnum.del.value()));
                //删除数据库
                delete(dis);
                //删除内存
                cmMpDisciples_map.remove(i);
                //删除的卡牌
                cv.getCc().add(PackageCardBo.getDicCard(dis.getMpDisId(), dis.getDiscipleId(), Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, Constants.DEFUALT_NULL, CardStatusEnum.del.value(), dis.getGestId()));
                exp = exp + Tools.getNumberToInt(final_exp_number);
            }
            ch.putObjectToCache(CacheNames.USER_DISCIPLE_CACHE, userId, cmMpDisciple_map);
            objs[0] = exp;
            objs[1] = cv;
            return objs;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //判断用户是否开启这个口诀

    public boolean koujue_open(int userLv, String type) throws Exception {
        try {
            Map<String, CdMessyData> map = (Map<String, CdMessyData>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
            for (int i = 0; i < client_type.length; i++) {
                if (type.equals(client_type[i])) {
                    Object obj = map.get(map_key[i]);
                    if (obj != null) {
                        CdMessyData cd = (CdMessyData) obj;
                        if (userLv >= Integer.parseInt(cd.getMessyValue())) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return false;

    }
}
