/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdFormula;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.tools.FelCount;
import com.bsc.util.tools.Tools;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class CommonBo extends DaosPublic {
    @Resource
    private CacheHandler ch;
    
    private static final Logger log = LoggerFactory.getLogger(CommonBo.class);


    public int getIntFromFormula(int formulaMapKey, Map formulaValueMap) {
        //查找公式码表
        Map cdFormula_map = (Map) ch.getObjectFromCache(CacheNames.FORMULABASIC_CODE_CACHE, ElementKeys.CODE_TABLE_KEY);
        CdFormula cdFormula = (CdFormula) cdFormula_map.get(formulaMapKey);
        //封装公式需要的参数
        Number final_exp_number = FelCount.getCountResult(formulaValueMap, cdFormula.getGongshi());
        return Tools.getNumberToInt(final_exp_number);
    }
    //存储定时清除的公共变量数据例如莫活动次数

    public Map getFixTimeCleanMap(String key) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, key);
            Map map = null;
            if (obj == null) {
                map = new HashMap();
            } else {
                map = (Map) obj;
            }
            return map;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
   
}
