/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.vo;

/**
 *
 * @author lxf
 */
public class BrokenListVo implements java.io.Serializable{
    private int mp_id;
    private String broken_info;;

    public int getMp_id() {
        return mp_id;
    }

    public void setMp_id(int mp_id) {
        this.mp_id = mp_id;
    }

   

    public String getBroken_info() {
        return broken_info;
    }

    public void setBroken_info(String broken_info) {
        this.broken_info = broken_info;
    }
    
   
    
}
