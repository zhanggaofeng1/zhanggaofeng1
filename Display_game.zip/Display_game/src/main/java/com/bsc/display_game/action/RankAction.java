/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;

import com.bsc.display_game.bo.RankBo;
import com.bsc.display_game.service.RankService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.io.ByteArrayInputStream;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/rank")
public class RankAction extends SuperAction {

    @Resource
    private RankService rankService;
    @Resource
    private RankBo rankBo;
    
    @Action(value = "list", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String list() {
        try {
            rankService.list(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "cr", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String cr() {
        try {
            rankBo.create();
            setJsonStream(new ByteArrayInputStream("123".getBytes()));
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
    
    @Action(value = "flush", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String flush() {
        try {
            rankService.flush(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
    
    @Action(value = "exchange", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String exchange() {
        try {
            rankService.exchange(this);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }
}
