/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.constants;

/**
 *
 * @author lxf
 */
public enum GrudgeConstants {
    FRIEND("1","-1","1"),
    ENEMY("2","-2","2"),
    ATTENT("3","-3","3");
    
    private final String value_add;
    private final String value_del;
    private final String value_find;
    
    GrudgeConstants(String value_add,String value_del,String value_find){
        this.value_add = value_add;
        this.value_del = value_del;
        this.value_find = value_find;
    }

    /**
     * @return the value_add
     */
    public String getValue_add() {
        return value_add;
    }

    /**
     * @return the value_rel
     */
    public String getValue_del() {
        return value_del;
    }  
   /**
     * @return the value_rel
     */
    public String getValue_find() {
        return value_find;
    }  
     
     
     
}
