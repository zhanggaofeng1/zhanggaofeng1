/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class BrokenSellListRQ extends ReceiveJson{
    @JsonProperty("li")
    private List<BrokenSell> brokenLt;

    public List<BrokenSell> getBrokenLt() {
        return brokenLt;
    }

    public void setBrokenLt(List<BrokenSell> brokenLt) {
        this.brokenLt = brokenLt;
    }
    
    
    
    
}
