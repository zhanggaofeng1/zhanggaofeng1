/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.battle.server.BattlePlInfoBean;
import com.bsc.battle.server.BattleUtilService;
import com.bsc.battle.vo.AttackUnit;
import com.bsc.battle.vo.PlayerBase;
import com.bsc.battle.vo.enums.BattleType;
import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.BrokenBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.CJBKSkill;
import com.bsc.commonproject.clinet.command.response.CJPackage;
import com.bsc.commonproject.clinet.command.response.RPBattleData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.CardTypeEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.GameConstants;
import com.bsc.commonproject.vo.BrokenVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.constants.CstateConstants;
import com.bsc.display_game.request.BrokenSell;
import com.bsc.display_game.vo.BrokenListVo;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.enums.MsgMode;
import com.bsc.message.server.NoteBoardService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdFormula;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CdSkillcfg;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpGestBroken;
import com.bsc.random.impl.RandFuncationBean;
import com.bsc.random.vo.GestUnder;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.json.JsonHelper;
import com.bsc.util.tools.FelCount;
import com.bsc.util.tools.Tools;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GestBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private NoteBoardService noteBoardService;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private CommonBo commonBo;
    @Resource
    private BrokenBo brokenBo;
    @Resource
    private RandFuncationBean randFuncationBean;
    @Resource
    private BattlePlInfoBean battlePlInfoBean;
    @Resource
    private BattleUtilService battleUtilService;
    @Resource
    private AddCardBo addCardBo;
    @Resource
    private SaveLogBo saveLogBo;
    private static final Logger log = LoggerFactory.getLogger(GestBo.class);

    //残片合成
    public RPChangeData mixtureBroken(int cardId, int userId, RPChangeData change) throws Exception {
        try {
//            int gestId = getGestIdIdFromBrokenId(brokenCodeId);
            MenPaiCacheVo user_vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (user_vo != null) {
                Map<Integer, BrokenVo> brokenVo_map = (Map<Integer, BrokenVo>) ch.getObjectFromCache(CacheNames.USER_GEST_BROKEN_CACHE, userId);
                //查询码表中需要合成的武功需要的个数
                Map<Integer, CdSkillcfg> broken_code_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.SKILLCFG_KEY);
                Object obj = brokenVo_map.get(cardId);
                if (obj == null) {
                    log.error("brokenCodeId does not exist");
                    change.setSt(CstateConstants.CANZHANG_NO);
                    return change;
                }
                BrokenVo vo = (BrokenVo) obj;
                int gestId = brokenBo.getGestIdIdFromBrokenId(vo.getBroken().getGestId());
                Object obj2 = broken_code_map.get(gestId);
                if (obj2 == null) {
                    log.error(CacheNames.BASIC_DATA_CACHE + " does not exist");
                    return change;
                }
                CdSkillcfg skill = (CdSkillcfg) obj2;
                if (vo.getBroken_map().size() < skill.getAmount()) {
                    log.error("broken num error");
                    change.setSt(CstateConstants.CANZHANG_NUMBER_NO);
                    return change;
                }
                boolean is_all_have = true;
                Map<String, Integer> broken_map = vo.getBroken_map();
                for (Map.Entry entry_type : broken_map.entrySet()) {
                    int broken_num = (Integer) entry_type.getValue();
                    if (broken_num < 1) {
                        is_all_have = false;
                        break;
                    }
                }
                if (is_all_have) {
                    boolean is_update = false;
                    //增加新的武功
                    CmMpGest gest = addCardBo.addCmMpGest(userId, gestId, GameConstants.DEFALUT_LEVEL);
                    //删除残片
                    Map new_broken_map = new HashMap();
                    for (Map.Entry entry_type : broken_map.entrySet()) {
                        String type = (String) entry_type.getKey();
                        int broken_num = (Integer) entry_type.getValue();
                        int num = broken_num - 1;
                        if (num == 0) {
                            is_update = true;
                            new_broken_map.remove(type);
                        } else {
                            new_broken_map.put(type, num);
                        }
                    }
                    vo.setBroken_map(new_broken_map);
                    brokenVo_map.put(vo.getBroken().getMpBrokenId(), vo);
                    if (is_update) {
                        //更新数据库
                        update_broken(vo);
                    }
                    change.getCv().getCc().add(PackageCardBo.getBrokenCard(vo.getBroken().getMpBrokenId(), vo.getBroken().getGestId(), new_broken_map, CardStatusEnum.add.value()));
                    //int cardId, int codeId, int lv,int state
                    change.getCv().getCc().add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), GameConstants.DEFALUT_LEVEL, CardStatusEnum.add.value()));
                    change.setSt(ErrorCodeEnum.normal_success.value());
                    ch.putObjectToCache(CacheNames.USER_GEST_BROKEN_CACHE, userId, brokenVo_map);

                    noteBoardService.addNodeBoardMsg(MsgMode.magic_merge_oper, user_vo.getUserId(), user_vo.getMpName(), skill.getId(), skill.getName(), 1);
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GestBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return change;
    }
    //武功参悟

    public RPChangeData ponder(List<Integer> list, int userId, int ponder_gest_id, RPChangeData change) throws Exception, Throwable {
        try {
            //判断该用户是否含有该武功
            Map cmMpGest_map = (Map) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            CmMpGest ponder_gest = null;
            boolean ble = false;
            List<CmMpGest> del_CmMpGests = new ArrayList();
            for (Integer gest_id : list) {
                Object obj = cmMpGest_map.get(gest_id);
                if (obj != null) {
                    CmMpGest g = (CmMpGest) obj;
                    del_CmMpGests.add(g);
                    if (g.getBattleDIscipleId() > 0) {
                        ble = true;
                        break;
                    }
                }
            }
            if (ble) {
                change.setSt(ErrorCodeEnum.up_lineup_no_delete.value());
                return change;
            }
            if (del_CmMpGests.size() != list.size()) {
                change.setSt(ErrorCodeEnum.user_data_error.value());
                return change;
            }
            Object ponder_obj = cmMpGest_map.get(ponder_gest_id);
            if (ponder_obj != null) {
                ponder_gest = (CmMpGest) ponder_obj;
            }
            if (ponder_gest == null) {
                change.setSt(ErrorCodeEnum.goal_prop_not_exist.value());
                return change;
            }

            //判断上限
            if (ponder_gest.getGestLevel() < 10) {
                //参悟几率
                GestUnder gestUnder = randFuncationBean.randSkillUnderstand(ponder_gest, del_CmMpGests);
                if (gestUnder != null) {
                    Map<Integer, CdSkillcfg> gest_code_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.SKILLCFG_KEY);
                    CdSkillcfg skill = (CdSkillcfg) gest_code_map.get(ponder_gest.getGestId());
                    //pz*100*$('Math').pow( skill_lv,2)                            
                    //封装公式需要的参数
                    Map formula_value_map = new HashMap();
                    formula_value_map.put("pz", skill.getPz());
                    formula_value_map.put("skill_lv", ponder_gest.getGestLevel());
                    int silver = commonBo.getIntFromFormula(27, formula_value_map);
                    if (vo.getMpSilver() >= silver) {
                        //删除参悟需要消耗的武功
                        for (Integer gest_id : list) {
                            CmMpGest gest = (CmMpGest) cmMpGest_map.get(gest_id);
                            //删除数据库
                            delete(gest);
                            //删除内存
                            cmMpGest_map.remove(gest.getMpGestId());
                            //封装返回数据
                            change.getCv().getCc().add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), CardTypeEnum.GEST_CARD_TYPE.value(), CardStatusEnum.del.value()));
                        }
                        //更新用户银元宝
                        mpcommonBo.consum_silver(userId, silver);
                        saveLogBo.sliver(ControlType.GEST_LEVEL, userId, vo.getMpName(), vo.getMpSilver(), -silver, "", 0);
                        //返回封装的消耗的银币数字
                        change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(-silver)));
                        //如果参悟成功则该武功升级 需要封装变化属性
                        if (gestUnder.isUderstand()) {
                            ponder_gest.setGestLevel(ponder_gest.getGestLevel() + 1);
                            ponder_gest.setFailRetuen(0);
                            change.getCv().getCc().add(PackageCardBo.getGestCard(ponder_gest.getMpGestId(), ponder_gest.getGestId(), ponder_gest.getGestLevel(), CardStatusEnum.add.value()));
                        } else {
                            ponder_gest.setFailRetuen(ponder_gest.getFailRetuen() + gestUnder.getFailRate());
                        }
                        cmMpGest_map.put(ponder_gest.getMpGestId(), ponder_gest);
                        ch.putObjectToCache(CacheNames.USER_GEST_CACHE, userId, cmMpGest_map);
                        change.setSt(ErrorCodeEnum.normal_success.value());

                        MsgMode MsgModeType = MsgMode.magic_comprehend_second;
                        if (skill.getPz() == 4) {
                            MsgModeType = MsgMode.magic_comprehend_first;
                        }
                        //增加走马灯消息, MsgMode mode, int userId, String mpName, int itemId, String itemName, int level
                        if (skill.getPz() == 4 || skill.getPz() == 3) {
                            noteBoardService.addNodeBoardMsg(MsgModeType, vo.getUserId(), vo.getMpName(), skill.getId(), skill.getName(), ponder_gest.getGestLevel());
                        }
                    } else {
                        change.setSt(CstateConstants.WUGONG_SHENGJI_MONEY_NO);
                    }
                } else {
                    change.setSt(ErrorCodeEnum.up_lineup_no_delete.value());
                }
            } else {
                change.setSt(CstateConstants.WUGONG_SHENGJI_SHANGXIAN);
            }

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }
    //抢夺残片

    public RPBattleData snatch(int have_uid, int snatch_uid, int brokenCodeId, String broken_type, RPBattleData rpbd) throws Exception {
        try {
            //判断拥有人是否含有该残片
            MenPaiCacheVo my_mp_vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, snatch_uid);
            Map<String, Integer> have_uid_map = null;
            have_uid_map = brokenBo.getBrokenMap(have_uid, brokenCodeId);
            if (have_uid_map == null || have_uid_map.isEmpty()) {
                log.error("have_uid_map is null");
                return rpbd;
            }
            //加载对手对象
            PlayerBase you_playerBase = battlePlInfoBean.getPlayerBattleData(have_uid, snatch_uid, true, false, BattleType.pvp_bt, 0);
            //加载自己信息对象
            PlayerBase my_playerBase = battlePlInfoBean.getPlayerBattleData(snatch_uid, snatch_uid, false, true, BattleType.pvp_bt, 0);
            //验证对方和己方数据都没问题
            if (you_playerBase != null && my_playerBase != null) {
                //加载战斗过程数据
                AttackUnit attackUnit = battleUtilService.requestBattle(my_playerBase, you_playerBase);
                //判断战斗结果和随机成功几率
                //  if (attackUnit != null && attackUnit.getBatResult() > 0 &&snatchResult(my_mp_vo.getMpLevel(), you_playerBase.getCjMpInfo().getLv())) {
                if (attackUnit != null && attackUnit.getBatResult() > 0) {
                    rpbd.setOl(attackUnit.getChInitData());
                    rpbd.setTr(attackUnit.getAk_round());
                    rpbd.setCf(my_playerBase.getCjfData());
                    rpbd.setCi(my_playerBase.getCjMpInfo());

                    brokenBo.update_less_broken(have_uid, brokenCodeId, broken_type, 1);
                    //更新用户数据
                    BrokenVo new_vo2 = addCardBo.AddCmMpGestBroken(snatch_uid, broken_type, 1, brokenCodeId);
                    CJBKSkill skill = new CJBKSkill();
                    skill.getC().put(broken_type, 1);
                    skill.setCid(new_vo2.getBroken().getMpBrokenId());
                    skill.setId(brokenCodeId);
                    skill.setCt(CardTypeEnum.GEST_CARD_TYPE.value());
                    CJPackage cp = new CJPackage();
                    cp.getCc().add(skill);
                    rpbd.setRw(cp);
                }
            }

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GestBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rpbd;
    }
    //更换,装备武功

    public void replace_gest(int down_cardId, int up_carsId, int userId, int site, int battleId) throws Exception {

        try {
            Map cmMpGest_map = (Map) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
            Object down_obj = cmMpGest_map.get(down_cardId);
            Object up_obj = cmMpGest_map.get(up_carsId);
            if (up_obj != null) {
                CmMpGest CmMpGest_up = (CmMpGest) up_obj;
                if (down_obj == null) {
                    CmMpGest_up.setGestSite(site);
                    CmMpGest_up.setBattleDIscipleId(battleId);
                    cmMpGest_map.put(CmMpGest_up.getMpGestId(), CmMpGest_up);
                } else {
                    CmMpGest CmMpGest_down = (CmMpGest) down_obj;
                    CmMpGest_up.setGestSite(CmMpGest_down.getGestSite());
                    CmMpGest_up.setBattleDIscipleId(battleId);
                    CmMpGest_down.setGestSite(0);
                    CmMpGest_down.setBattleDIscipleId(0);
                    cmMpGest_map.put(CmMpGest_down.getMpGestId(), CmMpGest_down);
                    cmMpGest_map.put(CmMpGest_up.getMpGestId(), CmMpGest_up);
                }
                ch.putObjectToCache(CacheNames.USER_GEST_CACHE, userId, cmMpGest_map);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //根据位置查找装备
    public CmMpGest getCmMpEquipFromCacheBySite(int userId, int battleId, int site) {
        Map<Integer, CmMpGest> cmMpGest_map = (Map<Integer, CmMpGest>) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
        if (cmMpGest_map != null) {
            for (Map.Entry entry_type : cmMpGest_map.entrySet()) {
                CmMpGest cmMpGest = (CmMpGest) entry_type.getValue();
                if (cmMpGest.getGestSite() == site && cmMpGest.getBattleDIscipleId() == battleId) {
                    return cmMpGest;
                }
            }
        }
        return null;
    }
    //查找弟子是否应用的相同的法术

    public boolean getCmMpGestFromCacheByApp(int userId, int battleId, int codeId) {
        Map<Integer, CmMpGest> cmMpGest_map = (Map<Integer, CmMpGest>) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
        if (cmMpGest_map != null) {
            for (Map.Entry entry_type : cmMpGest_map.entrySet()) {
                CmMpGest cmMpGest = (CmMpGest) entry_type.getValue();
                if (cmMpGest.getBattleDIscipleId() == battleId && cmMpGest.getGestId() == codeId) {
                    return false;
                }
            }
        }
        return true;
    }
    //残片卖出,

    public RPChangeData sellBronken(List<BrokenSell> brokenLt, int userId, RPChangeData change) throws Exception {
        try {

            Map<Integer, BrokenVo> cmMpGestBroken_map = (Map<Integer, BrokenVo>) ch.getObjectFromCache(CacheNames.USER_GEST_BROKEN_CACHE, userId);
            Map<Integer, CdSkillcfg> gest_code_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.SKILLCFG_KEY);
            int all_silver = 0;
            for (BrokenSell brokenSell : brokenLt) {
                BrokenVo brokenvo = (BrokenVo) cmMpGestBroken_map.get(brokenSell.getCardId());
                Map<String, Integer> broken_map = brokenvo.getBroken_map();
                Map<String, Integer> operat_broken_map = brokenvo.getBroken_map();
                Map<String, Integer> sell_broken_map = brokenSell.getMap();
                boolean is_all_sell = true;
                int sell_num = 0;
                if (sell_broken_map != null && !sell_broken_map.isEmpty()) {
                    is_all_sell = false;
                }
                for (Map.Entry entry_type : broken_map.entrySet()) {
                    String type = (String) entry_type.getKey();
                    int num = (Integer) entry_type.getValue();
                    if (is_all_sell) {
                        sell_num += num;
                    } else {
                        Object obj_num = sell_broken_map.get(type);
                        if (obj_num != null) {
                            int num1 = (Integer) obj_num;
                            sell_num = sell_num + num1;
                            if (num - num1 <= 0) {
                                operat_broken_map.remove(type);
                                break;
                            } else {
                                operat_broken_map.put(type, num - num1);
                            }
                        }
                    }
                }

                CdSkillcfg skill = (CdSkillcfg) gest_code_map.get(brokenBo.getGestIdIdFromBrokenId(brokenvo.getBroken().getGestId()));
                //封装公式需要的参数
                Map formula_value_map = new HashMap();
                formula_value_map.put("pz", skill.getPz());

                int silver = commonBo.getIntFromFormula(26, formula_value_map);
                //内存中获取残片的价格
                all_silver = all_silver + silver * sell_num;

                if (is_all_sell || operat_broken_map == null || operat_broken_map.isEmpty()) {
                    //删除数据库
                    delete(brokenvo.getBroken());
                    //删除内存
                    cmMpGestBroken_map.remove(brokenSell.getCardId());
                    change.getCv().getCc().add(PackageCardBo.getBrokenCard(brokenvo.getBroken().getMpBrokenId(), brokenvo.getBroken().getGestId(), null, CardStatusEnum.del.value()));
                } else {
                    brokenvo.setBroken_map(operat_broken_map);
                    cmMpGestBroken_map.put(brokenSell.getCardId(), brokenvo);
                    change.getCv().getCc().add(PackageCardBo.getBrokenCard(brokenvo.getBroken().getMpBrokenId(), brokenvo.getBroken().getGestId(), operat_broken_map, CardStatusEnum.add.value()));
                }
            }
            //更新用户银元宝
            mpcommonBo.add_silver(userId, all_silver);
            //返回封装的消耗的银币数字
            change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(all_silver)));
            ch.putObjectToCache(CacheNames.USER_GEST_BROKEN_CACHE, userId, cmMpGestBroken_map);
            change.setSt(ErrorCodeEnum.normal_success.value());
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }

    public List<CmMpGest> getCmMpGestFromCacheByCardSite(int userId, int battliId) {
        List<CmMpGest> list = new ArrayList();
        Map<Integer, CmMpGest> cmMpProps_map = (Map<Integer, CmMpGest>) ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
        if (cmMpProps_map != null && !cmMpProps_map.isEmpty()) {
            for (Map.Entry entry_type : cmMpProps_map.entrySet()) {
//                    int  cardId =  (Integer) entry_type.getKey();
                CmMpGest gest = (CmMpGest) entry_type.getValue();
                if (gest.getBattleDIscipleId() == battliId) {
                    list.add(gest);
                }
            }
        }
        return list;
    }
    //计算残章抢夺的陈功率

    public boolean snatchResult(int me_lv, int you_lv) {

        Map<String, CdMessyData> messyData_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
        CdMessyData cdMessyData = messyData_map.get("skill_grad1");
        int skill_grad1 = Integer.parseInt(cdMessyData.getMessyValue());
        CdMessyData cdMessyData2 = messyData_map.get("skill_grad2");
        int skill_grad2 = Integer.parseInt(cdMessyData2.getMessyValue());

        Map formula_value_map = new HashMap();
        formula_value_map.put("skill_grad1", skill_grad1);
        formula_value_map.put("my_lv", me_lv);
        formula_value_map.put("you_lv", you_lv);
        formula_value_map.put("skill_grad2", skill_grad2);
        //查找公式码表
        Map cdFormula_map = (Map) ch.getObjectFromCache(CacheNames.FORMULABASIC_CODE_CACHE, ElementKeys.CODE_TABLE_KEY);
        CdFormula cdFormula = (CdFormula) cdFormula_map.get(46);
        //封装公式需要的参数
        Number final_exp_number = FelCount.getCountResult(formula_value_map, cdFormula.getGongshi());
        double vale = Tools.getBigDecimal(final_exp_number.doubleValue(), 2);
        int value_int = (int) (vale * 100);
        int random = (1 + (int) (Math.random() * 100));
        if (value_int - random > 0) {
            return true;
        }

        return false;
    }

    public void update_broken(BrokenVo vo) throws Exception {
        try {
            CmMpGestBroken broken = vo.getBroken();
            broken.setBrokenInfo(JsonHelper.getJsonFromBeanNoSrting(vo.getBroken_map()));
            update(broken);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //查询残章列表
    public List<BrokenListVo> getBrokenList(int userId, int mp_lv, int gestId, List<String> brokenTypes) throws Exception {
        try {
            StringBuilder strb = new StringBuilder("select mp.mp_id ,bk.broken_info  from cimo_game_server_db.cm_menpai mp,cimo_game_server_db.cm_mp_gest_broken bk where 1=1 ");
            strb.append(" and mp.mp_id = bk.user_id");
            strb.append(" and mp.mp_id <>").append(userId);
            strb.append(" and mp.mp_level > ").append(mp_lv - 3);
            strb.append(" and mp.mp_level < ").append(mp_lv + 3);
            strb.append(" and bk.gest_id = ").append(gestId);
            if (brokenTypes != null && !brokenTypes.isEmpty()) {
                strb.append(" and (");
                int i = 0;
                for (String str : brokenTypes) {
                    i++;
                    strb.append(" bk.broken_info like '%\"").append(str).append("\"%'");
                    if (i != brokenTypes.size()) {
                        strb.append(" or ");
                    }
                }
                strb.append(")");
            }
            strb.append(" ORDER BY RAND() LIMIT 3");

            final String hql = strb.toString();
            return super.getHibernateTemplate().execute(new HibernateCallback<List>() {
                public List<BrokenListVo> doInHibernate(Session session) throws HibernateException, SQLException {
                    Query query = session.createSQLQuery(hql);
                    //1、将查询结果转换成List<Map<字段名,字段值>> 
                    query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
                    //2、将结果转换成指定的bean List<你的指定javaBean> 
                    query.setResultTransformer(Transformers.aliasToBean(BrokenListVo.class));
                    return query.list();
                }
            });
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
