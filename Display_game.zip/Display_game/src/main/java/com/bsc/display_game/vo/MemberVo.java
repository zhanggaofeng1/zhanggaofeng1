/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.vo;

/**
 *
 * @author lxf
 */
public class MemberVo implements java.io.Serializable{
    private int userId;
    private String name;
    private int devote;
    private int postId;
    private int level;
    

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDevote() {
        return devote;
    }

    public void setDevote(int devote) {
        this.devote = devote;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    
    
    
}
