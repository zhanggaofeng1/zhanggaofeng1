/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;

import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.vo.ReturnStatusVo;
import com.bsc.displaybases.SendData;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpDiscipleSoul;
import com.bsc.protracted.domin.CmMpEquip;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpGestZhenqi;
import com.bsc.protracted.domin.CmMpKoujue;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.util.json.JsonHelper;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/")
public class CacheSynchronousAction extends SuperAction {

    private String SK;
    private int UD;
    private String IV;
    private String parm;
    private int r = 0;
    @Resource
    private CacheHandler ch;

    @Action(value = "mp_session", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String mp_session() {
        try {
            //验证用户是否在线
            Object obj = ch.getObjectFromCache(CacheNames.USER_SESSION_CACHE, UD);
            if (obj != null) {
                String session = (String) ch.getObjectFromCache(CacheNames.USER_SESSION_CACHE, UD);
                ch.delMemoryForObject(CacheNames.VI_USER_CACHE, session);
            }
            ch.putObjectToCache(CacheNames.VI_USER_CACHE, SK, IV + ":" + UD);
            ch.putObjectToCache(CacheNames.USER_SESSION_CACHE, UD, SK);
            ReturnStatusVo vo = new ReturnStatusVo();
            vo.setStatus("OK");
            this.setResponseJson(JsonHelper.getJsonFromBean(vo));
            new SendData().sendDataToClient(this, false, false);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "mp_clean", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String mp_clean() {
        try {
            //验证用户是否在线
            Object obj = ch.getObjectFromCache(CacheNames.USER_SESSION_CACHE, UD);
            if (obj != null) {
                String session = (String) ch.getObjectFromCache(CacheNames.USER_SESSION_CACHE, UD);
                ch.delMemoryForObject(CacheNames.VI_USER_CACHE, session);
            }
            ReturnStatusVo vo = new ReturnStatusVo();
            vo.setStatus("OK");
            this.setResponseJson(JsonHelper.getJsonFromBean(vo));
            new SendData().sendDataToClient(this, false, false);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "find_cache_user", results =
            @Result(name = SUCCESS, type = "stream", params = {"inputName", "jsonStream", "contentType", "text/json;charset=UTF-8"}))
    public String find_cache_user() {
        try {

//     private CmMpLineup cmMpLineup;
//CmMpBarriers cmMpBarriers;
//     private CmMpAchievement cmMpAchievement;
//      private Map<String,CmMpOtherData> cmMpOtherDatas = new HashMap<String,CmMpOtherData>();


            CmMenpai mp = new CmMenpai();
            //验证用户是否在线
            int userId = UD;

            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            if (vo != null) {
                mp.setAllianceId(vo.getAllianceId());
                mp.setCmMpLineup(vo.getCmMpLineup());
                mp.setMpExp(vo.getMpExp());
                mp.setMpGold(vo.getMpGold());
                mp.setMpLevel(vo.getMpLevel());
                mp.setMpMomentum(vo.getMpMomentum());
                mp.setMpName(vo.getMpName());
                mp.setMpPhysique(vo.getMpPhysique());
                mp.setMpSilver(vo.getMpSilver());
                mp.setMpVip(vo.getMpVip());
                mp.setMpZhenyuan(vo.getMpZhenyuan());
                mp.setUserId(vo.getReal_userId());
                mp.setMpFlower(vo.getMpFlower());
                mp.setMpId(vo.getMpId());

                //弟子信息
                Object cmMpDisciple_obj = ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
                if (cmMpDisciple_obj == null) {
                    Map<Integer, CmMpDisciple> cmMpDisciples = (Map<Integer, CmMpDisciple>) cmMpDisciple_obj;
                    mp.setCmMpDisciples(cmMpDisciples);
                }
                //魂魄
                Object soul_obj = ch.getObjectFromCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId);
                if (soul_obj == null) {
                    Map<Integer,CmMpDiscipleSoul> cmMpDiscipleSouls = (Map<Integer,CmMpDiscipleSoul> )soul_obj;
                    mp.setCmMpDiscipleSouls(cmMpDiscipleSouls);
                }
                //道具
                Object prop_obj = ch.getObjectFromCache(CacheNames.USER_PROP_CACHE, userId);
                if (prop_obj == null) {
                    Map<Integer,CmMpProps> cmMpPropss = (Map<Integer,CmMpProps>)prop_obj;
                    mp.setCmMpPropss(cmMpPropss);
                }
                //武功
                Object gest_obj = ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
                if (gest_obj == null) {
                    Map<Integer,CmMpGest> cmMpGests = (Map<Integer,CmMpGest>)gest_obj;
                    mp.setCmMpGests(cmMpGests);
                }

                //真气
                Object zq_obj = ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
                if (zq_obj == null) {
                    Map<Integer,CmMpGestZhenqi> cmMpGestZhenqis = (Map<Integer,CmMpGestZhenqi>)zq_obj;
                    mp.setCmMpGestZhenqis(cmMpGestZhenqis);
                }
                //武功残片
                Object broken_obj = ch.getObjectFromCache(CacheNames.USER_GEST_BROKEN_CACHE, userId);
                if (broken_obj == null) {
                    Map barriers_map = (Map) broken_obj;
//                    Map<Integer,CmMpGestBroken> cmMpGestBrokens
                }
                //口诀
                Object kj_obj = ch.getObjectFromCache(CacheNames.USER_KOUJUE_CACHE, userId);
                if (kj_obj == null) {
                     Map<String,CmMpKoujue> cmMpKoujues = ( Map<String,CmMpKoujue>)kj_obj;
                     mp.setCmMpKoujues(cmMpKoujues);
                }
                //装备
                Object equip_obj = ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
                if (equip_obj == null) {
                    Map<Integer,CmMpEquip> cmMpEquips = (Map<Integer,CmMpEquip>)equip_obj;
                    mp.setCmMpEquips(cmMpEquips);
                }
                //关卡
                Object barriers_obj = ch.getObjectFromCache(CacheNames.USER_BARRIERS_DATA_CACHE, userId);
                if (barriers_obj == null) {
                    Map barriers_map = (Map) barriers_obj;
//                    Map<Integer,CmBattleDisciple> cmBattleDisciples
                }
                //武林谱
                Object wlp_obj = ch.getObjectFromCache(CacheNames.USER_WULINPU_CACHE, userId);
                if (wlp_obj == null) {
                }
                //成就
                Object achieve_obj = ch.getObjectFromCache(CacheNames.USER_ACHIEVEMENT_CACHE, userId);
                if (achieve_obj == null) {
                    //用户成就
                }
                //阵型数据
                Object zx_obj = ch.getObjectFromCache(CacheNames.USER_LINEUP_CACHE, userId);
                if (zx_obj == null) {
                }
                //门派相关数据
                Object other_obj = ch.getObjectFromCache(CacheNames.USER_OTHER_DATA_CACHE, userId);
                if (other_obj == null) {
                }


            }

                ReturnStatusVo vo1 = new ReturnStatusVo();
                vo1.setStatus("OK");
                this.setResponseJson(JsonHelper.getJsonFromBean(vo1));
                new SendData().sendDataToClient(this, false, false);
            }  catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    public String getSK() {
        return SK;
    }

    public void setSK(String SK) {
        this.SK = SK;
    }

    public int getUD() {
        return UD;
    }

    public void setUD(int UD) {
        this.UD = UD;
    }

    public String getIV() {
        return IV;
    }

    public void setIV(String IV) {
        this.IV = IV;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public String getParm() {
        return parm;
    }

    public void setParm(String parm) {
        this.parm = parm;
    }
    
    
}
