/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.cache.listener.factory;

import com.bsc.display_game.cache.listener.UserControlListener;
import java.util.Properties;
import net.sf.ehcache.event.CacheEventListener;
import net.sf.ehcache.event.CacheEventListenerFactory;

/**
 * Cache监听工厂
 *
 * @author penn
 */
public class UserControlListenerFactory extends CacheEventListenerFactory {

    @Override
    public CacheEventListener createCacheEventListener(Properties prprts) {
        return UserControlListener.INSTANCE;
    }
}
