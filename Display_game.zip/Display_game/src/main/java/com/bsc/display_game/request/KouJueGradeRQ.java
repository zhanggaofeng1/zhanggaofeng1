/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class KouJueGradeRQ extends ReceiveJson{
    @JsonProperty("xt")
    private String type;
    @JsonProperty("lp")
    private List<Integer> disCardId;
    @JsonProperty("lg")
    private List<String> soulCardIds;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Integer> getDisCardId() {
        return disCardId;
    }

    public void setDisCardId(List<Integer> disCardId) {
        this.disCardId = disCardId;
    }

    public List<String> getSoulCardIds() {
        return soulCardIds;
    }

    public void setSoulCardIds(List<String> soulCardIds) {
        this.soulCardIds = soulCardIds;
    }
    
    
    
    
    
    
}
