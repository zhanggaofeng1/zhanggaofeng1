/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class ClientActionLog {
    
    
//    @JsonProperty("p")
    private int seq;
     @JsonProperty("p")
    private String site;
      @JsonProperty("ud")
    private int time;

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

  
      
      
      
      
}
