/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.constants;

/**
 *
 * @author lxf
 */
public enum RankEnum {

    TOP10_USER("TOP10"),
    ATTACK_USER("HIT_BACK_PAIHANG"),
    NORMAL_USER("NORMAL_PAIHANG"),
    DOWN_USER("LOW_PAIHANG"),
    ;
    private String key;

    RankEnum(String key) {
        this.key = key;
    }

    public String value() {
        return key;
    }
}
