/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;


import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class EquipSellRQ extends ReceiveJson{
     @JsonProperty("il")
   private List<Integer> equipIds;

    public List<Integer> getEquipIds() {
        return equipIds;
    }

    public void setEquipIds(List<Integer> equipIds) {
        this.equipIds = equipIds;
    }
   
   

   
    
}
