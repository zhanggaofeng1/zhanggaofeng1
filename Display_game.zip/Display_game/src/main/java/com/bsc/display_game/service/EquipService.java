/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;



import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface EquipService extends BaseDao{
    
    public void upgrade(SuperAction sa)throws Exception;
    
    public void refining(SuperAction sa)throws Exception;
    
    public void sell(SuperAction sa)throws Exception;
}
