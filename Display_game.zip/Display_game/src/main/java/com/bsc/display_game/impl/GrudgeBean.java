/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.FriendBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.CJSnsUser;
import com.bsc.commonproject.clinet.command.response.RPFindSnsUser;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.Constants;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.EnemyVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.Message;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.display_game.bo.GrudgeBo;
import com.bsc.display_game.bo.MenPaiBo;
import com.bsc.display_game.bo.QueueBo;
import com.bsc.display_game.constants.GrudgeConstants;
import com.bsc.display_game.request.MessageReturnRQ;
import com.bsc.display_game.request.FriendInviteRQ;
import com.bsc.display_game.request.GrudgeDelRQ;
import com.bsc.display_game.request.GrudgeListRQ;
import com.bsc.display_game.request.SendFlowerRQ;
import com.bsc.display_game.service.GrudgeService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.CommMsgBean;
import com.bsc.message.server.LevelMsgService;
import com.bsc.message.server.SystemMsgService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CmFriend;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.util.json.JsonHelper;
import com.bsc.util.list.BSCLinkedMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GrudgeBean extends DaosPublic implements GrudgeService {

    private static final Logger log = LoggerFactory.getLogger(GrudgeBean.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private GrudgeBo grudgeBo;
    @Resource
    private CommMsgBean commMsgBean;
    @Resource
    private LevelMsgService levelMsgService;
    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private SystemMsgService systemMsgService;
    @Resource
    private FriendBo friendBo;
    @Resource
    private QueueBo queueBo;

    /**
     * 好友邀请请求，当用户发出邀请信息是将信息保存到内存当中，被邀请用户下次登录时加载请求
     *
     */
    public void invite(SuperAction sa) throws Exception {
        try {
            RPState publicRP = new RPState();
            String friend_request_json = sa.getRequestJson();
            FriendInviteRQ friendInviteRQ = (FriendInviteRQ) JsonHelper.getBeanFromJson(friend_request_json, FriendInviteRQ.class);
            int userId = friendInviteRQ.getUserid();
            int fid = friendInviteRQ.getFid();
            if (userId != fid) {
                if (fid != 0) {
                    String name = null;
                    MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
                    if (vo != null) {
                        name = vo.getMpName();
                    } else {
                        CmMenpai mp = menPaiBo.getCmMenpaiFromDB(userId);
                        name = mp.getMpName();
                    }
                    levelMsgService.someOneRequestSomeOneJoinFriend(userId, name, fid);
                }
                publicRP.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                publicRP.setSt(ErrorCodeEnum.user_data_error.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GrudgeBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * 该方法用来增加好友，仇敌和关注 1: 增加好友，被邀请用户接收到请求信息是做出的回应，无论被邀请人是否同意好友关系，都将删除请求消息 2：增加仇敌 3：增加关注
     */
    public void add(SuperAction sa) throws Exception {
        try {
            RPState publicRP = new RPState();
            String add_json = sa.getRequestJson();
            MessageReturnRQ friendConfirmRQ = (MessageReturnRQ) JsonHelper.getBeanFromJson(add_json, MessageReturnRQ.class);
            int userId = friendConfirmRQ.getUserid();
            int messageId = friendConfirmRQ.getMessageId();
            int messageType = friendConfirmRQ.getMessageType();
            String type = GrudgeConstants.FRIEND.getValue_add();
            String result = friendConfirmRQ.getResult();
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            //查找消息
            Message m = commMsgBean.getDifTypeOfMessage(userId, messageId, messageType);
            if (m == null) {
                if (Constants.DEFALUT_OK_1.equals(result)) {
                    if (GrudgeConstants.FRIEND.getValue_add().equals(type)) {
                        //增加好友
                        int add_result = grudgeBo.add_friend(m.getSenderId(), userId);
                        if (add_result == -1) {
                            publicRP.setSt(ErrorCodeEnum.user_enemy.value());
                        } else if (add_result == -2) {
                            publicRP.setSt(ErrorCodeEnum.arrive_limit.value());
                        } else {
                            levelMsgService.someOneAgreeJoinFriend(vo.getUserId(), vo.getMpName(), m.getSenderId());
                            publicRP.setSt(ErrorCodeEnum.normal_success.value());
                        }
                    }
                } else {
                    levelMsgService.someOneRefuseRequestJoinFriend(vo.getUserId(), vo.getMpName(), m.getSenderId());
                    publicRP.setSt(ErrorCodeEnum.normal_success.value());
                }
            }
//            else if (GrudgeConstants.ENEMY.getValue_add().equals(type)) {
////                friendBo.add_enemy(fid, userId);
//            } else if (GrudgeConstants.ATTENT.getValue_add().equals(type)) {
//                friendBo.add_attention(fid, userId);
//            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GrudgeBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * 获取恩怨列表
     *
     */
    public void list(SuperAction sa) throws Exception {
        try {
            RPFindSnsUser friend = new RPFindSnsUser();
            String list_json = sa.getRequestJson();
            GrudgeListRQ grudgeListRQ = (GrudgeListRQ) JsonHelper.getBeanFromJson(list_json, GrudgeListRQ.class);
            int userId = grudgeListRQ.getUserid();
            int type = grudgeListRQ.getType();
            int page = grudgeListRQ.getPage();
            int num = grudgeListRQ.getNum();
            if (num == 0) {
                num = 20;
            }
            String info = grudgeListRQ.getInfo();
            List<CmMenpai> list = null;
            BSCLinkedMap map = null;
            switch (type) {
                case 1://搜索查找不是我好友的用户 
                    String ids = grudgeBo.getFriendIds(userId);
                    list = grudgeBo.getCmFriendSearch(userId, info, page, num, ids);
                    break;
                case 2://搜索查找是我好友里的用户
                    list = grudgeBo.getCmMenpaiList(userId, page, num, info);
                    break;
                case 3://仇敌列表
                    map = grudgeBo.getCmEnemyList(userId);
                    break;
                case 4://好友列表
                    list = grudgeBo.getCmMenpaiList(userId, page, num, null);
                    break;
                case 5://愁人和好友列表一起加载    
                    map = grudgeBo.getCmEnemyList(userId);
                    list = grudgeBo.getCmMenpaiList(userId, page, num, null);
                    break;
            }
            if (list != null) {
                for (CmMenpai cmMenpai : list) {
                    friend.getLrs().add(new CJSnsUser(cmMenpai.getMpId(), cmMenpai.getMpName(), cmMenpai.getMpLevel(), cmMenpai.getMpVip(), 0));
                }
            }
            if (map != null) {
                Iterator it = map.entrySet().iterator();
                BSCLinkedMap del_map = grudgeBo.getCmEnemyList(userId);
                while (it.hasNext()) {
                    Map.Entry entry = (Map.Entry) it.next();
                    Integer key = (Integer) entry.getKey();
                    EnemyVo vo = (EnemyVo) entry.getValue();
//                    if (DateUtil.getCurrentDate().getTime() - vo.getEndDate().getTime() >= 0) {
//                        del_map.remove(key);
//                    } else {
                    Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, key);
                    if (obj == null) {
                        queueBo.addUserInPicture(userId);
                        obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, key);
                    }
                    if (obj != null) {
                        UserPictureVo upv = (UserPictureVo) obj;
                        friend.getLrs().add(new CJSnsUser(key, upv.getName(), upv.getLevel(), upv.getVip(), vo.getType()));
                    }
                }
                ch.putObjectToCache(CacheNames.USER_EMENY_CACHE, userId, del_map);
            }
            friend.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(friend));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    /**
     * 该操作用来删除恩怨信息：好友，仇敌和关注 -1：删除好友 -2：删除仇敌 -3：删除关注
     */
    public void del(SuperAction sa) throws Exception {
        try {
            RPState publicRP = new RPState();
            String del_json = sa.getRequestJson();
            GrudgeDelRQ grudgeDelRQ = (GrudgeDelRQ) JsonHelper.getBeanFromJson(del_json, GrudgeDelRQ.class);
            int userId = grudgeDelRQ.getUserid();
            int fid = grudgeDelRQ.getFid();
            String type = GrudgeConstants.FRIEND.getValue_del();
            if (GrudgeConstants.FRIEND.getValue_del().equals(type)) {
                List<CmFriend> list = friendBo.getCmFriendList(userId, fid);
                if (list != null && !list.isEmpty()) {
                    delete((CmFriend) list.get(0));
                }
            }
//            else if (GrudgeConstants.ENEMY.getValue_del().equals(type)) {
//                List<CmEnemy> list = friendBo.getCmEnemyList(userId, fid);
//                if (list != null && !list.isEmpty()) {
//                    delete((CmEnemy) list.get(0));
//                }
//            } else if (GrudgeConstants.ATTENT.getValue_del().equals(type)) {
//                List<CmAttention> list = friendBo.getCmAttentionList(userId, fid);
//                if (list != null && !list.isEmpty()) {
//                    delete((CmAttention) list.get(0));
//                }
//            }
            publicRP.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void flower(SuperAction sa) throws Exception {
        try {
            RPState publicRP = new RPState();
            String json = sa.getRequestJson();
            SendFlowerRQ flower = (SendFlowerRQ) JsonHelper.getBeanFromJson(json, SendFlowerRQ.class);
            int userId = flower.getUserid();
            int receive_userId = flower.getRecrive_userId();
            int num = flower.getType();
            MenPaiCacheVo my_vo = menPaiBo.getCmMenpaiFromCache(userId);

            String recName = "";
            //增加好友的花
            int flower_num = mpcommonBo.getPlayNum(21, userId, 2, true);
            if (flower_num == -1) {
                publicRP.setSt("too many");
            } else {
                if (grudgeBo.my_send_user(userId, receive_userId)) {
                    if (grudgeBo.receive_flower_num(receive_userId)) {
                        MenPaiCacheVo receive_vo = menPaiBo.getCmMenpaiFromCache(receive_userId);
                        if (receive_vo != null) {
                            recName = receive_vo.getMpName();
                            mpcommonBo.update_flower(receive_userId, num);
                        } else {
                            CmMenpai mp = menPaiBo.getCmMenpaiFromDB(receive_userId);
                            recName = mp.getMpName();
                            mp.setMpFlower(mp.getMpFlower() + num);
                            update(mp);
                        }
                        //增加我的花值
                        mpcommonBo.update_flower(userId, num);
                        systemMsgService.sendFloorMsg(userId, my_vo.getMpName(), my_vo.getMpVip(), receive_userId, recName);
                        publicRP.setSt(ErrorCodeEnum.normal_success.value());
                    } else {
                        publicRP.setSt("have send");
                    }
                } else {
                    publicRP.setSt("receive too many");
                }
            }

//            List<CmFriend> lt = friendBo.getCmFriendList(userId, receive_userId);
//            if (lt != null) {
//                CmFriend fr = (CmFriend) lt.get(0);
//                fr.setFriendValue(fr.getFriendValue() + 10);
//                update(fr);
//            }

            //int senderId, String senderName, int friendVal, int recId, String recName
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GrudgeBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
