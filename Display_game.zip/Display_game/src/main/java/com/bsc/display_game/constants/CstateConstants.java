/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.constants;

import com.bsc.commonproject.constants.ErrorCodeEnum;

/**
 *
 * @author lxf
 */
public class CstateConstants {
    //提升弟子不存在
    public static final String TISHENG_DISCIPLE_NO =ErrorCodeEnum.goal_prop_not_exist.value();
    //提升金币不够
    public static final String TISHENG_GOLD_NO = ErrorCodeEnum.gold_not_enough.value();
    //提升道具不够
    public static final String TISHENG_PROP_NO =ErrorCodeEnum.consum_prop_not_enough.value();
    //传授门徒不存在
    public static final String CHUANSHOU_DISCIPLE_NO=ErrorCodeEnum.goal_prop_not_exist.value();
    //传授消耗的门徒不存在
    public static final String CHUANSHOU_DEL_DISCIPLE_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //传授培养单不够
    public static final String CHUANSHOU_PEIYANGDAN_NO = ErrorCodeEnum.consum_prop_not_enough.value();
    //突破弟子不存在
    public static final String TUPO_DISCIPLE_NO=ErrorCodeEnum.goal_prop_not_exist.value();
    //突破魂魄不存在
    public static final String TUPO_SOUL_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //突破条件不符合
    public static final String TUPO_NO =ErrorCodeEnum.not_requirements.value();
    //弟子招募
    public static final String ZHAOMU_DISCIPLE_NO=ErrorCodeEnum.not_requirements.value();
    //招募魂魄不存在
    public static final String ZHAOMU_SOUL_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //招募魂魄数量不够
    public static final String ZHAOMU_SOUL_NUM_NO=ErrorCodeEnum.count_not_enough.value();
    //升级装备不存在
    public static final String SHENGJI_ZHUANGBEI_NO=ErrorCodeEnum.goal_prop_not_exist.value();
    //装备已经达到上限
    public static final String SHENGJI_ZHANGBEI_SHANGXIAN = ErrorCodeEnum.arrive_limit.value();
    //装备升级银币不够
    public static final String SHENEGJI_ZHUANGBEI_SLIVER_NO=ErrorCodeEnum.silver_not_enough.value();
    //精炼装备不存在
    public static final String JINGLIAN_ZHUANGBEI_NO = ErrorCodeEnum.goal_prop_not_exist.value();
    //装备精炼的等级上限
    public static final String JINGLIAN_ZHUANGBEI_SHANGXINA=ErrorCodeEnum.arrive_limit.value();
    //消耗材料不够
    public static final String JINGLIAN_PROP_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //武功升级目标武功不存在
    public static final String WUGONG_SHNEGJI_GOAL_NO = ErrorCodeEnum.goal_prop_not_exist.value();
    //消耗武功不存在
    public static final String WUGONG_SHENGJI_DEL_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //武功升级上限
    public static final String WUGONG_SHENGJI_SHANGXIAN=ErrorCodeEnum.arrive_limit.value();
    //武功升级消耗金钱不够
    public static final String WUGONG_SHENGJI_MONEY_NO=ErrorCodeEnum.gold_not_enough.value();
    //残章合成残障不够
    public static final String CANZHANG_NUMBER_NO=ErrorCodeEnum.count_not_enough.value();
    //残障不存在
    public static final String CANZHANG_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //真气升级目标真气不存在
    public static final String ZHENQI_SHENGJI_GOAL_NO=ErrorCodeEnum.goal_prop_not_exist.value();
    //消耗真气不存在
    public static final String ZHEN_SHNEGJI_DEL_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //升级上限
    public static final String ZHENQI_SHENGJI_SHANGXIAN=ErrorCodeEnum.arrive_limit.value();
    //练气金币或者银币不够
//    public static final String LIANQI_MONEY_NO="ConditionError_Card_money";
    //练气CD时间未到
    public static final String LIANQI_CD_NO=ErrorCodeEnum.cd_time_not_arrive.value();
    //真气兑换
    public static final String ZHENQI_DUIHUAN_NUM_NO=ErrorCodeEnum.count_not_enough.value();
    //真气不存在
    public static final String ZEHNQI_DUIHUAN_NO=ErrorCodeEnum.goal_prop_not_exist.value();
    //口诀状态 没有开启
    public static final String KOUJUE_STARTR_NO=ErrorCodeEnum.not_requirements.value();
    //口诀 魂魄格式不对
    public static final String KOUJUE_SOUL_FORMAT_NO=ErrorCodeEnum.info_error_json.value();
    //口诀 魂魄不存在
    public static final String KOUJUE_SOUL_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    //口诀 弟子不存在
    public static final String KOUJUE_DISCIPLE_NO=ErrorCodeEnum.consum_prop_not_enough.value();
    
    
    
    
    
}
