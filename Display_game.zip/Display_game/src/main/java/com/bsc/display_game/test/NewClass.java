/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.test;

import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.request.BattlleRQ;
import com.bsc.display_game.request.AddQueueDIsRQ;
import com.bsc.display_game.request.AllanceCreateRQ;
import com.bsc.display_game.request.AllianceApplyRQ;
import com.bsc.display_game.request.AllianceApplyResultRQ;
import com.bsc.display_game.request.AllianceOperateRQ;
import com.bsc.display_game.request.AlliancePrayerRQ;
import com.bsc.display_game.request.AllianceQuitRQ;
import com.bsc.display_game.request.BrokenSell;
import com.bsc.display_game.request.BrokenSellListRQ;
import com.bsc.display_game.request.ChangeQueueRQ;
import com.bsc.display_game.request.CreateMPRQ;
import com.bsc.display_game.request.EditCardSiteRQ;
import com.bsc.display_game.request.EquipRefining;
import com.bsc.display_game.request.EquipRefiningRQ;
import com.bsc.display_game.request.EquipSellRQ;
import com.bsc.display_game.request.EquipUpgradeRQ;
import com.bsc.display_game.request.FriendInviteRQ;
import com.bsc.display_game.request.GestBrokenListRQ;
import com.bsc.display_game.request.GestMixRQ;
import com.bsc.display_game.request.GestUpgradeRQ;
import com.bsc.display_game.request.GetQueueListRQ;
import com.bsc.display_game.request.MessageReturnRQ;
import com.bsc.display_game.request.GrudgeDelRQ;
import com.bsc.display_game.request.GrudgeListRQ;
import com.bsc.display_game.request.KouJueGradeRQ;
import com.bsc.display_game.request.RechargeRQ;
import com.bsc.display_game.request.RecruitDisRQ;
import com.bsc.display_game.request.SendFlowerRQ;
import com.bsc.display_game.request.ShopBuyRQ;
import com.bsc.display_game.request.ShopOpenRQ;
import com.bsc.display_game.request.TQLoadRQ;
import com.bsc.display_game.request.TrainConfirmRQ;
import com.bsc.display_game.request.TrainRQ;
import com.bsc.display_game.request.TransferRQ;
import com.bsc.display_game.request.TuPoRQ;
import com.bsc.display_game.request.ZQLianQiRQ;
import com.bsc.display_game.request.ZQUpgradeRQ;

import com.bsc.util.json.JsonHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author lxf
 */
public class NewClass {

    public static void main(String[] d) throws Exception {

        FriendInviteRQ fi = new FriendInviteRQ();
        fi.setUserid(1);
        fi.setFid(2);
        System.out.println("invite----------->" + JsonHelper.getJsonFromBean(fi));
        MessageReturnRQ ga = new MessageReturnRQ();
//        ga.setFid(2);
//        ga.setType("1");
//        ga.setInviteResult("1");
        ga.setUserid(1);



        System.out.println("friend---add----------->" + JsonHelper.getJsonFromBean(ga));

        GrudgeListRQ gl = new GrudgeListRQ();
        gl.setType(1);
        gl.setUserid(1);
        gl.setInfo("sd");
        System.out.println("friend---list----------->" + JsonHelper.getJsonFromBean(gl));

        GrudgeDelRQ gd = new GrudgeDelRQ();
        gd.setFid(2);
//        gd.setType("-1");
        gd.setUserid(1);
        System.out.println("friend---del----------->" + JsonHelper.getJsonFromBean(gd));


        CreateMPRQ cm = new CreateMPRQ();
        cm.setUserid(4);
        cm.setDisId(101001006);
        cm.setName("测试数据4");
        System.out.println("CreateMPRQ-------------------->" + JsonHelper.getJsonFromBean(cm));

        RecruitDisRQ rd = new RecruitDisRQ();
        rd.setUserid(1);
        rd.setSoulid(1);
        System.out.println("RecruitDisRQ-------------------->" + JsonHelper.getJsonFromBean(rd));


        TransferRQ tf = new TransferRQ();
        tf.setCardId(2);
        List<Integer> dl = new ArrayList();
        dl.add(4);
        tf.setCardIds(dl);
        tf.setPropid(1);
        System.out.println("TransferRQ-------------------->" + JsonHelper.getJsonFromBean(tf));
        RPChangeData change = new RPChangeData();
        System.out.println("TransferRQ-------------------->" + JsonHelper.getJsonFromBean(change));

        TrainRQ tr = new TrainRQ();
        tr.setCardId(2);
        tr.setType(2);
        tr.setUserid(1);

        System.out.println("TrainRQ-------------------->" + JsonHelper.getJsonFromBean(tr));
        TrainConfirmRQ tcm = new TrainConfirmRQ();
//        tcm.setCardId(2);
        tcm.setReslut("1");
        tcm.setUserid(1);
        System.out.println("TrainConfirmRQ-------------------->" + JsonHelper.getJsonFromBean(tcm));

        EquipUpgradeRQ eu = new EquipUpgradeRQ();
        eu.setCardId(1);
        eu.setUserid(1);
        System.out.println("EquipUpgradeRQ-------------------->" + JsonHelper.getJsonFromBean(eu));
        EquipRefiningRQ erf = new EquipRefiningRQ();
        EquipRefining er = new EquipRefining();
        er.setCardId(2);
        er.setNum(1);
        List l2 = new ArrayList();
        l2.add(er);
        erf.setCardId(1);
        erf.setEquipRefinings(l2);

        System.out.println("EquipRefiningRQ-------------------->" + JsonHelper.getJsonFromBean(erf));

        GestUpgradeRQ gur = new GestUpgradeRQ();
        gur.setCardId(1);
        List lg = new ArrayList();
        lg.add(5);
        lg.add(6);
        gur.setUserid(1);
        gur.setDelCardIds(lg);
        System.out.println("GestUpgradeRQ-------------------->" + JsonHelper.getJsonFromBean(gur));

        GestMixRQ gm = new GestMixRQ();
        gm.setCardId(1);
        gm.setUserid(1);

        System.out.println("GestMixRQ-------------------->" + JsonHelper.getJsonFromBean(gm));
        ZQUpgradeRQ zqup = new ZQUpgradeRQ();
        zqup.setCardId(1);
        List ls = new ArrayList();
        ls.add(2);
        zqup.setDelCardIds(ls);
        System.out.println("ZQUpgradeRQ-------------------->" + JsonHelper.getJsonFromBean(zqup));

        ZQLianQiRQ lq = new ZQLianQiRQ();
        lq.setLq_type(2);
//        lq.setStart_site(2);
        System.out.println("ZQLianQiRQ-------------------->" + JsonHelper.getJsonFromBean(lq));

        GetQueueListRQ gql = new GetQueueListRQ();
        gql.setRequest_type(1);
        gql.setUserid(1);
        System.out.println("GetQueueListRQ-------------------->" + JsonHelper.getJsonFromBean(gql));

        EditCardSiteRQ ecs = new EditCardSiteRQ();
        ecs.setCardId(6);
        ecs.setEquipSite(3);
        ecs.setEquipType(2);
        ecs.setQueueSite(1);
        ecs.setUserid(1);
        System.out.println("EditCardSiteRQ-------------------->" + JsonHelper.getJsonFromBean(ecs));

        AddQueueDIsRQ aqd = new AddQueueDIsRQ();
        aqd.setDisCardId(3);
        aqd.setSite(3);
        aqd.setUserid(1);
        System.out.println("AddQueueDIsRQ-------------------->" + JsonHelper.getJsonFromBean(aqd));

        ChangeQueueRQ cq = new ChangeQueueRQ();
        List ll = new ArrayList();
        ll.add(2);
        ll.add(1);
        ll.add(3);
        cq.setSiteList(ll);
        cq.setUserid(1);
        System.out.println("ChangeQueueRQ-------------------->" + JsonHelper.getJsonFromBean(cq));

        Map nm = new HashMap();
        nm.put(1, 4);
        nm.put(2, 3);
        nm.put(3, 1);
        nm.put(4, 5);
        System.out.println("as-------------------->" + JsonHelper.getJsonFromBeanNoSrting(nm));



        BattlleRQ gs = new BattlleRQ();
        Map mm = new HashMap();
        mm.put("brokenCodeId", 120001001);
        mm.put("brokenType", 3);
        gs.setCompetitorId(2);
        gs.setUserid(1);
        gs.setAppendMap(mm);

        System.out.println("BattlleRQ-------------------->" + JsonHelper.getJsonFromBean(gs));


        TuPoRQ tp = new TuPoRQ();
        tp.setSoulid(0);
        tp.setUserid(0);
        System.out.println("TuPoRQ-------------------->" + JsonHelper.getJsonFromBean(tp));

        System.out.println((10 / 10) + "---" + (10 % 10));


        EquipSellRQ ere = new EquipSellRQ();
        List<Integer> ererlt = new ArrayList<Integer>();
        ererlt.add(2);
        ere.setUserid(1);
        ere.setEquipIds(ererlt);
        System.out.println("EquipSellRQ-------------------->" + JsonHelper.getJsonFromBean(ere));

        GestBrokenListRQ gbl = new GestBrokenListRQ();
        gbl.setGestCodeId(120001001);
        List<String> gblt = new ArrayList<String>();
        gblt.add("2");
        gbl.setTypeList(gblt);
        System.out.println("GestBrokenListRQ-------------------->" + JsonHelper.getJsonFromBean(gbl));

        AllanceCreateRQ ac = new AllanceCreateRQ();
        ac.setName("sfs4");
        ac.setUserid(2);
        System.out.println("AllanceCreateRQ-------------------->" + JsonHelper.getJsonFromBean(ac));
        AllianceApplyRQ aar = new AllianceApplyRQ();
        aar.setAllianceId(2);
        aar.setUserid(1);
        System.out.println("AllianceApplyRQ-------------------->" + JsonHelper.getJsonFromBean(aar));
        AllianceApplyResultRQ aarr = new AllianceApplyResultRQ();
        aarr.setResult("1");
        aarr.setUserid(2);
        System.out.println("AllianceApplyResultRQ-------------------->" + JsonHelper.getJsonFromBean(aarr));
        AllianceOperateRQ ao = new AllianceOperateRQ();
        ao.setOp_userId(2);
        ao.setOperationType(4);
        ao.setUserid(1);
        System.out.println("AllianceOperateRQ-------------------->" + JsonHelper.getJsonFromBean(ao));

        AllianceQuitRQ aq = new AllianceQuitRQ();
        aq.setUserid(2);
        System.out.println("AllianceQuitRQ-------------------->" + JsonHelper.getJsonFromBean(aq));

        AlliancePrayerRQ ap = new AlliancePrayerRQ();
        ap.setUserid(1);
        ap.setPrayerType(1);
        System.out.println("AlliancePrayerRQ-------------------->" + JsonHelper.getJsonFromBean(ap));


        KouJueGradeRQ kjr = new KouJueGradeRQ();
        List<Integer> l1 = new ArrayList<Integer>();
        l1.add(20);
        kjr.setDisCardId(l1);
        List<String> l3 = new ArrayList<String>();
        l3.add("1:10");
        kjr.setSoulCardIds(l3);
        kjr.setUserid(1);
        kjr.setType("atk");
        System.out.println("KouJueGradeRQ-------------------->" + JsonHelper.getJsonFromBean(kjr));

        SendFlowerRQ sf = new SendFlowerRQ();
        sf.setRecrive_userId(2);
        sf.setType(1);
        sf.setUserid(1);
        System.out.println("SendFlowerRQ-------------------->" + JsonHelper.getJsonFromBean(sf));

        ShopOpenRQ so = new ShopOpenRQ();
        so.setCardId(7);
        so.setUserid(1);
        System.out.println("ShopOpenRQ-------------------->" + JsonHelper.getJsonFromBean(so));

        TQLoadRQ tl = new TQLoadRQ();
        tl.setType(1);
        tl.setUserid(1);
        System.out.println("TQLoadRQ-------------------->" + JsonHelper.getJsonFromBean(tl));

        BrokenSellListRQ bs = new BrokenSellListRQ();
        Map m = new HashMap();
        m.put("1", 1);
        BrokenSell b = new BrokenSell();
        b.setCardId(6);
        b.setMap(m);
        bs.setUserid(1);
        List<BrokenSell> brokenLt = new ArrayList<BrokenSell>();
        brokenLt.add(b);
        bs.setBrokenLt(brokenLt);
        System.out.println("BrokenSellListRQ-------------------->" + JsonHelper.getJsonFromBean(bs));


        RechargeRQ rr = new RechargeRQ();
        rr.setKey("aaaaa");
        rr.setRechargeId(1);
        rr.setUserid(46);
        System.out.println("RechargeRQ-------------------->" + JsonHelper.getJsonFromBean(rr));

        ShopBuyRQ s = new ShopBuyRQ();
        s.setUserid(1);
        s.setNum(1);
        s.setType(2);
        s.setCodeId(140010001);
        System.out.println("ShopBuyRQ-------------------->" + JsonHelper.getJsonFromBean(s));

        ShopOpenRQ or = new ShopOpenRQ();
        or.setCardId(1128);
        or.setNum(1);
        or.setUserid(174);
        System.out.println("ShopOpenRQ-------------------->" + JsonHelper.getJsonFromBean(or));

        MessageReturnRQ mr = new MessageReturnRQ();
        mr.setMessageId(1);
        mr.setUserid(399);
        mr.setMessageType(16);
        mr.setResult("1");
        System.out.println("MessageReturnRQ-------------------->" + JsonHelper.getJsonFromBean(mr));
    }

    public static String getCharacterAndNumber(int length) {
        String val = "";

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num"; // 输出字母还是数字  
            if ("char".equalsIgnoreCase(charOrNum)) // 字符串  
            {
                int choice = random.nextInt(2) % 2 == 0 ? 65 : 97; //取得大写字母还是小写字母  
                val += (char) (choice + random.nextInt(26));
            } else if ("num".equalsIgnoreCase(charOrNum)) // 数字  
            {
                val += String.valueOf(random.nextInt(10));
            }
        }

        return val;
    }
}
