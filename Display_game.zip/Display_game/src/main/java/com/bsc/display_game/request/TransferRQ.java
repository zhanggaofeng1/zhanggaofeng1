/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;


import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class TransferRQ extends ReceiveJson {

    @JsonProperty("id")
    private int cardId; //门徒卡牌id
    @JsonProperty("dl")
    private List<Integer> cardIds;//消耗弟子
    @JsonProperty("iid")
    private int propid;//消耗道具

    public int getPropid() {
        return propid;
    }

    public void setPropid(int propid) {
        this.propid = propid;
    }

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public List<Integer> getCardIds() {
        return cardIds;
    }

    public void setCardIds(List<Integer> cardIds) {
        this.cardIds = cardIds;
    }
}
