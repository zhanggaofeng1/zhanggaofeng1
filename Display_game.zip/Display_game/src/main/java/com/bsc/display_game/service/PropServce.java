/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;

import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface PropServce extends BaseDao{
    public void open(SuperAction sa) throws Exception;
    public void load_tq(SuperAction sa) throws Exception;
    public void add_tq(SuperAction sa) throws Exception;
    public void menpai_update(SuperAction sa) throws Exception;
    public void use(SuperAction sa) throws Exception;
    
}
