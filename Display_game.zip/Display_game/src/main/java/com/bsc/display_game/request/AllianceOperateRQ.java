/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class AllianceOperateRQ extends ReceiveJson{
     @JsonProperty("id")
    private int op_userId;
      @JsonProperty("ot")
    private int operationType;;

    public int getOp_userId() {
        return op_userId;
    }

    public void setOp_userId(int op_userId) {
        this.op_userId = op_userId;
    }

    public int getOperationType() {
        return operationType;
    }

    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }
    
    

   

    
   
    
    
    
    
    
}
