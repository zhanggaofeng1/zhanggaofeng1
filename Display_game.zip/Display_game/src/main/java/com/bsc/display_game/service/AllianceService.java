/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;

import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface AllianceService extends BaseDao {
    //创建门派

    public void create(SuperAction sa) throws Exception;
    //申请加入

    public void apply(SuperAction sa) throws Exception;
    //申请返回结果

    public void applyresult(SuperAction sa) throws Exception;
    //成员列表

    public void memeberlist(SuperAction sa) throws Exception;
    //联盟列表

    public void alliancelist(SuperAction sa) throws Exception;
    //祈福

    public void prayer(SuperAction sa) throws Exception;
    //领工资

    public void pay(SuperAction sa) throws Exception;
    //黑市列表

//    public void heiShiList(SuperAction sa) throws Exception;
    //黑市购买

    public void buy(SuperAction sa) throws Exception;
    //申请列表

    public void applylist(SuperAction sa) throws Exception;
    //解散联盟

    public void disband(SuperAction sa) throws Exception;
    //斗战胜佛

    public void douzhanshengfo_apply(SuperAction sa) throws Exception;
    //斗战胜佛结果

    public void douzhanshengfo_result(SuperAction sa) throws Exception;
    //获取联盟数据

    public void alliance(SuperAction sa) throws Exception;

    //邀请结果

    public void inviteresut(SuperAction sa) throws Exception;
    
    //查找可以用户列表，邀请加入联盟
    public void findUserList(SuperAction sa) throws Exception;
    //联盟成员管理
    public void manager(SuperAction sa) throws Exception;
    
    
}
