/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.service.ManagerInterface;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.display_game.vo.RankVo;
import com.bsc.logs.util.LogHelper;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class RankLogBean extends ManagerInterface{

    @Resource
    private CacheHandler ch;
    @Resource
    private SaveLogBo saveLogBo;

    private static final Logger log = LoggerFactory.getLogger(RankLogBean.class);
    
    @Override
    public void rank_data() {
//        List<RankVo> rvlt = null;
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            if (obj != null) {
                List<RankVo> list = (List) obj;
                if (!list.isEmpty()) {
                    List<RankVo> top_list = new ArrayList();
                    int end_site1 = 1000;
                    if (list.size() < 1000) {
                        end_site1 = list.size();
                    }
                    top_list.addAll(list.subList(0, end_site1));
                    int i = 0;
                    for (RankVo vo : top_list) {
                        Object pic_obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, vo.getUserId());
                        if (pic_obj != null) {
                            UserPictureVo upv = (UserPictureVo) pic_obj;
                            //int mp_id, String name, int rank, int lv, int score
                            saveLogBo.sendDiscusses(vo.getUserId(), upv.getName(), i++, upv.getLevel(), vo.getScore());
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
        }
        
    }
}
