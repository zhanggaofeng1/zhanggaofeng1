/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;



import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface QueueService extends BaseDao{
    public void getQueueList(SuperAction sa)throws Exception;
    
    public void editCardSite(SuperAction sa)throws Exception;
    
    public void addQueueDIs(SuperAction sa)throws Exception;

    
    public void changeQueue(SuperAction sa)throws Exception;
    
}
