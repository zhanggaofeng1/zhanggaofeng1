/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.constants.GameConstants;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdBaby;
import com.bsc.protracted.domin.CdExprience;
import com.bsc.protracted.domin.CdRecruit;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpDiscipleSoul;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;

import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class DiscipleBo extends DaosPublic {

    private static final Logger log = LoggerFactory.getLogger(DiscipleBo.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private CommonBo commonBo;




    public CmMpDiscipleSoul getCmMpDiscipleSoulFromCache(int userId, int cardId) {
        Object cmMpDiscipleSouls_obj = ch.getObjectFromCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId);

        if (cmMpDiscipleSouls_obj != null) {
            Map cmMpDiscipleSoul_map = (Map) cmMpDiscipleSouls_obj;
            return (CmMpDiscipleSoul) cmMpDiscipleSoul_map.get(cardId);
        }
        return null;
    }
    public int[] getallExpToLevel(int all_exp, int codeId) throws Exception {
        CdExprience current_cdExprience = null;
        int[] array_int = new int[2];//0:当前等级 1:剩余经验
        array_int[0] = 0;
        array_int[1] = 0;
        int level = 0;
        try {
            Map<Integer, CdExprience> map = (Map<Integer, CdExprience>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.EXPRIENCE_KEY);
            //查找弟子码表
            Map baby_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
            CdBaby cdBaby = (CdBaby) baby_map.get(codeId);
            double scale = Tools.getBigDecimal(all_exp / cdBaby.getExp(), 1);
            for (Map.Entry entry_type : map.entrySet()) {
//                int cardId = (Integer) entry_type.getKey();
                CdExprience cdExprience = (CdExprience) entry_type.getValue();
                if (cdExprience.getExpneed() > scale) {
                    level = cdExprience.getLv() - 1;
                    break;
                }
            }

            current_cdExprience = (CdExprience) map.get(level);
            if (current_cdExprience != null) {
                //封装公式需要的参数
                Map formula_value_map = new HashMap();
                formula_value_map.put("exp", cdBaby.getExp());
                formula_value_map.put("expneed", current_cdExprience.getExpneed());
                int final_exp_int = commonBo.getIntFromFormula(1, formula_value_map);

                array_int[0] = level;
                //计算剩余经验
                array_int[1] = all_exp - final_exp_int;
            }

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return array_int;
    }

    //根据弟子类别查找用户该类别下载弟子
    public List<CmMpDisciple> getCmMpDiscipleListFromCacheFromPz(int userId, int pz) {
        List<CmMpDisciple> lt = new ArrayList<CmMpDisciple>();
        Object cmMpDisciples_obj = ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
        if (cmMpDisciples_obj != null) {
            Map baby_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
            Map<Integer, CmMpDisciple> cmMpDisciples_map = (Map<Integer, CmMpDisciple>) cmMpDisciples_obj;
            for (Map.Entry entry_type : cmMpDisciples_map.entrySet()) {
//                int cardId = (Integer) entry_type.getKey();
                CmMpDisciple cmMpDisciple = (CmMpDisciple) entry_type.getValue();
                CdBaby cdBaby = (CdBaby) baby_map.get(cmMpDisciple.getDiscipleId());
                if (cdBaby.getPz() == pz) {
                    lt.add(cmMpDisciple);
                }
            }
        }
        return lt;
    }

    //根据出入不同的mapkey获取不同的CdRecruit值
    public int getCdRecruitValue(int disCodeId, String mapKey) {
        //查找弟子码表
        Map baby_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DATA_CACHE, ElementKeys.BABY_KEY);
        CdBaby cdBaby = (CdBaby) baby_map.get(disCodeId);

        //查找品质对应的码表数据
        Map reciuit_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RECRUIT_KEY);
        CdRecruit cdRecruit = (CdRecruit) reciuit_map.get(mapKey);

        //查找对应品质对应的数值
        int value = 0;
        switch (cdBaby.getPz()) {
            case GameConstants.QUALITY_DING://丁及品质 
                value = cdRecruit.getFourLv();
                break;
            case GameConstants.QUALITY_BING://丙级品质
                value = cdRecruit.getThridLv();
                break;
            case GameConstants.QUALITY_YI://乙级品质
                value = cdRecruit.getSecondLv();
                break;
            case GameConstants.QUALITY_JIA://甲级品质
                value = cdRecruit.getFirstLv();
                break;
        }
        return value;
    }
}
