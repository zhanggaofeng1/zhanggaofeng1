/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.bo.WordFilter;
import com.bsc.commonproject.clinet.command.response.CJCardBase;
import com.bsc.commonproject.clinet.command.response.CJUserData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPUserData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.PropConstants;
import com.bsc.commonproject.vo.BrokenVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.TiYanVipVo;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.protracted.domin.CmMpAchievement;
import com.bsc.protracted.domin.CmMpDisciple;
import com.bsc.protracted.domin.CmMpDiscipleSoul;
import com.bsc.protracted.domin.CmMpEquip;
import com.bsc.protracted.domin.CmMpGest;
import com.bsc.protracted.domin.CmMpGestBroken;
import com.bsc.protracted.domin.CmMpGestZhenqi;
import com.bsc.protracted.domin.CmMpKoujue;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.util.datas.StringUtil;
import com.bsc.util.json.JsonHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class MenPaiBo extends DaosPublic {

    @Resource
    private CacheHandler ch;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private PropBo propBo;
    @Resource
    private KoujueBo koujueBo;
    @Resource
    private WordFilter wordFilter;

    private static final Logger log = LoggerFactory.getLogger(MenPaiBo.class);

    public boolean is_huan_name(String name) {
        List list = get(CmMenpai.class, "mpName", name, true);
        if (list == null || list.isEmpty()) {
            return true;
        }
        return false;
    }

    public CmMenpai getCmMenpaiFromDB(Integer userId) {
        return (CmMenpai) get(CmMenpai.class, userId);
    }

    public MenPaiCacheVo getCmMenpaiFromCache(int userId) {
        Object obj = ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
        if (obj != null) {
            return (MenPaiCacheVo) obj;
        }
        return null;
    }

    public String getMenPaiName(int userId) {
        MenPaiCacheVo friend_vo = getCmMenpaiFromCache(userId);
        String recName = "";
        if (friend_vo != null) {
            recName = friend_vo.getMpName();
        } else {
            CmMenpai mp = getCmMenpaiFromDB(userId);
            recName = mp.getMpName();
        }
        return recName;
    }

    //用户获修改vip
    public boolean update_vip(int userId, int vip) throws Exception {
        boolean ble = true;
        try {
            //更新用户vip
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            vo.setMpVip(vip);
            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, userId);
            if (obj != null) {
                UserPictureVo picvo = (UserPictureVo) obj;
                picvo.setVip(vip);
                ch.putObjectToCache(CacheNames.USER_PICTURE_DATA_CACHE, userId, picvo);
            }
            ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, userId, vo);

            //将信息更新至数据库
            CmMenpai cmMenpai = (CmMenpai) get(CmMenpai.class, userId);
            if (cmMenpai != null) {
                cmMenpai.setMpVip(vip);
                update(cmMenpai);
            }

        } catch (Exception e) {
            ble = false;
            log.error(LogHelper.getException(e));
            throw e;
        }
        return ble;
    }
//用户修改名称

    public boolean update_name(int userId, String name) throws Exception {
        boolean ble = true;
        try {
            //更新用户银元宝
            MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, userId);
            vo.setMpName(name);
            ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, userId, vo);
            //将信息更新至数据库
            //将信息更新至数据库
            CmMenpai cmMenpai = (CmMenpai) get(CmMenpai.class, userId);
            if (cmMenpai != null) {
                cmMenpai.setMpName(name);
                update(cmMenpai);
            }
            //用户修改门派名称时候将内存中的门派头像信息同时修改名称
            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, userId);
            if (obj != null) {
                UserPictureVo picvo = (UserPictureVo) obj;
                picvo.setName(name);
                ch.putObjectToCache(CacheNames.USER_PICTURE_DATA_CACHE, userId, picvo);
            }

        } catch (Exception e) {
            ble = false;
            log.error(LogHelper.getException(e));
            throw e;
        }
        return ble;
    }

    //封装用户卡牌数据
    public List<CJCardBase> getUserCardList(CmMenpai cmMenpai) throws Exception {
        try {
            List<CJCardBase> cjlt = new ArrayList<CJCardBase>();
            //弟子
            Map cmMpDisciple_map = cmMenpai.getCmMpDisciples();
            for (Map.Entry entry_type : cmMenpai.getCmMpDisciples().entrySet()) {
                CmMpDisciple cmMpDisciple = (CmMpDisciple) entry_type.getValue();
                cjlt.add(PackageCardBo.getDicCardAll(cmMpDisciple.getDisLevel(), cmMpDisciple.getTupoLevel(), cmMpDisciple.getDisExp(), cmMpDisciple.getDisAtk(), cmMpDisciple.getDisDef(), cmMpDisciple.getDisHp(), cmMpDisciple.getDisMp(), cmMpDisciple.getDisPotential(), cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
            }

            ch.putObjectToCache(CacheNames.USER_DISCIPLE_CACHE, cmMenpai.getMpId(), cmMpDisciple_map);

            //弟子魂魄
            Map cmMpDiscipleSoul_map = cmMenpai.getCmMpDiscipleSouls();
            if (cmMpDiscipleSoul_map == null || cmMpDiscipleSoul_map.isEmpty()) {
                cmMpDiscipleSoul_map = new HashMap<Integer, CmMpDiscipleSoul>();
            }
            for (Map.Entry entry_type : cmMenpai.getCmMpDiscipleSouls().entrySet()) {
                CmMpDiscipleSoul cmMpDiscipleSoul = (CmMpDiscipleSoul) entry_type.getValue();

                cjlt.add(PackageCardBo.getSoulCard(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul.getDiscipleId(), cmMpDiscipleSoul.getSoulNum(), CardStatusEnum.add.value()));
            }
            ch.putObjectToCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, cmMenpai.getMpId(), cmMpDiscipleSoul_map);
            //道具数据
            Map cCmMpProps_map = cmMenpai.getCmMpPropss();
            if (cCmMpProps_map == null || cCmMpProps_map.isEmpty()) {
                cCmMpProps_map = new HashMap<Integer, CmMpProps>();
            }
            for (Map.Entry entry_type : cmMenpai.getCmMpPropss().entrySet()) {
                CmMpProps cmMpProps = (CmMpProps) entry_type.getValue();
                cjlt.add(PackageCardBo.getPropCard(cmMpProps.getMpPropId(), cmMpProps.getPropId(), cmMpProps.getPropNum(), cmMpProps.getPropLv(), CardStatusEnum.add.value()));
            }
            ch.putObjectToCache(CacheNames.USER_PROP_CACHE, cmMenpai.getMpId(), cCmMpProps_map);
            //武功
            Map gest_map = cmMenpai.getCmMpGests();
            if (gest_map == null || gest_map.isEmpty()) {
                gest_map = new HashMap<Integer, CmMpGest>();
            }
            for (Map.Entry entry_type : cmMenpai.getCmMpGests().entrySet()) {
                CmMpGest gest = (CmMpGest) entry_type.getValue();
                cjlt.add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), 0));
            }
            ch.putObjectToCache(CacheNames.USER_GEST_CACHE, cmMenpai.getMpId(), gest_map);
            //真气
            Map zq_map = cmMenpai.getCmMpGestZhenqis();
            if (zq_map == null || zq_map.isEmpty()) {
                zq_map = new HashMap<Integer, CmMpGestZhenqi>();
            }
            for (Map.Entry entry_type : cmMenpai.getCmMpGestZhenqis().entrySet()) {
                CmMpGestZhenqi zq = (CmMpGestZhenqi) entry_type.getValue();
                cjlt.add(PackageCardBo.getZhenQiCard(zq.getMpZhenqiId(), zq.getZhenqiId(), zq.getZhenqiLevel(), zq.getZhenqiExp(), CardStatusEnum.add.value()));
            }
            ch.putObjectToCache(CacheNames.USER_ZHENQI_CACHE, cmMenpai.getMpId(), zq_map);
            //武功残片
            Map<Integer, CmMpGestBroken> cmMpGestBrokens = cmMenpai.getCmMpGestBrokens();
            Map<Integer, BrokenVo> gest_broken_map = new HashMap<Integer, BrokenVo>();
            for (Map.Entry entry_type : cmMpGestBrokens.entrySet()) {
                CmMpGestBroken broken = (CmMpGestBroken) entry_type.getValue();
                Map broken_type_map = new HashMap();
                if (broken.getBrokenInfo() != null && StringUtil.isNotNull(broken.getBrokenInfo())) {
                    broken_type_map = (Map) JsonHelper.getBeanFromJson(broken.getBrokenInfo(), Map.class);
                    BrokenVo bvo = new BrokenVo();
                    bvo.setBroken(broken);
                    bvo.setBroken_map(broken_type_map);
                    gest_broken_map.put(broken.getMpBrokenId(), bvo);
                }
                cjlt.add(PackageCardBo.getBrokenCard(broken.getMpBrokenId(), broken.getGestId(), broken_type_map, CardStatusEnum.add.value()));
            }
            ch.putObjectToCache(CacheNames.USER_GEST_BROKEN_CACHE, cmMenpai.getMpId(), gest_broken_map);
            //武功口诀
            Map koujue_map = cmMenpai.getCmMpKoujues();
            if (koujue_map == null || koujue_map.isEmpty()) {
                koujue_map = new HashMap<Integer, CmMpKoujue>();
            }
            ch.putObjectToCache(CacheNames.USER_KOUJUE_CACHE, cmMenpai.getMpId(), koujue_map);
            //装备

            Map equip_map = cmMenpai.getCmMpEquips();
            if (equip_map == null || equip_map.isEmpty()) {
                equip_map = new HashMap<Integer, CmMpEquip>();
            }
            for (Map.Entry entry_type : cmMenpai.getCmMpEquips().entrySet()) {
                CmMpEquip equip = (CmMpEquip) entry_type.getValue();
                cjlt.add(PackageCardBo.getEquipCard(equip.getMpEquipId(), equip.getEquipId(), equip.getEquipLevel(), equip.getRefiningLevel(), equip.getRefiningExp(), CardStatusEnum.add.value()));
            }
            ch.putObjectToCache(CacheNames.USER_EQUIP_CACHE, cmMenpai.getMpId(), equip_map);
            return cjlt;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPUserData loadfromdb(CmMenpai cmMenpai, RPUserData userDatd) throws Exception {
        try {
            MenPaiCacheVo vo = new MenPaiCacheVo();
            vo.setAllianceId(cmMenpai.getAllianceId());
            vo.setCmMpLineup(cmMenpai.getCmMpLineup());
            vo.setMpExp(cmMenpai.getMpExp());
            vo.setMpGold(cmMenpai.getMpGold());
            vo.setMpLevel(cmMenpai.getMpLevel());
            vo.setMpMomentum(cmMenpai.getMpMomentum());
            vo.setMpName(cmMenpai.getMpName());
            vo.setMpPhysique(cmMenpai.getMpPhysique());
            vo.setMpSilver(cmMenpai.getMpSilver());
            vo.setMpVip(cmMenpai.getMpVip());
            vo.setMpZhenyuan(cmMenpai.getMpZhenyuan());
            vo.setUserId(cmMenpai.getMpId());
            vo.setLoginStatue(1);
            vo.setMpId(cmMenpai.getMpId());
            vo.setReal_userId(cmMenpai.getUserId());
            vo.setMpFlower(cmMenpai.getMpFlower());

            ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, cmMenpai.getMpId(), vo);

            CmMpAchievement cmMpAchievement = cmMenpai.getCmMpAchievement();
            int c = 0;
            if (cmMpAchievement != null) {
                c = cmMpAchievement.getAchieveValue();
            }

            //用户成就
            ch.putObjectToCache(CacheNames.USER_ACHIEVEMENT_CACHE, cmMenpai.getMpId(), cmMpAchievement);

            mpcommonBo.edit_physique(cmMenpai.getMpId(), 0, 0);
            mpcommonBo.edit_momentum(cmMenpai.getMpId(), 0, 0);

            CJUserData ud = new CJUserData();
            ud.setId(vo.getMpId());
            ud.setN(vo.getMpName());
            ud.setG(vo.getMpGold());
            ud.setS(vo.getMpSilver());
            ud.setC(c);
            ud.setLv(vo.getMpLevel());
            ud.setExp(vo.getMpExp());
            ud.setT(vo.getMpPhysique());
            ud.setQ(vo.getMpMomentum());
            ud.setVip(vo.getMpVip());
            ud.setAid(vo.getAllianceId());
            TiYanVipVo tyv = mpcommonBo.get_vip_tiyan(cmMenpai.getMpId());
            if (tyv != null) {
                vo.setTiYanVipVo(tyv);
                ud.setTvip(tyv.getVip());
            }
            userDatd.setCardlist(getUserCardList(cmMenpai));
            userDatd.setLi(koujueBo.getKoujueList(cmMenpai.getMpId()));

            //关卡数据
            Map barriers_map = new HashMap();
            if (cmMenpai.getCmMpBarriers() != null) {
                String json_str = cmMenpai.getCmMpBarriers().getBarriersInfo();
                if (StringUtil.isNotNull(json_str)) {
                    barriers_map = (Map) JsonHelper.getBeanFromJson(json_str, Map.class);
                }
            }
            ch.putObjectToCache(CacheNames.USER_BARRIERS_DATA_CACHE, cmMenpai.getMpId(), barriers_map);
            //武林谱
            ch.putObjectToCache(CacheNames.USER_WULINPU_CACHE, cmMenpai.getMpId(), cmMenpai.getCmMpWulinpus());
            //加载弟子阵型数据
            ch.putObjectToCache(CacheNames.USER_LINEUP_CACHE, cmMenpai.getMpId(), cmMenpai.getCmBattleDisciples());
            //加载用户杂项数据
            ch.putObjectToCache(CacheNames.USER_OTHER_DATA_CACHE, cmMenpai.getMpId(), cmMenpai.getCmMpOtherDatas());

            userDatd.setUdata(ud);
            return userDatd;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPUserData loadfromcache(int userId, RPUserData userDatd) throws Exception {
        try {
            MenPaiCacheVo vo = getCmMenpaiFromCache(userId);
            vo.setLoginStatue(1);
            ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, vo.getUserId(), vo);
            TiYanVipVo tyv = mpcommonBo.get_vip_tiyan(userId);
            if (tyv != null) {
                vo.setTiYanVipVo(tyv);
            }

            mpcommonBo.edit_physique(userId, 0, 0);
            mpcommonBo.edit_momentum(userId, 0, 0);
            CJUserData ud = new CJUserData();
            ud.setId(vo.getUserId());
            ud.setN(vo.getMpName());
            ud.setG(vo.getMpGold());
            ud.setS(vo.getMpSilver());
            int c = 0;
            Object o = ch.getObjectFromCache(CacheNames.USER_ACHIEVEMENT_CACHE, userId);
            if (o != null) {
                CmMpAchievement cmMpAchievement = (CmMpAchievement) o;
                c = cmMpAchievement.getAchieveValue();
            }
            ud.setC(c);
            ud.setLv(vo.getMpLevel());
            ud.setExp(vo.getMpExp());
            ud.setT(vo.getMpPhysique());
            ud.setQ(vo.getMpMomentum());
            ud.setVip(vo.getMpVip());
            ud.setAid(vo.getAllianceId());
            userDatd.setCardlist(getUserCardList(userId));
            userDatd.setLi(koujueBo.getKoujueList(vo.getUserId()));
            if (tyv != null) {
                vo.setTiYanVipVo(tyv);
                ud.setTvip(tyv.getVip());
            }
            userDatd.setUdata(ud);

            return userDatd;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //封装用户卡牌数据

    public List<CJCardBase> getUserCardList(int userId) throws Exception {
        try {
            List<CJCardBase> cjlt = new ArrayList<CJCardBase>();
            //弟子
            Object cmMpDisciple_obj = ch.getObjectFromCache(CacheNames.USER_DISCIPLE_CACHE, userId);
            if (cmMpDisciple_obj != null) {
                Map<Integer, CmMpDisciple> cmMpDisciple_map = (Map<Integer, CmMpDisciple>) cmMpDisciple_obj;
                for (Map.Entry entry_type : cmMpDisciple_map.entrySet()) {
                    CmMpDisciple cmMpDisciple = (CmMpDisciple) entry_type.getValue();
                    cjlt.add(PackageCardBo.getDicCardAll(cmMpDisciple.getDisLevel(), cmMpDisciple.getTupoLevel(), cmMpDisciple.getDisExp(), cmMpDisciple.getDisAtk(), cmMpDisciple.getDisDef(), cmMpDisciple.getDisHp(), cmMpDisciple.getDisMp(), cmMpDisciple.getDisPotential(), cmMpDisciple.getMpDisId(), cmMpDisciple.getDiscipleId(), CardStatusEnum.add.value(), cmMpDisciple.getGestId()));
                }
            }
            //弟子魂魄;
            Object cmMpDiscipleSoul_obj = ch.getObjectFromCache(CacheNames.USER_DISCIPLE_SOUL_CACHE, userId);
            if (cmMpDiscipleSoul_obj != null) {
                Map<Integer, CmMpDiscipleSoul> cmMpDiscipleSoul_map = (Map<Integer, CmMpDiscipleSoul>) cmMpDiscipleSoul_obj;
                for (Map.Entry entry_type : cmMpDiscipleSoul_map.entrySet()) {
                    CmMpDiscipleSoul cmMpDiscipleSoul = (CmMpDiscipleSoul) entry_type.getValue();
                    cjlt.add(PackageCardBo.getSoulCard(cmMpDiscipleSoul.getSoulId(), cmMpDiscipleSoul.getDiscipleId(), cmMpDiscipleSoul.getSoulNum(), CardStatusEnum.add.value()));
                }
            }
            //道具数据

            Object cCmMpProps_obj = ch.getObjectFromCache(CacheNames.USER_PROP_CACHE, userId);
            if (cCmMpProps_obj != null) {
                Map<Integer, CmMpProps> cCmMpProps_map = (Map<Integer, CmMpProps>) cCmMpProps_obj;
                for (Map.Entry entry_type : cCmMpProps_map.entrySet()) {
                    CmMpProps cmMpProps = (CmMpProps) entry_type.getValue();
                    cjlt.add(PackageCardBo.getPropCard(cmMpProps.getMpPropId(), cmMpProps.getPropId(), cmMpProps.getPropNum(), cmMpProps.getPropLv(), CardStatusEnum.add.value()));
                }
            }

            //武功
            Object gest_obj = ch.getObjectFromCache(CacheNames.USER_GEST_CACHE, userId);
            if (gest_obj != null) {
                Map<Integer, CmMpGest> map = (Map<Integer, CmMpGest>) gest_obj;
                for (Map.Entry entry_type : map.entrySet()) {
                    CmMpGest gest = (CmMpGest) entry_type.getValue();
                    cjlt.add(PackageCardBo.getGestCard(gest.getMpGestId(), gest.getGestId(), gest.getGestLevel(), 0));
                }
            }

            //真气
            Object zq_obj = ch.getObjectFromCache(CacheNames.USER_ZHENQI_CACHE, userId);
            if (zq_obj != null) {
                Map<Integer, CmMpGestZhenqi> zq_map = (Map<Integer, CmMpGestZhenqi>) zq_obj;
                for (Map.Entry entry_type : zq_map.entrySet()) {
                    CmMpGestZhenqi zq = (CmMpGestZhenqi) entry_type.getValue();
                    cjlt.add(PackageCardBo.getZhenQiCard(zq.getMpZhenqiId(), zq.getZhenqiId(), zq.getZhenqiLevel(), zq.getZhenqiExp(), CardStatusEnum.add.value()));
                }
            }
            //武功残片
            Object broken_obj = ch.getObjectFromCache(CacheNames.USER_GEST_BROKEN_CACHE, userId);
            if (broken_obj != null) {
                Map<Integer, BrokenVo> BrokenVo_map = (Map<Integer, BrokenVo>) broken_obj;
                for (Map.Entry entry_type : BrokenVo_map.entrySet()) {
                    BrokenVo broken = (BrokenVo) entry_type.getValue();
                    cjlt.add(PackageCardBo.getBrokenCard(broken.getBroken().getMpBrokenId(), broken.getBroken().getGestId(), broken.getBroken_map(), CardStatusEnum.add.value()));
                }
            }
            //装备
            Object equip_obj = ch.getObjectFromCache(CacheNames.USER_EQUIP_CACHE, userId);
            if (equip_obj != null) {
                Map<Integer, CmMpEquip> equip_map = (Map<Integer, CmMpEquip>) equip_obj;
                for (Map.Entry entry_type : equip_map.entrySet()) {
                    CmMpEquip equip = (CmMpEquip) entry_type.getValue();
                    cjlt.add(PackageCardBo.getEquipCard(equip.getMpEquipId(), equip.getEquipId(), equip.getEquipLevel(), equip.getRefiningLevel(), equip.getRefiningExp(), CardStatusEnum.add.value()));
                }
            }
            return cjlt;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPChangeData renamed(int userId, String name) throws Exception {
        RPChangeData rud = new RPChangeData();
        try {
            if (name == null || !StringUtil.isNotNull(name)) {
                rud.setSt(ErrorCodeEnum.info_error_must_data_null.value());
                return rud;
            }
            if (!wordFilter.wordValite(name)) {
                rud.setSt(ErrorCodeEnum.info_data_illegal.value());
                return rud;
            }

            if (!is_huan_name(name)) {
                rud.setSt(ErrorCodeEnum.menpai_name_have_exist.value());
                return rud;
            }
            MenPaiCacheVo vo = getCmMenpaiFromCache(userId);
            if (vo == null) {
                rud.setSt(ErrorCodeEnum.user_not_exist.value());
                return rud;
            }
            CmMpProps prop = propBo.getCmMpPropsFromCacheBycodeId(userId, PropConstants.GENGMINGTIE_CODE_ID);
            if (prop == null || prop.getPropNum() - 1 < 0) {
                rud.setSt(ErrorCodeEnum.consum_prop_not_enough.value());
            }
            CmMpProps consum_prop = propBo.consumProp(userId, prop.getMpPropId(), 1);
            int card_status = CardStatusEnum.add.value();
            if (consum_prop.getPropNum() == 0) {
                card_status = CardStatusEnum.del.value();
            }
            rud.getCv().getCc().add(PackageCardBo.getPropCard(prop.getMpPropId(), prop.getPropId(), prop.getPropNum(), prop.getPropNum(), card_status));
            rud.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.mp_name.value(), name));
            vo.setMpName(name);
            ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, userId, vo);

            Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, userId);
            if (obj != null) {
                UserPictureVo picvo = (UserPictureVo) obj;
                picvo.setName(name);
                ch.putObjectToCache(CacheNames.USER_PICTURE_DATA_CACHE, userId, picvo);
            }
            rud.setSt(ErrorCodeEnum.normal_success.value());

            return rud;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public List<CmMenpai> getCmMenpaiFromUserId(int userId) {
        return get(CmMenpai.class, "userId", userId, true);
    }
}
