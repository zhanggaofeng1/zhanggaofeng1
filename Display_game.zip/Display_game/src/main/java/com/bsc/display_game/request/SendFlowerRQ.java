/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;

import com.bsc.commonproject.clinet.command.ReceiveJson;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class SendFlowerRQ extends ReceiveJson{
      @JsonProperty("id")
    private int recrive_userId;
        @JsonProperty("tp")
    private int type;

    public int getRecrive_userId() {
        return recrive_userId;
    }

    public void setRecrive_userId(int recrive_userId) {
        this.recrive_userId = recrive_userId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
    
    
    
    
}
