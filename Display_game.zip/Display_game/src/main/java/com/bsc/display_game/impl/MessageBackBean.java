/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.MsgEvent;
import com.bsc.commonproject.vo.Message;
import com.bsc.display_game.bo.MessageBackBo;
import com.bsc.display_game.request.MessageReturnRQ;
import com.bsc.display_game.service.MessageBackService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.CommMsgBean;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.util.json.JsonHelper;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class MessageBackBean extends DaosPublic implements MessageBackService {

    @Resource
    private MessageBackBo messageBackBo;
    @Resource
    private CommMsgBean commMsgBean;
    private static final Logger log = LoggerFactory.getLogger(MessageBackBean.class);

    public void message(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            MessageReturnRQ messageReturnRQ = (MessageReturnRQ) JsonHelper.getBeanFromJson(json, MessageReturnRQ.class);
            int userId = messageReturnRQ.getUserid();
            int messageId = messageReturnRQ.getMessageId();
            int messageType = messageReturnRQ.getMessageType();
            String result = messageReturnRQ.getResult();
            RPState publicRP = new RPState();
            Message m = commMsgBean.getDifTypeOfMessage(userId, messageId, messageType);
            if (m != null) {
                if (m.getMsgEvent().value() == MsgEvent.return_back.value()) {
                    publicRP = messageBackBo.flower(userId, m, result,messageType);
                } else if (m.getMsgEvent().value() == MsgEvent.is_agree_invate_join_faction.value()) {
                    publicRP = messageBackBo.alliance_inviteresut(userId, m, result,messageType);
                } else if (m.getMsgEvent().value() == MsgEvent.is_aggree_request_join_faction.value()) {
                    publicRP = messageBackBo.allance_applyresult(userId, m, result,messageType);
                } else if (m.getMsgEvent().value() == MsgEvent.is_agree_request_join_friend.value()) {
                    publicRP = messageBackBo.friend_add(userId, m, result,messageType);
                } else {
                    publicRP.setSt(ErrorCodeEnum.meaage_no_exist.value());
                }
            } else {
                publicRP.setSt(ErrorCodeEnum.meaage_no_exist.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(publicRP));
            sa.getSend().sendDataToClient(sa, true, true);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(MessageBackBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
