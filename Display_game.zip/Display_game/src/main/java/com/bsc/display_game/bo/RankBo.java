/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.battle.actmanager.ActivityService;
import com.bsc.battle.server.BattlePlInfoBean;
import com.bsc.battle.server.BattleRewardBean;
import com.bsc.battle.server.BattleUtilService;
import com.bsc.battle.vo.AttackUnit;
import com.bsc.battle.vo.PlayerBase;
import com.bsc.battle.vo.enums.BattleType;
import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.clinet.command.response.CJAchieveData;
import com.bsc.commonproject.clinet.command.response.CJPackage;
import com.bsc.commonproject.clinet.command.response.RPBattleData;
import com.bsc.commonproject.constants.CardStatusEnum;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.PropConstants;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.vo.RankVo;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.SystemMsgService;
import com.bsc.protracted.domin.CdCoinLv;
import com.bsc.protracted.domin.CdLv;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CdRankScore;
import com.bsc.protracted.domin.CmMpProps;
import com.bsc.random.server.RandomUtilService;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.datas.DateUtil;
import com.bsc.util.list.BSCLinkedMap;
import com.bsc.util.tools.Tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class RankBo {

    private static final Logger log = LoggerFactory.getLogger(RankBo.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private RandomUtilService randomUtilService;
    @Resource
    private BattleUtilService battleUtilService;
    @Resource
    private BattlePlInfoBean battlePlInfoBean;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private AddCardBo addPropBo;
    @Resource
    private SystemMsgService systemMsgService;
    @Resource
    private AchieveBo achieveBo;
    @Autowired
    private ActivityService actService;
    @Resource
    private BattleRewardBean battleRewardBean;

    //新增加排行用户
    private RankVo add(int userId) throws Exception {
        try {
            List<RankVo> list = null;
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            if (obj == null) {
                list = new ArrayList();
            } else {
                list = (List) obj;
            }
//            RankVo vo = getUserRankDataFromUserId(userId);
//            if (vo == null) {
            RankVo vo = new RankVo();
            vo.setUserId(userId);
            vo.setStartTime(DateUtil.getCurrentDate().getTime());
            list.add(vo);
            vo.setSite(list.size());
            ch.putObjectToCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY, list);
//            }
            return vo;
        } catch (Exception e) {
            e.printStackTrace();
            log.error(LogHelper.getException(e));
            throw e;
        }

    }

    public void create() throws Exception {
        try {
            List<RankVo> list = new ArrayList();
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            for (int i = 500; i > 0; i--) {
                RankVo vo = new RankVo();
                vo.setUserId(i);
                vo.setStartTime(DateUtil.getCurrentDate().getTime());
                list.add(vo);
            }
            ch.putObjectToCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY, list);

        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }

    }
    //查找我在排行中的数据

    public RankVo getUserRankDataFromUserId(int userId) throws Exception {
        RankVo myvo = null;
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            int i = 0;
            if (obj != null) {
                List<RankVo> list = (List) obj;
                for (RankVo vo : list) {
                    i++;
                    if (vo.getUserId() == userId) {
                        myvo = vo;
                        myvo.setSite(i);
                        break;
                    }
                }
                if (myvo == null) {
                    myvo = add(userId);
                }
            } else {
                myvo = add(userId);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return myvo;
    }

    public int getUserRankDataFromUserId2(int userId) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            int i = 0;
            if (obj != null) {
                List<RankVo> list = (List) obj;
                for (RankVo vo : list) {
                    i++;
                    if (vo.getUserId() == userId) {
                        return i;
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return -1;
    }

    public RankVo getUserRankDataFromSite(int site) throws Exception {
        RankVo myvo = null;
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            int i = -1;
            if (obj != null) {
                List<RankVo> list = (List) obj;
                for (RankVo vo : list) {
                    i++;
                    if (i == site) {
                        myvo = vo;
                        myvo.setSite(i);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return myvo;
    }
    //查找互打双方的排行数据

    public RankVo[] getTwoRankData(int userId, int rivalId) throws Exception {
        RankVo[] vos = new RankVo[2];
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            int i = -1;
            if (obj != null) {
                List<RankVo> list = (List) obj;
                for (RankVo vo : list) {
                    i++;
                    if (vo.getUserId() == userId) {
                        vo.setSite(i);
                        vos[0] = vo;
                    }
                    if (vo.getUserId() == rivalId) {
                        vo.setSite(i);
                        vos[1] = vo;
                    }
                    if (vos[0] != null && vos[1] != null) {
                        return vos;
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return null;
    }

    //修改排行数据
    public RankVo[] editRankDate(int userId, int rivalId) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            RankVo[] vos = null;
            if (obj != null) {
                List<RankVo> list = (List) obj;
                vos = getTwoRankData(userId, rivalId);
                if (vos != null && vos.length == 2) {
                    RankVo myVo = vos[0];
                    RankVo rivalVo = vos[1];
                    list.remove(myVo);
                    list.remove(rivalVo);
                    list.add(rivalVo.getSite(), myVo);
                    list.add(myVo.getSite(), rivalVo);

//                    List<RankVo> new_list = new ArrayList();
//                    if (rivalVo.getSite() > 0) {
//                        new_list.addAll(list.subList(0, rivalVo.getSite()));
//                        new_list.add(myVo);
//                        int mysite = myVo.getSite();
//                        if (myVo.getSite()  >= list.size()) {
//                            mysite = list.size();
//                        }
//                        new_list.addAll(list.subList(rivalVo.getSite(), mysite));
//                        list.add(rivalVo);
//                        if (myVo.getSite() + 1 < list.size()) {
//                            new_list.addAll(list.subList(myVo.getSite(), list.size()));
//                        }
//                        myVo.setAttackNum(myVo.getAttackNum());
//                    } else {
//                        new_list.add(myVo);
//                        new_list.addAll(list);
//                    }
                    ch.putObjectToCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY, list);
                }
            }
            return vos;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //修改排行数据
    public RankVo editUserRankDate(int userId, int atackNum, String awardData, BSCLinkedMap map, int consum_score) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            if (obj != null) {
                List<RankVo> list = (List) obj;
                RankVo vo = getUserRankDataFromUserId(userId);
                if (vo != null) {
                    list.remove(vo);
                    vo.setAttackNum(vo.getAttackNum() + atackNum);
                    if (awardData != null && !"".equals(awardData) && !awardData.equals("null")) {
                        vo.setAwardData(awardData);
                    }
                    if (map != null && !map.isEmpty()) {
                        vo.setMap(map);
                    }
                    long start_time = vo.getStartTime();
                    Long sl[] = getMinToScore(vo.getStartTime(), vo.getSite());
                    if (sl[0] != 0) {
                        start_time = DateUtil.getCurrentDate().getTime() - sl[1];
                    }
                    vo.setScore(vo.getScore() + sl[0].intValue());
                    if (consum_score != 0) {
                        vo.setScore(vo.getScore() - consum_score);
                    }
                    vo.setStartTime(start_time);
                    list.remove(vo);
                    list.add(vo.getSite() - 1, vo);
//                    List<RankVo> new_list = new ArrayList();
//                    new_list.addAll(list.subList(0, vo.getSite()));
//                    new_list.add(vo);
//                    new_list.addAll(list.subList(vo.getSite(), list.size()));
                    ch.putObjectToCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY, list);
                    return vo;
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return null;
    }

    public Object[] getmyRankList(int userId) throws Exception {
        Object[] objs = null;
        try {
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            if (obj != null) {
                List<RankVo> list = (List) obj;
                RankVo vo = getUserRankDataFromUserId(userId);
                if (vo != null && vo.getSite() <= list.size()) {
                    objs = new Object[4];//0:用户数据，1：top10，2：用户所在位置上边数据，3：用户所在位置下边数据
                    objs[0] = vo;
                    List<RankVo> nl = null;
                    if (list.size() <= 10) {
                        objs[1] = list.subList(0, list.size());
                    } else {
                        List<RankVo> top_list = new ArrayList();
                        int end_site1 = 10;
                        if (vo.getSite() - 10 <= 0) {
                            end_site1 = vo.getSite();
                        }
                        top_list.addAll(list.subList(0, end_site1));
                        objs[1] = top_list;
                        if (vo.getSite() > 10) {
                            List<RankVo> up_list = new ArrayList();
                            int end_site = vo.getSite();
                            int start_site = 10;
                            if (end_site - 50 > 10) {
                                start_site = vo.getSite() - 50;
                            }
                            up_list.addAll(list.subList(start_site, end_site));
                            nl = new ArrayList();
                            for (int i = 0; i < up_list.size(); i++) {
                                RankVo vo2 = (RankVo) up_list.get(i);
                                vo2.setSite(vo.getSite() - (i + 1));
                                nl.add(vo2);
                            }
                            nl.addAll((List) randomUtilService.rand_many_diff_equip_rate(nl, 10));

                            objs[2] = nl;
                        }

                        int end = vo.getSite() + 5;
                        if (list.size() - vo.getSite() < 5) {
                            end = list.size();
                        }
                        List<RankVo> down_list = new ArrayList();
                        down_list.addAll(list.subList(vo.getSite(), end));
                        objs[3] = down_list;
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return objs;
    }
//排行战斗

    public RPBattleData battle(int userId, int rivalId, RPBattleData rpbd) throws Exception, Throwable {
        try {
            MenPaiCacheVo mp_vo = mpcommonBo.getCmMenpaiFromCache(userId);
            if (mp_vo == null) {
                rpbd.setSt(ErrorCodeEnum.user_not_exist.value());
                return rpbd;
            }
            if (mp_vo.getMpMomentum() <= 0) {
                rpbd.setSt(ErrorCodeEnum.momentum_not_enough.value());
                return rpbd;
            }
            int all_num = mpcommonBo.getPlayNum(1, userId, 2, false);
            int today_num = mpcommonBo.getPlayNum(1, userId, 3, true);
            if (all_num - today_num < 1) {
                rpbd.setSt(ErrorCodeEnum.count_not_enough.value());
                return rpbd;
            }

            Map<Integer, CdCoinLv> coins = (Map<Integer, CdCoinLv>) ch.getObjectFromCache(CacheNames.ACTIVITY_BASIC_CODE_CACHE, ElementKeys.LOGIN_LIGHE_COIN_REWORD);
            if (coins == null || coins.isEmpty()) {
                rpbd.setSt(ErrorCodeEnum.info_error_member_error.value());
                return rpbd;
            }
            CdCoinLv coin = coins.get(mp_vo.getMpLevel());
            if (coin == null) {
                rpbd.setSt(ErrorCodeEnum.info_error_member_error.value());
                return rpbd;
            }
            Map<Integer, CdLv> lvs = (Map<Integer, CdLv>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.LV_KEY);
            if (lvs == null || lvs.isEmpty()) {
                rpbd.setSt(ErrorCodeEnum.info_error_member_error.value());
                return rpbd;
            }
            CdLv lv = lvs.get(mp_vo.getMpLevel());

            //加载自己信息对象
            PlayerBase my_playerBase = battlePlInfoBean.getPlayerBattleData(userId, userId, false, true, BattleType.pvp_bt, 0);
            //加载对手对象
//            PlayerBase you_playerBase = battlePlInfoBean.getPlayerBattleData(rivalId, userId, true, false, BattleType.pvp_bt, 0);
            PlayerBase you_playerBase = null;
            if (rivalId < 10000) {
                you_playerBase = battlePlInfoBean.getTranscriptCfgBattleInfo(rivalId, userId, false, 0, BattleType.robot_config);
            } else {
                you_playerBase = battlePlInfoBean.getPlayerBattleData(rivalId, userId, true, false, BattleType.other_bt, 0);
            }

            //验证对方和己方数据都没问题
            if (you_playerBase != null && my_playerBase != null) {
                //加载战斗过程数据
                AttackUnit attackUnit = battleUtilService.requestBattle(my_playerBase, you_playerBase);
                CJPackage rw = new CJPackage();
                //判断战斗结果
                if (attackUnit != null) {
                    //查询固定奖励数据
                    int peiyangdan = 0;
                    Map cdMessyData_map = (Map) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);

                    //封装数据
//                    rpbd.setOl(attackUnit.getChInitData());
//                    rpbd.setTr(attackUnit.getAk_round());
//                    rpbd.setCf(my_playerBase.getCjfData());
//                    rpbd.setCi(my_playerBase.getCjMpInfo());
                    actService.getBattResultInfo(rpbd, you_playerBase, attackUnit);
                    //用户战斗胜利
                    if (attackUnit.getBatResult() > 0) {
                        if (cdMessyData_map.get("rank_success") != null) {
                            CdMessyData cd = (CdMessyData) cdMessyData_map.get("rank_success");
                            peiyangdan = Integer.parseInt(cd.getMessyValue());
                        }
                        //赢了修改排行顺序
                        editRankDate(userId, rivalId);
                        //战斗结束后封装攻击者的数据
                        RankVo vo = getUserRankDataFromUserId(userId);
                        if (vo != null) {
                            vo.getMap().put(rivalId, rivalId);
                            editUserRankDate(userId, vo.getAttackNum() + 1, vo.getAwardData(), vo.getMap(), 0);
                        }
                        //战斗结束后修改被攻击者数据
                        RankVo vo2 = getUserRankDataFromUserId(rivalId);
                        if (vo2 != null) {
                            vo2.getMap().put(userId, userId);
                            editUserRankDate(rivalId, vo2.getAttackNum(), vo2.getAwardData(), vo2.getMap(), 0);
                        }
                        if (vo != null && vo2 != null) {
                            //int senderId, String senderName, int upRank, int receverId, String reveverName, int downRank
                            systemMsgService.sendCompareSwordMsg(userId, my_playerBase.getMpaiName(), vo.getSite(), rivalId, you_playerBase.getMpaiName(), vo2.getSite());
                        }

                        battleRewardBean.rdDissExpVal(mp_vo, rw, coin.getBabyRewardExp());
                        mpcommonBo.add_enemy(userId, rivalId, 2);

                        AchieveVo achieveVo = achieveBo.saveAchieve(userId, 150010003, 0, vo.getSite());
                        AchieveVo achieveVo2 = achieveBo.saveAchieve(userId, 150010004, 1, 0);
                        if (achieveVo != null || achieveVo2 != null) {
                            Map<String, Object> m = new HashMap<String, Object>();
                            List<CJAchieveData> lt = new ArrayList<CJAchieveData>();
                            if (achieveVo != null) {
                                CJAchieveData cd = new CJAchieveData();
                                cd.setId(150010003);
                                cd.setLv(achieveVo.getLv());
                                lt.add(cd);
                            }
                            if (achieveVo2 != null) {
                                CJAchieveData cd = new CJAchieveData();
                                cd.setId(150010004);
                                cd.setLv(achieveVo2.getLv());
                                lt.add(cd);
                            }
                            m.put(ClientMapKeyEnum.achive.value(), lt);
                            rpbd.setAh(m);
                        }
                    } else {//战斗失败
                        //修改攻击者数据
                        RankVo vo = getUserRankDataFromUserId(userId);
                        if (vo != null) {
//                            vo.getMap().put(rivalId, rivalId);
                            editUserRankDate(userId, vo.getAttackNum(), vo.getAwardData(), vo.getMap(), 0);
                        }
                        if (cdMessyData_map.get("rank_fail") != null) {
                            CdMessyData cd = (CdMessyData) cdMessyData_map.get("rank_fail");
                            peiyangdan = Integer.parseInt(cd.getMessyValue());
                        }
                    }
                    if (peiyangdan != 0) {
//                        //查找用户的培养丹
//                        CmMpProps cmMpProps = addPropBo.getCmMpPropsFromCacheBycodeId(userId, PropConstants.PEIYANGDAN_CODE_ID,0);
                        //修改用户的培养丹个数
                        CmMpProps cmMpProps = addPropBo.addProp(userId, peiyangdan, PropConstants.PEIYANGDAN_CODE_ID);
//                        rw.getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.peiyangdan.value(), String.valueOf(peiyangdan)));

                        rw.getCc().add(PackageCardBo.getPropCard(cmMpProps.getMpPropId(), cmMpProps.getPropId(), cmMpProps.getPropNum(), cmMpProps.getPropLv(), CardStatusEnum.add.value()));

                    }
                    battleRewardBean.rdMpExp(userId, lv.getBattleExperience(), rw);
                    rw.getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.qili.value(), "-1"));
                    rw.getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.fight_count.value(), "-1"));
                    rpbd.setRw(rw);
                    mpcommonBo.getPlayNum(1, userId, 2, true);
                    mpcommonBo.edit_momentum(userId, -1, 1);

                    rpbd.setSt(ErrorCodeEnum.normal_success.value());
                } else {
                    rpbd.setSt(ErrorCodeEnum.battle_not_exist.value());
                }
            } else {
                rpbd.setSt(ErrorCodeEnum.user_not_exist.value());
            }
            return rpbd;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void use_zhangmentie(int userId, int num) throws Exception {
        try {
            Object map_obj = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId));
            Map map = null;
            if (map_obj == null) {
                map = new HashMap();
            } else {
                map = (Map) map_obj;
            }
            Object obj = map.get("PlayNum_" + 1);
            int current_num = 0;
            if (obj != null) {
                current_num = (Integer) obj;
            }

            map.put("PlayNum_" + 1, current_num - num);
            ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId), map);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public Long[] getMinToScore(long startTime, int rank) {
        Long[] r = {0L, 0L};//0:对话积分，1：剩余分钟数
        List<CdRankScore> list = (List<CdRankScore>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RANK_SCORE_KEY);
        long l = DateUtil.getCurrentDate().getTime() - startTime;
        long min = (l / (1000 * 60));
        int score = 0;
        int i = -1;
        for (CdRankScore cdRankScore : list) {
            i++;
            if (cdRankScore.getRank() >= rank) {
                break;
            }
        }
        if (i + 1 > list.size()) {
            i = list.size() - 1;
        }
        int k = 0;
        if (rank <= 10) {
            k = i;
        } else {
            if (i - 1 < 1) {
                i = 1;
            }
            k = i - 1;
        }
        CdRankScore cdRankScore = list.get(k);
        score = cdRankScore.getRankReward();
        if (min >= 10) {
            r[0] = (long) Tools.getNumberToInt(min / 10) * score;
            r[1] = (min % 10) * 60 * 1000;
        }
        return r;
    }

    public Object[] getmyRankList2(int userId) throws Exception {
//        List<RankVo> rvlt = null;
        Object[] objs = null;
        try {
            RankVo vo = getUserRankDataFromUserId(userId);
            Object obj = ch.getObjectFromCache(CacheNames.MENPAI_RANK_DATA_CACHE, ElementKeys.CODE_TABLE_KEY);
            if (obj != null) {
                List<RankVo> list = (List) obj;
                if (vo != null) {
                    objs = new Object[5];//0:用户数据，1：top10，2：攻击过我的人，3:用户所在位置上边数据 ，4：用户所在位置下边数据
                    objs[0] = vo;
                    if (vo.getSite() <= list.size()) {
                        editUserRankDate(userId, vo.getAttackNum(), vo.getAwardData(), vo.getMap(), 0);
                        if (list.size() <= 10) {
                            objs[1] = list.subList(0, list.size());
                            objs[2] = new ArrayList();
                            objs[3] = new ArrayList();
                            objs[4] = new ArrayList();
                        } else {
                            //获取前10列表
                            List<RankVo> top_list = new ArrayList();
                            if (vo.getSite() < 7) {
                                top_list.addAll(list.subList(0, 10));
                                objs[1] = top_list;
                                objs[2] = new ArrayList();
                                objs[3] = new ArrayList();
                                objs[4] = new ArrayList();
                            } else {
                                List<RankVo> up_list = new ArrayList();

                                int end_site1 = 10;
                                if (vo.getSite() - 10 <= 0) {
                                    end_site1 = vo.getSite();
                                }
                                top_list.addAll(list.subList(0, end_site1));
                                objs[1] = top_list;

                                //便利获取击败过我的人
                                List<Integer> lt = new ArrayList<Integer>();
                                Iterator map_it = vo.getMap().entrySet().iterator();
                                while (map_it.hasNext()) {
                                    Map.Entry entry_type = (Map.Entry) map_it.next();
                                    int attach_userd = (Integer) entry_type.getKey();
                                    lt.add(attach_userd);
                                }
                                //击败过我的用户列表
                                List attack_rank = new ArrayList();
                                int attack_num = 0;
                                for (int i = 0; i < list.size(); i++) {
                                    RankVo rankVo = (RankVo) list.get(i);
                                    if (lt.contains(rankVo.getUserId())) {
                                        if (vo.getSite() > i) {
                                            rankVo.setSite(i);
                                            attack_rank.add(rankVo);
                                        }
                                        attack_num++;
                                    }
                                    if (attack_num == lt.size()) {
                                        break;
                                    }
                                }
                                objs[2] = attack_rank;
                                //计算我上边的用户
                                int start_rank = vo.getSite();
                                for (int j = 0; j < 5; j++) {
                                    int R = getRankTwoSite(start_rank);
                                    if (R > 0) {
                                        int next_rank = start_rank - (R / 5 - 1);
//                            if (next_rank < 10) {
                                        RankVo nvo = getUserRankDataFromSite(next_rank);
                                        start_rank = nvo.getSite();
                                        up_list.add(nvo);
                                    }
                                }
                                objs[3] = up_list;

                                //获取我下边的用户
                                int end = vo.getSite() + 3;
                                if (list.size() - vo.getSite() < 3) {
                                    end = list.size();
                                }
                                List<RankVo> down_list = new ArrayList();
                                down_list.addAll(list.subList(vo.getSite(), end));
                                objs[4] = down_list;
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return objs;
    }

    //获取排行的上下连个数值差，规则表中的R
    public int getRankTwoSite(int rank) {
        if (rank > 10) {
            List<CdRankScore> list = (List<CdRankScore>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.RANK_SCORE_KEY);
            Integer[] in = new Integer[2];
            int z = -1;
            for (CdRankScore cdRankScore : list) {
                z++;
                if (cdRankScore.getRank() > rank) {
                    in[1] = cdRankScore.getRank();
                    Object obj = list.get(z - 1);
                    if (obj != null) {
                        in[0] = ((CdRankScore) obj).getRank();
                    }
                    break;
                }
            }
            if (in != null && in.length > 1 && in[1] != in[0]) {
                return in[1] - in[0];
            }
        }
        return -1;
    }
}
