/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.display_game.bo.GameRechargeBo;
import com.bsc.display_game.request.RechargeRQ;
import com.bsc.display_game.service.GameRechargeService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.util.json.JsonHelper;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GameRechargeBean extends DaosPublic implements GameRechargeService {

    private static final Logger log = LoggerFactory.getLogger(GameRechargeBean.class);
    @Resource
    private GameRechargeBo rechargeBo;

    public void rechage(SuperAction sa) throws Exception {
       
        try {
            String json = sa.getRequestJson();
            RechargeRQ rechargeRQ = (RechargeRQ) JsonHelper.getBeanFromJson(json, RechargeRQ.class);
            int userId = rechargeRQ.getUserid();
            int rechargeId = rechargeRQ.getRechargeId();
            String key = rechargeRQ.getKey();
            RPChangeData change = rechargeBo.rechage(key, userId, rechargeId);           
            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GestBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
