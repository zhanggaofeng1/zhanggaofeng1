/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.CJSnatchBSData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPSnatchBKSkill;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.commonproject.vo.RobotVo;
import com.bsc.commonproject.vo.UserPictureVo;
import com.bsc.display_game.bo.GestBo;
import com.bsc.display_game.bo.QueueBo;
import com.bsc.display_game.request.BrokenSell;
import com.bsc.display_game.request.BrokenSellListRQ;
import com.bsc.display_game.request.GestBrokenListRQ;
import com.bsc.display_game.request.GestMixRQ;
import com.bsc.display_game.request.GestUpgradeRQ;
import com.bsc.display_game.service.GestService;
import com.bsc.display_game.vo.BrokenListVo;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.json.JsonHelper;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class GestBean extends DaosPublic implements GestService {

    private static final Logger log = LoggerFactory.getLogger(GestBean.class);
    @Resource
    private CacheHandler ch;
    @Resource
    private GestBo gestBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private QueueBo queueBo;

    //武功参悟
    public void upgrade(SuperAction sa) throws Exception {
        RPChangeData rpchangeData = new RPChangeData();
        try {
            String json = sa.getRequestJson();
            GestUpgradeRQ gestUpgradeRQ = (GestUpgradeRQ) JsonHelper.getBeanFromJson(json, GestUpgradeRQ.class);
            int cardId = gestUpgradeRQ.getCardId();
            int userId = gestUpgradeRQ.getUserid();
            List<Integer> delCardIds = gestUpgradeRQ.getDelCardIds();
            rpchangeData = gestBo.ponder(delCardIds, userId, cardId, rpchangeData);
            sa.setResponseJson(JsonHelper.getJsonFromBean(rpchangeData));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(GestBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void mixtureBroken(SuperAction sa) throws Exception {
        try {
            RPChangeData rpchangeData = new RPChangeData();
            String json = sa.getRequestJson();
            GestMixRQ gestMixRQ = (GestMixRQ) JsonHelper.getBeanFromJson(json, GestMixRQ.class);
            int cardId = gestMixRQ.getCardId();
            int userId = gestMixRQ.getUserid();

            rpchangeData = gestBo.mixtureBroken(cardId, userId, rpchangeData);

            sa.setResponseJson(JsonHelper.getJsonFromBean(rpchangeData));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void sellBroken(SuperAction sa) throws Exception {
        //
        try {
            RPChangeData rpchangeData = new RPChangeData();
            String json = sa.getRequestJson();
            BrokenSellListRQ brokenSellRQ = (BrokenSellListRQ) JsonHelper.getBeanFromJson(json, BrokenSellListRQ.class);
            int userId = brokenSellRQ.getUserid();
            List<BrokenSell> brokenLt = brokenSellRQ.getBrokenLt();
            rpchangeData = gestBo.sellBronken(brokenLt, userId, rpchangeData);

            sa.setResponseJson(JsonHelper.getJsonFromBean(rpchangeData));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void brokenlist(SuperAction sa) throws Exception {
        //
        try {
            RPSnatchBKSkill bk = new RPSnatchBKSkill();
            String json = sa.getRequestJson();
            GestBrokenListRQ bl = (GestBrokenListRQ) JsonHelper.getBeanFromJson(json, GestBrokenListRQ.class);
            int userId = bl.getUserid();

            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                int gestCodeId = bl.getGestCodeId();
                List<String> typeList = bl.getTypeList();
                List<BrokenListVo> volt = gestBo.getBrokenList(userId, vo.getMpLevel(), gestCodeId, typeList);
                if (volt != null && !volt.isEmpty()) {
                    for (BrokenListVo v : volt) {
                        String type = null;
                        Map broken_type_map = (Map) JsonHelper.getBeanFromJson(v.getBroken_info(), Map.class);
                        for (String str : typeList) {
                            if (broken_type_map.get(str) != null) {
                                type = str;
                                break;
                            }
                        }
                        Object obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, v.getMp_id());
                        if (obj == null) {
                            queueBo.addUserInPicture(userId);
                            obj = ch.getObjectFromCache(CacheNames.USER_PICTURE_DATA_CACHE, v.getMp_id());
                        }
                        if (type != null && obj != null) {
                            UserPictureVo upv = (UserPictureVo) obj;
                            CJSnatchBSData cd = new CJSnatchBSData();
                            cd.setCid(gestCodeId);
                            cd.setIl(upv.getDisCodeIds());
                            cd.getTl().add(type);
                            cd.setId(v.getMp_id());
                            cd.setN(upv.getName());
                            cd.setLv(upv.getLevel());
                            bk.getUl().add(cd);
                        }
                    }
                }
                if (bk.getUl().size() < 3) {
                    Map<Integer, List<RobotVo>> map = (Map) ch.getObjectFromCache(CacheNames.ROBOT_DATA_CACHE, ElementKeys.ROBOT_BROKEN_KEY);
                    if (map != null && !map.isEmpty()) {
                        while (bk.getUl().size() != 3) {
                            int mp_lv = getRandomNum(vo.getMpLevel());
                            List<RobotVo> rvlt = map.get(mp_lv);
                            if (rvlt != null && !rvlt.isEmpty()) {
                                int z = (int) (Math.random() * (rvlt.size()));
                                RobotVo rvo = rvlt.get(z);
                                boolean ble = true;
                                for (CJSnatchBSData jd : bk.getUl()) {
                                    if (jd.getId() == rvo.getUserId()) {
                                        ble = false;
                                        break;
                                    }
                                }
                                if (ble) {
                                    CJSnatchBSData cd = new CJSnatchBSData();
                                    cd.setCid(gestCodeId);
                                    cd.setIl(rvo.getDisLt());
                                    cd.getTl().add((typeList == null || typeList.isEmpty()) ? "1" : (String) typeList.get(0));
                                    cd.setId(rvo.getUserId());
                                    cd.setN(rvo.getName());
                                    cd.setLv(rvo.getLv());
                                    bk.getUl().add(cd);
                                }
                            }
                        }
                    }
                }
                bk.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                bk.setSt(ErrorCodeEnum.user_not_login.value());
            }
            sa.setResponseJson(JsonHelper.getJsonFromBean(bk));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    private Integer getRandomNum(int lv) {
        if (lv < 4) {
            return lv;
        }
        int[] is = new int[]{-3, -2, -1, 0, 1, 2, 3};
        int z = (int) (Math.random() * (is.length - 1));
        return lv + is[z];
    }
}
