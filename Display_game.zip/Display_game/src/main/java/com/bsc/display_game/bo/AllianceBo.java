/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.bo;

import com.bsc.battle.server.BattlePlInfoBean;
import com.bsc.battle.server.BattleUtilService;
import com.bsc.battle.vo.AttackUnit;
import com.bsc.battle.vo.PlayerBase;
import com.bsc.battle.vo.enums.BattleType;
import com.bsc.commonproject.bo.AchieveBo;
import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.bo.PackageCardBo;
import com.bsc.commonproject.bo.PropBo;
import com.bsc.commonproject.bo.SaveLogBo;
import com.bsc.commonproject.clinet.command.response.CJSpecialShopItem;
import com.bsc.commonproject.clinet.command.response.RPBattleData;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPShopItemList;
import com.bsc.commonproject.clinet.command.response.RPState;
import com.bsc.commonproject.constants.ClientMapKeyEnum;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.commonproject.constants.FixTimeCleanMapKey;
import com.bsc.commonproject.vo.AchieveVo;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.constants.DataConstants;
import com.bsc.display_game.vo.AllianceVo;
import com.bsc.fun_record.ControlType;
import com.bsc.logs.util.LogHelper;
import com.bsc.message.server.FactionService;
import com.bsc.message.server.LevelMsgService;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CdMessyData;
import com.bsc.protracted.domin.CdUnion;
import com.bsc.protracted.domin.CdUnionStore;
import com.bsc.protracted.domin.CmAlliance;
import com.bsc.protracted.domin.CmAllianceMember;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.random.server.RandomUtilService;
import com.bsc.random.vo.RandOnlyItem;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import com.bsc.temporary.ehcache.ElementKeys;
import com.bsc.util.datas.StringUtil;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import javax.annotation.Resource;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class AllianceBo extends DaosPublic {

    @Resource
    private MenPaiBo menPaiBo;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private CacheHandler ch;
    @Resource
    private CommonBo commonBo;
    @Resource
    private RandomUtilService randomUtilService;
    @Resource
    private AddCardBo addCardBo;
    @Resource
    private BattleUtilService battleUtilService;
    @Resource
    private BattlePlInfoBean battlePlInfoBean;
    @Resource
    private PropBo propBo;
    @Resource
    private LevelMsgService levelMsgService;
    @Resource
    private SaveLogBo saveLogBo;
    @Resource
    private AchieveBo achieveBo;
    @Resource
    private FactionService factionService;
    private static final Logger log = LoggerFactory.getLogger(AllianceBo.class);
//修改联盟经验

    public RPChangeData update_exp(int allianceId, int exp, RPChangeData change) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            if (obj != null) {
                CmAlliance alliance = (CmAlliance) obj;
                int all_exp = alliance.getAllanceExp() + exp;
                Map<Integer, CdUnion> map = (Map<Integer, CdUnion>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                CdUnion cdUnion = (CdUnion) map.get(alliance.getAllanceLevel());
                alliance.setAllanceExp(all_exp);
                //验证联盟是否可以升级
                if (all_exp - cdUnion.getUnionExp() >= 0) {
                    alliance.setAllanceLevel(alliance.getAllanceLevel() + 1);
                    alliance.setAllanceExp(all_exp - cdUnion.getUnionExp());
                    //更新联盟数据
                    update(alliance);
                    change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.alliance_lv.value(), String.valueOf(1)));
                    Map<Integer, CmAllianceMember> members = alliance.getMembers();

                    for (Map.Entry entry_type : members.entrySet()) {
//                        String type = (String) entry_type.getKey();
                        CmAllianceMember cmAllianceMember = (CmAllianceMember) entry_type.getValue();
                        MenPaiCacheVo mpvo = mpcommonBo.getCmMenpaiFromCache(cmAllianceMember.getUserId());
                        if (mpvo != null) {
                            AchieveVo achieveVo = achieveBo.saveAchieve(cmAllianceMember.getUserId(), 150010009, 0, alliance.getAllanceLevel());
                        } else {
                            achieveBo.saveAchievementLevelDB(cmAllianceMember.getUserId(), 150010009, alliance.getAllanceLevel());
                        }
                    }
                }
                ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId, alliance);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
        return change;
    }
    //用户加入联盟或者退出联盟allianceId:0退出联盟，allianceId!=0加入联盟

    public void edit_user_AllianceId(int userId, int allianceId) throws Exception {
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                vo.setAllianceId(allianceId);
                ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, userId, vo);
            }
//            else {
            CmMenpai mp = menPaiBo.getCmMenpaiFromDB(userId);
            if (mp != null) {
                mp.setAllianceId(allianceId);
                update(mp);
//                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //更新联盟用户贡献

    public void update_devote(int allianceId, int userId, int devote) throws Exception {
        try {
            CmAlliance alliance = (CmAlliance) ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            Map<Integer, CmAllianceMember> memebers = alliance.getMembers();
            CmAllianceMember member = memebers.get(userId);
            member.setDevoteValue(member.getDevoteValue() + devote);
            memebers.put(userId, member);
            alliance.setMembers(memebers);
            ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId, alliance);
            Map map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
            Object obj = map.get(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE);
            int old_devote = 0;
            if (obj != null) {
                old_devote = Integer.parseInt((String) obj);
            }
            map.put(FixTimeCleanMapKey.ALLIANCE_TODAY_DEVOTE_VALUE, String.valueOf(old_devote + devote));
            ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId), map);


        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //验证该用户是否为盟主

    public CmAlliance is_mengzhu(int userId) throws Exception {
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, vo.getAllianceId());
            if (obj != null) {
                CmAlliance alliance = (CmAlliance) obj;
                if (alliance.getCreateUserId() == userId) {
                    return alliance;
                }
            }
            return null;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //验证该用户是否为联盟成员

    public CmAllianceMember is_alliance_member(int userId) throws Exception {
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            int allianceId = 0;
            if (vo == null) {
                CmMenpai mp = menPaiBo.getCmMenpaiFromDB(userId);
                allianceId = mp.getAllianceId();
            } else {
                allianceId = vo.getAllianceId();
            }


            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            if (obj != null) {
                CmAlliance alliance = (CmAlliance) obj;
                Map<Integer, CmAllianceMember> memebers = alliance.getMembers();
                for (Map.Entry entry_type : memebers.entrySet()) {
//                    int  cardId =  (Integer) entry_type.getKey();
                    CmAllianceMember member = (CmAllianceMember) entry_type.getValue();
                    if (member.getUserId() == userId) {
                        return member;
                    }
                }
            }
            return null;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //查找用户所在的联盟

    public CmAlliance find_alliance_userId(int userId) throws Exception {
        try {
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            if (vo != null) {
                Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, vo.getAllianceId());
                if (obj != null) {
                    return (CmAlliance) obj;
                } else {
                    if (vo.getAllianceId() != 0) {
                        CmAlliance a = (CmAlliance) get(CmAlliance.class, vo.getAllianceId());
                        ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, vo.getAllianceId(), a);
                        return a;
                    }
                }
            }
            return null;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //查找用户所在的联盟

    public CmAlliance find_alliance(int allianceId) throws Exception {
        try {

            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            if (obj != null) {
                return (CmAlliance) obj;
            } else {
                Object aobj = get(CmAlliance.class, allianceId);
                if (aobj != null) {
                    CmAlliance a = (CmAlliance) aobj;
                    ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId, a);
                    return a;
                }
            }
            return null;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //修改联盟职位

    public void edit_member_post(int allianceId, int userId, int postId) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            if (obj != null) {
                CmAlliance alliance = (CmAlliance) obj;
                Map<Integer, CmAllianceMember> memebers = alliance.getMembers();
                CmAllianceMember member = (CmAllianceMember) memebers.get(userId);
                member.setPost(postId);
                memebers.put(userId, member);
                ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, userId, alliance);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //查找联盟该职位对应的人数

    public int find_post_num(int allianceId, int postId) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            int num = 0;
            if (obj != null) {
                CmAlliance alliance = (CmAlliance) obj;
                Map<Integer, CmAllianceMember> memebers = alliance.getMembers();
                for (Map.Entry entry_type : memebers.entrySet()) {
//                    int  cardId =  (Integer) entry_type.getKey();
                    CmAllianceMember member = (CmAllianceMember) entry_type.getValue();
                    if (member.getPost() == postId) {
                        num++;
                    }
                }
            }
            return num;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
    //验证该职位是否可以增加用户

    public boolean is_post_ok(int allianceId, int postId, int post_num) throws Exception {
        boolean ble = true;
        try {
            if (DataConstants.ALLIANCE_POST_FUMENGZHU == postId) {
                if (post_num >= 2) {
                    ble = false;
                }
            } else if (DataConstants.ALLIANCE_POST_JINGYING == postId) {
                Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
                if (obj != null) {
                    CmAlliance alliance = (CmAlliance) obj;
                    Map<Integer, CdUnion> map = (Map<Integer, CdUnion>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                    CdUnion cdUnion = (CdUnion) map.get(alliance.getAllanceLevel());
                    //封装公式需要的参数
                    //union_num是一个只与联盟等级有关的参数，见配置表“union"
                    Map formula_value_map = new HashMap();
                    formula_value_map.put("union_num", cdUnion.getUnionNum());
                    int final_exp_int = commonBo.getIntFromFormula(47, formula_value_map);
                    if (post_num >= final_exp_int) {
                        ble = false;
                    }
                }
            }
            return ble;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
//新加入联盟用户

    public CmAllianceMember add_alliance(int allianceId, int userId) throws Exception {
        try {
            Object obj = ch.getObjectFromCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId);
            if (obj != null) {
                CmAlliance alliance = (CmAlliance) obj;
                CmAllianceMember member = new CmAllianceMember(allianceId, userId, 0, DataConstants.ALLIANCE_POST_MEMEBER);
                int memberId = save(member);
                member.setMemberId(memberId);
                alliance.getMembers().put(userId, member);
                edit_user_AllianceId(userId, allianceId);
                ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, allianceId, alliance);
            }
            return null;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    //查询门派排行列表
    public List<AllianceVo> getAllianceRank(String name, final int page, final int num) throws Exception {
        try {
            StringBuilder strb = new StringBuilder("select al as alliance,mp.mpName as userName from CmAlliance al,CmMenpai mp where al.createUserId = mp.mpId");
            if (name != null && StringUtil.isNotNull(name)) {
                strb.append(" and al.allianceName like '%").append(name.trim()).append("%'");
            }
            strb.append(" order by al.allanceLevel desc");
            final String hql = strb.toString();
            return super.getHibernateTemplate().execute(new HibernateCallback<List>() {
                public List<AllianceVo> doInHibernate(Session session) throws HibernateException, SQLException {
                    Query query = session.createQuery(hql);
                    query.setFirstResult((page - 1) * num);
                    query.setMaxResults(num);
                    //1、将查询结果转换成List<Map<字段名,字段值>> 
                    query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
                    //2、将结果转换成指定的bean List<你的指定javaBean> 
                    query.setResultTransformer(Transformers.aliasToBean(AllianceVo.class));
                    return query.list();
                }
            });
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPShopItemList getHeiShiList(int userId, RPShopItemList sli) throws Exception {
        try {
            CmAlliance alliance = find_alliance_userId(userId);
            int alliance_id = 0;
            int alliance_lv = 3;
            if (alliance != null) {
                alliance_id = alliance.getAllianceId();
                if (alliance.getAllanceLevel() > 3) {
                    alliance_lv = alliance.getAllanceLevel();
                }
                sli.setUl(alliance_lv);
                Map<Integer, CmAllianceMember> members = alliance.getMembers();
                CmAllianceMember m = members.get(userId);
                sli.setUv(m.getDevoteValue());
            } else {
                sli.setUl(0);
                sli.setUv(0);
            }
            List<CdUnionStore> sj_lt = null;
            Object obj3 = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, FixTimeCleanMapKey.ALLIANCE_HEISHI_PROPS_LIST + "_" + alliance_id);
            if (obj3 == null) {
//                if (true) {
                //获取联盟黑市规则
                Object obj = ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_KEY);
                //获取联盟黑市数据源
                Object obj2 = ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.UNION_STORE_KEY);
                if (obj != null && obj2 != null) {
                    Map<Integer, CdUnion> CdUnion_map = (Map<Integer, CdUnion>) obj;
                    Map<Integer, List<CdUnionStore>> CdUnionStore_map = (Map<Integer, List<CdUnionStore>>) obj2;
                    CdUnion cdUnion = (CdUnion) CdUnion_map.get(alliance_lv);
                    if (cdUnion != null && cdUnion.getUnionAlv() != null && StringUtil.isNotNull(cdUnion.getUnionAlv()) && !"0".equals(cdUnion.getUnionAlv())) {
                        //解析联盟数据源规则
                        String[] vunion_alv = cdUnion.getUnionAlv().split(",");
                        sj_lt = new ArrayList<CdUnionStore>();
                        int show_lv = 0;
                        for (String alv : vunion_alv) {
                            if (new Integer(alv) > show_lv) {
                                show_lv = new Integer(alv);
                            }
                            CdUnion cdUnion2 = (CdUnion) CdUnion_map.get(new Integer(alv));
                            List<CdUnionStore> cumap = CdUnionStore_map.get(new Integer(alv));
                            int z = 0;
                            int all_weight = 0;
                            List<RandOnlyItem> rlt = new ArrayList<RandOnlyItem>();
                            for (CdUnionStore store : cumap) {
                                z++;
                                all_weight += store.getChance();
                                rlt.add(new RandOnlyItem(store, store.getChance(), z));
                            }
                            //随机产品
                            List<RandOnlyItem> RandOnlyList = randomUtilService.randomMultiDiffItem(rlt, all_weight, cdUnion2.getUnionStoreNum());
                            for (RandOnlyItem ri : RandOnlyList) {
                                sj_lt.add((CdUnionStore) ri.getItem());
                            }
                        }
                        List<CdUnionStore> cumap_show = CdUnionStore_map.get(new Integer(10000));
                        List<RandOnlyItem> rlt_show = new ArrayList<RandOnlyItem>();
                        int all_weight2 = 0;
                        int z1 = 0;
                        for (CdUnionStore store : cumap_show) {
                            if (store.getUnionLv() > show_lv) {
                                z1++;
                                all_weight2 = all_weight2 + store.getChance();
                                rlt_show.add(new RandOnlyItem(store, store.getChance(), z1));
                            }
                        }

                        Map<String, CdMessyData> CdMessyData_map = (Map<String, CdMessyData>) ch.getObjectFromCache(CacheNames.BASIC_DEPLOY_CACHE, ElementKeys.MESS_DATA_KEY);
                        int show_num = 3;
                        if (CdMessyData_map != null && CdMessyData_map.get("union_store_num") != null) {
                            CdMessyData cd = (CdMessyData) CdMessyData_map.get("union_store_num");
                            show_num = Integer.parseInt(cd.getMessyValue());
                        }
                        //随机产品
                        List<RandOnlyItem> RandOnlyList_show = randomUtilService.randomMultiDiffItem(rlt_show, all_weight2, show_num);
                        for (RandOnlyItem ri : RandOnlyList_show) {
                            sj_lt.add((CdUnionStore) ri.getItem());
                        }
                        ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, FixTimeCleanMapKey.ALLIANCE_HEISHI_PROPS_LIST + "_" + alliance_id, sj_lt);
                    } else {
                        log.error("table formal error");
                    }
                } else {
                    log.error("table error");
                }
            } else {
                sj_lt = (List<CdUnionStore>) obj3;
            }
            if (sj_lt != null && !sj_lt.isEmpty()) {
                for (CdUnionStore cs : sj_lt) {

                    //获取定义的购买次数
                    //获取定义的购买次数
                    Map map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
                    Object obj = map.get(FixTimeCleanMapKey.ALLIANCE_USER_BUY_NUM);
                    int buynum = 0;
                    if (obj != null) {
                        Map<Integer, Integer> num_map = (Map<Integer, Integer>) obj;
                        Object num_obj = num_map.get(cs.getId());
                        if (num_obj != null) {
                            buynum = (Integer) num_obj;
                        }
                    }


                    CJSpecialShopItem ss = new CJSpecialShopItem();
                    ss.setCid(cs.getId());
                    ss.setLl(cs.getPlayerLv());
                    ss.setMt(cs.getType());
                    ss.setNum(buynum);
                    ss.setRp(cs.getMoney());
                    ss.setUe(cs.getPlayerUnionExp());
                    ss.setUl(cs.getUnionLv());
                    ss.setVl(cs.getVipLv());
                    sli.getLs().add(ss);
                }
            }
            return sli;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPChangeData buyFromHS(int userId, int propId) throws Exception {
        try {
            RPChangeData change = new RPChangeData();
            //查找用户所在的联盟
            CmAlliance alliance = find_alliance_userId(userId);
            if (alliance != null) {
                CmAllianceMember cm = alliance.getMembers().get(userId);
                //获取联盟黑市数据源
                Object obj3 = ch.getObjectFromCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, FixTimeCleanMapKey.ALLIANCE_HEISHI_PROPS_LIST + "_" + alliance.getAllianceId());
                if (obj3 != null) {
                    List<CdUnionStore> uslt = (List<CdUnionStore>) obj3;
                    CdUnionStore cdUnionStore = null;
                    for (CdUnionStore cus : uslt) {
                        if (cus.getId() == propId) {
                            cdUnionStore = cus;
                            break;
                        }
                    }
                    MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
                    if (cdUnionStore != null && vo != null) {
                        if (vo.getMpLevel() < cdUnionStore.getPlayerLv()) {
                            change.setSt(ErrorCodeEnum.mp_level_no_enough.value());
                            return change;
                        }
                        if (vo.getMpVip() < cdUnionStore.getVipLv()) {
                            change.setSt(ErrorCodeEnum.mp_vip_lev_no_enough.value());
                            return change;
                        }

                        if (cm.getDevoteValue() < cdUnionStore.getPlayerUnionExp()) {
                            change.setSt(ErrorCodeEnum.alliance_devote_no_enough.value());
                            return change;
                        }
                        //获取定义的购买次数
                        Map map = commonBo.getFixTimeCleanMap(String.valueOf(userId));
                        Object obj = map.get(FixTimeCleanMapKey.ALLIANCE_USER_BUY_NUM);
                        Map<Integer, Integer> num_map = null;
                        int buynum = 0;
                        if (obj != null) {
                            num_map = (Map<Integer, Integer>) obj;
                            Object num_obj = num_map.get(cdUnionStore.getId());
                            if (num_obj != null) {
                                buynum = (Integer) num_obj;
                            }
                        } else {
                            num_map = new HashMap<Integer, Integer>();
                        }
                        if (buynum > cdUnionStore.getNumUp()) {
                            change.setSt(ErrorCodeEnum.count_not_enough.value());
                            return change;
                        }

                        //判断用户是否可以本次购买
                        int propCodeId = 0;
                        //银币购买
                        if (DataConstants.MONEY_TYPE_SILVERE == cdUnionStore.getType()) {
                            if (vo.getMpSilver() - cdUnionStore.getMoney() > 0) {
                                propCodeId = cdUnionStore.getId();
                                //修改用户银币
                                mpcommonBo.consum_silver(userId, cdUnionStore.getMoney());
                                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.silver.value(), String.valueOf(-cdUnionStore.getMoney())));
                            }
                        } else if (DataConstants.MONEY_TYPE_GOLD == cdUnionStore.getType()) {//金币购买
                            if (vo.getMpGold() - cdUnionStore.getMoney() > 0) {
                                propCodeId = cdUnionStore.getId();
                                //修改金币
                                mpcommonBo.consum_gold(userId, cdUnionStore.getMoney());
                                //String gold_name,int userId, String mp_name, int gold, int counsu_gold, String result, int type
                                saveLogBo.gold(ControlType.HEISHI, userId, vo.getMpName(), vo.getMpGold(), -cdUnionStore.getMoney(), String.valueOf(propCodeId));
                                change.getCv().getCp().add(PackageCardBo.getCJProptyty(ClientMapKeyEnum.gold.value(), String.valueOf(-cdUnionStore.getMoney())));
                            }
                        }
                        if (propCodeId != 0) {
                            change = addCardBo.addAllGoods(userId, propCodeId, cdUnionStore.getNumber(), 1, "1", change);
                            //返回增加数据或者修改数量
                        }
                        num_map.put(cdUnionStore.getId(), buynum + 1);
                        map.put(FixTimeCleanMapKey.ALLIANCE_USER_BUY_NUM, num_map);
                        ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, String.valueOf(userId), map);
                        change.setSt(ErrorCodeEnum.normal_success.value());
                    } else {
                        change.setSt(ErrorCodeEnum.info_error_member_error.value());
                    }
                }
            }
            return change;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void douzhanshengnfo(int userId) throws Exception {
        try {
            CmAllianceMember user_member = is_alliance_member(userId);
            RPBattleData rpbd = null;
            if (user_member != null) {
                Map<String, Object> douzhanshengfo_map = commonBo.getFixTimeCleanMap("allianceId_" + user_member.getAllianceId());
                int first_userId = 0;
                int second_userId = 0;
                int three_userId = 0;
                int site = 0;
                Object first_obj = douzhanshengfo_map.get("first");
                if (first_obj != null) {
                    first_userId = (Integer) first_obj;
                    site = 1;
                }
                Object second_obj = douzhanshengfo_map.get("second");
                if (second_obj != null) {
                    second_userId = (Integer) second_obj;
                    site = 2;
                }
                Object three_obj = douzhanshengfo_map.get("three");
                if (three_obj != null) {
                    three_userId = (Integer) three_obj;
                    site = 3;
                }
                //第一个进入系统的默认为第一名
                if (site == 0) {
                    douzhanshengfo_map.put("first", userId);
                }
                //第二个进入系统的需要和第一个用户打，判断第一，第二名
                if (site == 1) {
                    rpbd = getbattle(userId, first_userId, rpbd);
                    if (rpbd != null) {
                        douzhanshengfo_map.put("first", userId);
                        douzhanshengfo_map.put("second", first_userId);
                        douzhanshengfo_map.put(String.valueOf(userId), rpbd);
                        douzhanshengfo_map.put(String.valueOf(first_userId), rpbd);
                    }
                }
                //第三个进入系统，先和第二位打，赢了之后和第一位打
                if (site == 2) {
                    rpbd = getbattle(userId, second_userId, rpbd);
                    if (rpbd != null) {//和第二位打确定排名
                        douzhanshengfo_map.put("second", userId);
                        douzhanshengfo_map.put("third", second_userId);
                        douzhanshengfo_map.put(String.valueOf(userId), rpbd);
                        douzhanshengfo_map.put(String.valueOf(second_userId), rpbd);
                        rpbd = getbattle(userId, first_userId, rpbd);
                        if (rpbd != null) {//和第一位打确定排名
                            douzhanshengfo_map.put("first", userId);
                            douzhanshengfo_map.put("second", first_userId);
                            douzhanshengfo_map.put(String.valueOf(userId), rpbd);
                            douzhanshengfo_map.put(String.valueOf(first_userId), rpbd);
                        }
                    }
                }
                //第四个进入系统，先和第三位位打，赢了之后和第二位打，最后和第一位打
                if (site == 3) {
                    rpbd = getbattle(userId, three_userId, rpbd);
                    if (rpbd != null) {//和第三位打确定排名
                        douzhanshengfo_map.put("third", userId);
                        douzhanshengfo_map.put(String.valueOf(userId), rpbd);
                        douzhanshengfo_map.put(String.valueOf(three_userId), rpbd);
                        if (rpbd != null) {//和第二位打确定排名
                            douzhanshengfo_map.put("second", userId);
                            douzhanshengfo_map.put("third", second_userId);
                            douzhanshengfo_map.put(String.valueOf(userId), rpbd);
                            douzhanshengfo_map.put(String.valueOf(second_userId), rpbd);

                            rpbd = getbattle(userId, first_userId, rpbd);
                            if (rpbd != null) {//和第一位打确定排名
                                douzhanshengfo_map.put("first", userId);
                                douzhanshengfo_map.put("second", first_userId);
                                douzhanshengfo_map.put(String.valueOf(userId), rpbd);
                                douzhanshengfo_map.put(String.valueOf(first_userId), rpbd);
                            }
                        }
                    }
                }
                ch.putObjectToCache(CacheNames.USER_FIX_TIME_ZERO_TIME_CLEAN_CACHE, "allianceId_" + user_member.getAllianceId(), douzhanshengfo_map);
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPBattleData getbattle(int my_userId, int you_userId, RPBattleData rpbd) throws Exception {
        try {
            //加载对手对象
            PlayerBase you_playerBase = battlePlInfoBean.getPlayerBattleData(my_userId, my_userId, true, false, BattleType.pvp_bt, 0);
            //加载自己信息对象
            PlayerBase my_playerBase = battlePlInfoBean.getPlayerBattleData(you_userId, my_userId, false, true, BattleType.pvp_bt, 0);
            //验证对方和己方数据都没问题
            if (you_playerBase != null && my_playerBase != null) {
                //加载战斗过程数据
                AttackUnit attackUnit = battleUtilService.requestBattle(my_playerBase, you_playerBase);
                //判断战斗结果
                if (attackUnit != null && attackUnit.getBatResult() > 0) {
                    rpbd = new RPBattleData();
                    rpbd.setOl(attackUnit.getChInitData());
                    rpbd.setTr(attackUnit.getAk_round());
                    rpbd.setCf(my_playerBase.getCjfData());
                    rpbd.setCi(my_playerBase.getCjMpInfo());
                    return rpbd;
                }
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public List<CmMenpai> getCmUserSearch(int userId, String info, final int page, final int num) {

        StringBuilder strb = new StringBuilder("select menpai from CmMenpai menpai where 1=1");
//        strb.append(" select f.id from CmFriend f where f.userId =  ").append(userId);
//        strb.append(" and f.friendId = menpai.userId ) is null");
        strb.append(" and mpId <>").append(userId);
        strb.append(" and allianceId=0");
        if (info != null && StringUtil.isNotNull(info)) {
            if (info.matches("[0-9]+")) {
                strb.append(" and menpai.mpLevel = ").append(info);
            } else {
                strb.append(" and menpai.mpName like '%").append(info).append("%'");
            }
        }
        strb.append("order by menpai.mpLevel desc");
        final String hq = strb.toString();
        return getHibernateTemplate().executeFind(new HibernateCallback() {
            public List doInHibernate(Session session) throws HibernateException, SQLException {
                Query query = session.createQuery(hq);
                query.setFirstResult((page - 1) * num);
                query.setMaxResults(num);
                return query.list();
            }
        });
    }

    public RPState post(int userId, int op_userId, int type) throws Exception {
        RPState p = new RPState();
        try {
            //验证用户是否为联盟的盟主
            CmAlliance alliance = is_mengzhu(userId);
            //任命副盟主
            int post = DataConstants.ALLIANCE_POST_FUMENGZHU;
            if (type == 6) {
                post = 0;//解除职位
            }
            if (alliance != null) {
                //验证被提升的人员是否为联盟成员
                if (is_alliance_member(op_userId) != null) {
                    //int userId, int allianceId, int postId, int post_num
                    //判断吗该职位是否可以变化
                    if (post != 0 && !is_post_ok(alliance.getAllianceId(), post, find_post_num(alliance.getAllianceId(), post))) {
                        p.setSt(ErrorCodeEnum.alliance_post_error.value());
                        return p;
                    }
                    //修改职位信息
                    edit_member_post(alliance.getAllianceId(), op_userId, post);
                    MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
                    // factionPlayerBecomeSecondLeader(int senderId, String whoJoin, int factionId)
                    if (type == 6) {
                        factionService.factionPlayerBecomeSecondLeader(userId, vo.getMpName(), vo.getAllianceId());
                    }
                    p.setSt(ErrorCodeEnum.normal_success.value());
                } else {
                    p.setSt(ErrorCodeEnum.alliance_post_error.value());
                }
            } else {
                p.setSt(ErrorCodeEnum.alliance_not_exist.value());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    public RPState invite(int userId, int op_userId, int type) throws Exception {
        RPState p = new RPState();
        try {
            CmAlliance cmAlliance = find_alliance_userId(userId);
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);

            //int senderId, String senderName, int recId, String recName, int factionId, String factionName
            if (vo != null) {
                MenPaiCacheVo op_user_vo = menPaiBo.getCmMenpaiFromCache(op_userId);
                int op_user_allianceId = 0;
                String recName = "";
                if (op_user_vo == null) {
                    CmMenpai mp = menPaiBo.getCmMenpaiFromDB(op_userId);
                    recName = mp.getMpName();
                    op_user_allianceId = mp.getAllianceId();
                } else {
                    recName = vo.getMpName();
                    op_user_allianceId = op_user_vo.getAllianceId();
                }
                if (op_user_allianceId == 0) {
                    levelMsgService.someOneInvateSomeOneJoinFc(userId, vo.getMpName(), op_userId, recName, cmAlliance.getAllianceId(), cmAlliance.getAllianceName());
                    p.setSt(ErrorCodeEnum.normal_success.value());
                } else {
                    p.setSt(ErrorCodeEnum.alliance_have_exist.value());
                }
            } else {
                p.setSt(ErrorCodeEnum.user_not_exist.value());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    public RPState invite_result(int userId, int op_userId, int type) throws Exception {
        RPState p = new RPState();
        try {
            CmAlliance cmAlliance = find_alliance_userId(userId);
            MenPaiCacheVo vo = menPaiBo.getCmMenpaiFromCache(userId);
            String recName = menPaiBo.getMenPaiName(op_userId);
            //int senderId, String senderName, int recId, String recName, int factionId, String factionName
            if (vo != null && vo.getAllianceId() == 0) {
                levelMsgService.someOneInvateSomeOneJoinFc(userId, vo.getMpName(), op_userId, recName, cmAlliance.getAllianceId(), cmAlliance.getAllianceName());
                p.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                p.setSt(ErrorCodeEnum.alliance_have_exist.value());
            }
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        } catch (Throwable ex) {
            java.util.logging.Logger.getLogger(AllianceBo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    public RPState delmember(int userId, int op_userId, int type) throws Exception {
        RPState p = new RPState();
        try {
            CmAllianceMember member = is_alliance_member(userId);
            if (member == null) {
                p.setSt(ErrorCodeEnum.alliance_not_exist.value());
                return p;
            }
            if (member.getPost() < 6) {
                p.setSt(ErrorCodeEnum.alliance_post_error.value());
                return p;
            }

            CmAlliance alliance = find_alliance(member.getAllianceId());
            Map<Integer, CmAllianceMember> members = alliance.getMembers();
            Object obj = members.get(op_userId);
            if (obj != null) {
                CmAllianceMember mem = (CmAllianceMember) obj;
                delete(mem);
                members.remove(op_userId);
                edit_user_AllianceId(op_userId, 0);
                p.setSt(ErrorCodeEnum.normal_success.value());
            }
            return p;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPState quit(int userId, int op_userId, int type) throws Exception {
        RPState p = new RPState();
        try {
            CmAlliance cmAlliance = find_alliance_userId(userId);
            if (cmAlliance != null) {
                CmAllianceMember member = is_alliance_member(userId);
                if (member != null) {
                    //删除数据库
                    delete(member);
                    //删除内存
                    cmAlliance.getMembers().remove(userId);
                    //修改用户信息
                    edit_user_AllianceId(userId, 0);
                    ch.putObjectToCache(CacheNames.ALLIANCE_DATA_CACHE, cmAlliance.getAllianceId(), cmAlliance);
                    p.setSt(ErrorCodeEnum.normal_success.value());
                } else {
                    p.setSt(ErrorCodeEnum.no_alliance_member.value());
                }
            } else {
                p.setSt(ErrorCodeEnum.alliance_not_exist.value());
            }
            return p;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public RPState disband(int userId, int op_userId, int type) throws Exception {
        try {
            RPState state = new RPState();
            CmAlliance mengzhu = is_mengzhu(userId);
            if (mengzhu != null) {
                Map<Integer, CmAllianceMember> memebers = mengzhu.getMembers();
                for (Map.Entry entry_type : memebers.entrySet()) {
                    CmAllianceMember member = (CmAllianceMember) entry_type.getValue();
                    edit_user_AllianceId(member.getUserId(), 0);
                }
                delete(mengzhu);
                ch.delMemoryForObject(CacheNames.ALLIANCE_DATA_CACHE, mengzhu.getAllianceId());
                state.setSt(ErrorCodeEnum.normal_success.value());
            } else {
                state.setSt(ErrorCodeEnum.alliance_post_error.value());
            }
            return state;
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
