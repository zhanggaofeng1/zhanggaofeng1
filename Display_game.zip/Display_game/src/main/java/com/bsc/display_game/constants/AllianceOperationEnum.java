/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.constants;

/**
 *
 * @author lxf
 */
public enum AllianceOperationEnum {
    APPLY_ADD_ALLIANCE("1"),
    AGREE_APPLY("2"),
    DISAGREE_APPLY("3"),
    DELETE_ALLIANCE_MEMBER("4"),
    ALLIANCE_FUMENGZHU("5"),
    DELETE_POST("6"),
    ;
    private String key;

    AllianceOperationEnum(String key) {
        this.key = key;
    }

    public String value() {
        return key;
    }
}
