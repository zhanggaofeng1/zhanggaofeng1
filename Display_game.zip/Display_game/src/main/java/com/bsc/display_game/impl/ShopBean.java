/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.impl;

import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.clinet.command.response.RPShopItemList;
import com.bsc.commonproject.clinet.command.response.RPSummonProtog;
import com.bsc.commonproject.constants.ErrorCodeEnum;
import com.bsc.display_game.bo.AllianceBo;
import com.bsc.display_game.bo.ShopBo;
import com.bsc.display_game.request.ShopBuyRQ;
import com.bsc.display_game.request.ShopListRQ;
import com.bsc.display_game.request.ShopRecruitRQ;
import com.bsc.display_game.service.ShopService;
import com.bsc.displaybases.SuperAction;
import com.bsc.logs.util.LogHelper;
import com.bsc.protracted.daos.DaosPublic;
import com.bsc.protracted.domin.CmAlliance;
import com.bsc.protracted.domin.CmAllianceMember;
import com.bsc.util.json.JsonHelper;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 *
 * @author lxf
 */
@Service
public class ShopBean extends DaosPublic implements ShopService {

    @Resource
    private ShopBo shopBo;
    @Resource
    private AllianceBo allianceBo;
    private static final Logger log = LoggerFactory.getLogger(ShopBean.class);

    public void list(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            ShopListRQ shopListRQ = (ShopListRQ) JsonHelper.getBeanFromJson(json, ShopListRQ.class);
            int userId = shopListRQ.getUserid();
            RPShopItemList sli = new RPShopItemList();
            //黑市列表
            sli = allianceBo.getHeiShiList(userId, sli);
            //商城列表
            sli.getLi().addAll(shopBo.getShopListFromCache("", userId));
            //封装时间
            String[] strs = shopBo.get_flush_time(userId);
            sli.setB(strs[0]);
            sli.setQ(strs[1]);
            sli.setW(strs[2]);
            
             CmAlliance alliance = allianceBo.find_alliance_userId(userId);
             if(alliance != null){
                  sli.setUl(alliance.getAllanceLevel());
                   Map<Integer,CmAllianceMember> members_map = alliance.getMembers();
                   if(members_map!=null &&members_map.get(userId)!=null){
                       CmAllianceMember mm= members_map.get(userId);
                       sli.setUv(mm.getDevoteValue());
                   }
             }
            sli.setSt(ErrorCodeEnum.normal_success.value());
            sa.setResponseJson(JsonHelper.getJsonFromBean(sli));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void buy(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            ShopBuyRQ shopBuyRQ = (ShopBuyRQ) JsonHelper.getBeanFromJson(json, ShopBuyRQ.class);
            RPChangeData change = null;
            if (shopBuyRQ.getType() == 4) {
                change = allianceBo.buyFromHS(shopBuyRQ.getUserid(), shopBuyRQ.getCodeId());
            } else {
                change = shopBo.buy(shopBuyRQ.getUserid(), shopBuyRQ.getCodeId(), shopBuyRQ.getNum(), shopBuyRQ.getType());
            }

            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }

    public void recruit(SuperAction sa) throws Exception {
        try {
            String json = sa.getRequestJson();
            ShopRecruitRQ shopRecruitRQ = (ShopRecruitRQ) JsonHelper.getBeanFromJson(json, ShopRecruitRQ.class);
            int userId = shopRecruitRQ.getUserid();
            RPSummonProtog change = shopBo.getDiscipleFromMarket(shopRecruitRQ.getUserid(), shopRecruitRQ.getType());
            //封装时间
            String[] strs = shopBo.get_flush_time(userId);
            change.setB(strs[0]);
            change.setQ(strs[1]);
            change.setW(strs[2]);

            sa.setResponseJson(JsonHelper.getJsonFromBean(change));
            sa.getSend().sendDataToClient(sa, true, true);
        } catch (Exception e) {
            log.error(LogHelper.getException(e));
            throw e;
        }
    }
}
