/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.service;

import com.bsc.displaybases.SuperAction;
import com.bsc.protracted.daos.BaseDao;

/**
 *
 * @author lxf
 */
public interface MenPaiService extends BaseDao {

    public void create(SuperAction sa) throws Exception;

    public void load(SuperAction sa) throws Exception;

    public void update(SuperAction sa) throws Exception;

    public void barriers(SuperAction sa) throws Exception;
    
    public void tujian(SuperAction sa) throws Exception;
    
    public void renamed(SuperAction sa) throws Exception;
    
    public void otherdata(SuperAction sa) throws Exception;
    
    public void quit(SuperAction sa) throws Exception;
    
}
