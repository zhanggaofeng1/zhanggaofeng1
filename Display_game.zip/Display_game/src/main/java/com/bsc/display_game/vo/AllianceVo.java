/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.vo;

import com.bsc.protracted.domin.CmAlliance;

/**
 *
 * @author lxf
 */
public class AllianceVo implements java.io.Serializable{
    private CmAlliance alliance;
    private String userName;

    public CmAlliance getAlliance() {
        return alliance;
    }

    public void setAlliance(CmAlliance alliance) {
        this.alliance = alliance;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
}
