/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.request;


import com.bsc.commonproject.clinet.command.ReceiveJson;
import java.util.List;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 *
 * @author lxf
 */
public class ChangeQueueRQ extends ReceiveJson{
      @JsonProperty("fl")
    private List<Integer> siteList;

    public List<Integer> getSiteList() {
        return siteList;
    }

    public void setSiteList(List<Integer> siteList) {
        this.siteList = siteList;
    }
    
    
    
}
