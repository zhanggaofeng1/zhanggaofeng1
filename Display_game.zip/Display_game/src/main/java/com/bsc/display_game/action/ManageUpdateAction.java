/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bsc.display_game.action;

import com.bsc.commonproject.bo.AddCardBo;
import com.bsc.commonproject.bo.BrokenBo;
import com.bsc.commonproject.bo.MPCommonBo;
import com.bsc.commonproject.clinet.command.response.RPChangeData;
import com.bsc.commonproject.vo.MenPaiCacheVo;
import com.bsc.display_game.bo.MenPaiBo;
import com.bsc.display_game.bo.PackageBo;
import com.bsc.display_game.service.ManageUpdateService;
import com.bsc.displaybases.SuperAction;
import static com.bsc.displaybases.SuperAction.THROWSERROR;
import com.bsc.protracted.domin.CdBox;
import com.bsc.protracted.domin.CmMenpai;
import com.bsc.temporary.ehcache.CacheHandler;
import com.bsc.temporary.ehcache.CacheNames;
import static com.opensymphony.xwork2.Action.NONE;
import static com.opensymphony.xwork2.Action.SUCCESS;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

/**
 *
 * @author lxf
 */
@ParentPackage("CimoGame")
@Namespace("/")
public class ManageUpdateAction extends SuperAction {

    @Resource
    private ManageUpdateService manageUpdateService;
    @Resource
    private AddCardBo addCardBo;
    @Resource
    private BrokenBo brokenBo;
    @Resource
    private MenPaiBo menPaiBo;
    private int pid;
    private int n;
    private int type;
    private int user_id;
    private int lv;
    private int dlv;
    private int silver;
    private int gold;
    private int vip;
    private int zy;
    private int bt;
    private String tableName;
    private String r = "NO";
    @Resource
    private CacheHandler ch;
    @Resource
    private MPCommonBo mpcommonBo;
    @Resource
    private PackageBo packageBo;

    @Action(value = "mu_update")
    public String mu_update() {
        try {
            r = manageUpdateService.update(type);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return NONE;
    }

    @Action(value = "mp_update")
    public String mp_update() {
        try {
            mpcommonBo.updateFromCacheToDB(type);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return NONE;
    }

    @Action(value = "yl_test")
    public String yl_test() {
        try {
            mpcommonBo.getMenpaiFromDB(type);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return NONE;
    }

    @Action(value = "mp_data", results = {
        @Result(name = "success", location = "/edit_user.jsp")})
    public String mp_data() {
        try {
            if (user_id != 0) {
                CmMenpai m = mpcommonBo.getMenpaiFromDB(user_id);
                if (m != null) {
                    if (gold != 0) {
                        mpcommonBo.add_gold(user_id, gold);
                    }
                    if(vip !=0){
                        menPaiBo.update_vip(user_id, vip);
                    }
                    if (lv != 0) {
                        MenPaiCacheVo vo = (MenPaiCacheVo) ch.getObjectFromCache(CacheNames.USER_MENPAI_CACHE, user_id);
                        vo.setMpLevel(lv);
                        ch.putObjectToCache(CacheNames.USER_MENPAI_CACHE, user_id, vo);
                    }
                    if (silver != 0) {
                        mpcommonBo.add_silver(user_id, silver);
                    }
                    if (zy != 0) {
                        mpcommonBo.update_zhenyuan(user_id, zy);
                    }

//                     menPaiBo.loadfromdb(m, new RPUserData());  
//                    manageUpdateService.update(m);
                }

                addCardBo.addAllGoods(user_id, pid, n, dlv, String.valueOf(bt), new RPChangeData());

            }
            ServletActionContext.getRequest().setAttribute("r", "OK");
            ServletActionContext.getRequest().setAttribute("uid", user_id);
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "mp_rank", results = {
        @Result(name = "success", location = "/edit_user.jsp")})
    public String mp_rank() {
        try {
            manageUpdateService.creat_rank();
            r = "OK";
        } catch (Exception e) {
            return THROWSERROR;
        }
        return NONE;
    }
 @Action(value = "mp_robot", results = {
        @Result(name = "success", location = "/edit_user.jsp")})
    public String mp_robot() {
        try {
            manageUpdateService.creat_rank2();
            r = "OK";
        } catch (Exception e) {
            return THROWSERROR;
        }
        return NONE;
    }
    @Action(value = "user_clean", results = {
        @Result(name = "success", location = "/index.jsp")})
    public String user_clean() {
        try {
            MenPaiCacheVo vo = mpcommonBo.getCmMenpaiFromCache(user_id);
            if (vo != null) {
                mpcommonBo.getMenpaiFromDB(user_id);
                ch.delMemoryForObject(CacheNames.USER_MENPAI_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_DISCIPLE_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_DISCIPLE_SOUL_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_EQUIP_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_GEST_BROKEN_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_GEST_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_KOUJUE_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_LINEUP_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_OTHER_DATA_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_PROP_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_ZHENQI_CACHE, user_id);
                ch.delMemoryForObject(CacheNames.USER_BARRIERS_DATA_CACHE, user_id);
            }
            ServletActionContext.getRequest().setAttribute("r", "OK");
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "t_box", results = {
        @Result(name = "success", location = "/open.jsp")})
    public String t_box() {
        try {
            if (type != 0) {
                List<Integer> lt = new ArrayList();
                if (type == 10) {//金箱子
                    int money = 0;
                    for (int i = 0; i < n; i++) {
                        money = money + 30;
                        if (money < 3000) {
                            type = 1;
                        } else if (money >= 3000 && money < 8000) {
                            type = 8;
                        } else if (money >= 8000) {
                            type = 7;
                        }
                        CdBox b = packageBo.getreward(type);
                        lt.add(b.getItem());
                    }
                } else if (type == 20) {//银箱子
                    int money = 0;
                    for (int i = 0; i < n; i++) {
                        money = money + 20;
                        if (money < 3000) {
                            type = 3;
                        } else if (money >= 3000 && money < 8000) {
                            type = 9;
                        } else if (money >= 8000) {
                            type = 7;
                        }
                        CdBox b = packageBo.getreward(type);
                        lt.add(b.getItem());
                    }
                } else {//
                    for (int i = 0; i < n; i++) {
                        CdBox b = packageBo.getreward(type);
                        lt.add(b.getItem());
                    }
                }
                ServletActionContext.getRequest().setAttribute("lt", lt);
            }
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    @Action(value = "update_table", results = {
        @Result(name = "success", location = "/table.jsp")})
    public String update_table() {
        try {
            manageUpdateService.updateCacheDate(tableName);
            ServletActionContext.getRequest().setAttribute("r", "OK");
        } catch (Exception e) {
            return THROWSERROR;
        }
        return SUCCESS;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getR() {
        return r;
    }

    public void setR(String r) {
        this.r = r;
    }

    public ManageUpdateService getManageUpdateService() {
        return manageUpdateService;
    }

    public void setManageUpdateService(ManageUpdateService manageUpdateService) {
        this.manageUpdateService = manageUpdateService;
    }

    public AddCardBo getAddCardBo() {
        return addCardBo;
    }

    public void setAddCardBo(AddCardBo addCardBo) {
        this.addCardBo = addCardBo;
    }

    public BrokenBo getBrokenBo() {
        return brokenBo;
    }

    public void setBrokenBo(BrokenBo brokenBo) {
        this.brokenBo = brokenBo;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getLv() {
        return lv;
    }

    public void setLv(int lv) {
        this.lv = lv;
    }

    public int getSilver() {
        return silver;
    }

    public void setSilver(int silver) {
        this.silver = silver;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getVip() {
        return vip;
    }

    public void setVip(int vip) {
        this.vip = vip;
    }

    public int getZy() {
        return zy;
    }

    public void setZy(int zy) {
        this.zy = zy;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getBt() {
        return bt;
    }

    public void setBt(int bt) {
        this.bt = bt;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public int getDlv() {
        return dlv;
    }

    public void setDlv(int dlv) {
        this.dlv = dlv;
    }

}
